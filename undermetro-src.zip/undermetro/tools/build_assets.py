# -*- coding: utf-8 -*-
"""
Генератор ассетов и дата-файлов мода (текстуры-заглушки, модели, lang, рецепты, лут, звуки, теги).
Запуск из корня проекта:  python3 tools/build_assets.py
Зависимости: Pillow, numpy, scipy, ffmpeg (для .ogg).
"""
import json
import os
import random
import subprocess
import sys
import tempfile
import zlib

import numpy as np
from PIL import Image, ImageDraw
from scipy.io import wavfile
from scipy.signal import butter, lfilter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from defs import *  # noqa

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "src/main/resources")
MOD = "undermetro"
A = os.path.join(RES, f"assets/{MOD}")
D = os.path.join(RES, f"data/{MOD}")


def write(path, data, mode="json"):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if mode == "json":
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    else:
        with open(path, "w", encoding="utf-8") as f:
            f.write(data)


def hexrgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def shade(c, k):
    return tuple(max(0, min(255, int(v * k))) for v in c)


# ====================================================================== текстуры предметов
def finish(img16, seed):
    """16x16 -> 32x32 с лёгким шумом и тёмным контуром (мрачный полуреалистичный вид)."""
    img = img16.resize((32, 32), Image.NEAREST)
    px = img.load()
    rnd = random.Random(seed)
    for x in range(32):
        for y in range(32):
            r, g, b, a = px[x, y]
            if a:
                n = rnd.uniform(0.88, 1.06)
                px[x, y] = (int(r * n * 0.92), int(g * n * 0.92), int(b * n * 0.92), a)
    # контур
    out = img.copy()
    op = out.load()
    for x in range(32):
        for y in range(32):
            if px[x, y][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < 32 and 0 <= ny < 32 and px[nx, ny][3] > 0:
                        op[x, y] = (12, 12, 12, 170)
                        break
    return out


def icon(kind, color, seed=0):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    c = hexrgb(color)
    dk, lt = shade(c, 0.6), shade(c, 1.3)
    rnd = random.Random(seed)

    def r(x1, y1, x2, y2, col):
        d.rectangle([x1, y1, x2, y2], fill=col + (255,))

    if kind == "can":
        r(4, 3, 11, 13, c); r(4, 3, 11, 4, (170, 170, 170)); r(4, 12, 11, 13, (140, 140, 140))
        r(5, 6, 10, 10, lt); r(7, 7, 8, 9, dk)
    elif kind == "bottle":
        r(6, 2, 9, 4, (90, 90, 90)); r(5, 5, 10, 14, c); r(6, 5, 9, 6, lt); r(5, 9, 10, 11, shade(c, 0.8))
        r(6, 12, 9, 13, dk)
    elif kind == "box":
        r(3, 4, 12, 12, c); r(3, 4, 12, 5, lt); r(5, 7, 10, 10, (225, 215, 190)); r(6, 8, 9, 9, dk)
    elif kind == "bar":
        r(2, 6, 13, 10, c); r(2, 6, 13, 7, lt); r(4, 6, 4, 10, dk); r(8, 6, 8, 10, dk); r(12, 6, 12, 10, dk)
    elif kind == "candy":
        r(5, 6, 10, 9, c); r(3, 7, 4, 8, lt); r(11, 7, 12, 8, lt); r(6, 7, 8, 8, shade(c, 1.4))
    elif kind == "pill":
        r(3, 5, 8, 7, (230, 230, 230)); r(8, 5, 12, 7, c); r(4, 9, 7, 11, c); r(7, 9, 11, 11, (230, 230, 230))
    elif kind == "bandage":
        r(3, 5, 12, 11, c); r(3, 7, 12, 7, (200, 200, 190)); r(3, 9, 12, 9, (200, 200, 190)); r(7, 5, 8, 11, (170, 40, 40))
    elif kind == "medkit":
        r(2, 4, 13, 12, c); r(2, 4, 13, 5, lt); r(7, 6, 8, 11, (240, 240, 240)); r(5, 8, 10, 9, (240, 240, 240))
        r(6, 2, 9, 3, (80, 80, 80))
    elif kind == "syringe":
        r(2, 11, 4, 12, (140, 140, 140)); r(4, 8, 10, 11, (220, 230, 235)); r(5, 9, 9, 10, c); r(10, 9, 13, 10, (120, 120, 120))
    elif kind == "knife":
        d.polygon([(3, 12), (4, 12), (12, 3), (13, 4), (6, 13)], fill=c + (255,))
        r(2, 12, 5, 14, (60, 40, 30)); r(5, 11, 6, 12, (110, 110, 110))
    elif kind == "blade":
        d.polygon([(4, 11), (5, 12), (14, 2), (13, 1)], fill=c + (255,))
        r(2, 12, 5, 14, (50, 35, 25)); r(4, 10, 6, 11, (100, 100, 100))
    elif kind == "bat":
        d.polygon([(3, 13), (4, 14), (13, 4), (12, 2)], fill=c + (255,)); r(2, 13, 3, 14, dk)
        if color in ("#6e4d2a",):
            for (x, y) in ((8, 8), (10, 6), (6, 10)): r(x, y, x + 1, y + 1, (160, 160, 160))
    elif kind == "hammer":
        d.line([(3, 13), (11, 5)], fill=(100, 70, 40, 255), width=2); r(8, 2, 14, 6, c); r(8, 2, 14, 3, lt)
    elif kind == "pick":
        d.line([(3, 13), (11, 5)], fill=(100, 70, 40, 255), width=2)
        d.arc([3, 0, 15, 12], 200, 340, fill=c + (255,), width=2); r(9, 2, 13, 3, c)
    elif kind == "shovel":
        d.line([(3, 13), (9, 7)], fill=(100, 70, 40, 255), width=2); d.polygon([(9, 7), (14, 2), (15, 6), (11, 9)], fill=c + (255,))
    elif kind == "axe":
        d.line([(3, 13), (11, 5)], fill=(100, 70, 40, 255), width=2); d.polygon([(8, 2), (14, 3), (13, 8), (10, 6)], fill=c + (255,))
    elif kind == "hoe":
        d.line([(3, 13), (11, 4)], fill=(100, 70, 40, 255), width=2); r(9, 2, 14, 3, c); r(13, 2, 14, 5, c)
    elif kind.startswith("gun"):
        sub = kind.split("_")[1]
        if sub == "pistol":
            r(3, 4, 11, 6, c); r(8, 7, 10, 12, (70, 50, 35)); r(4, 6, 8, 7, dk); r(11, 4, 12, 5, dk)
        elif sub == "smg":
            r(2, 4, 13, 6, c); r(6, 7, 8, 13, dk); r(9, 7, 11, 10, (70, 50, 35)); r(1, 5, 2, 6, (70, 50, 35))
        elif sub == "rifle":
            r(1, 5, 14, 7, c); r(4, 8, 6, 12, dk); r(8, 8, 9, 9, dk); r(0, 6, 2, 8, (90, 62, 38)); r(11, 4, 14, 4, dk)
        elif sub == "sniper":
            r(0, 6, 15, 7, c); r(2, 4, 7, 5, (40, 40, 40)); r(0, 7, 3, 9, (90, 62, 38)); r(7, 8, 8, 10, dk)
        else:  # shotgun
            r(2, 5, 14, 6, c); r(2, 7, 14, 8, dk); r(0, 6, 4, 10, (90, 62, 38)); r(7, 9, 9, 10, dk)
    elif kind == "mask":
        d.ellipse([3, 2, 12, 12], fill=c + (255,)); r(4, 5, 6, 7, (20, 20, 20)); r(9, 5, 11, 7, (20, 20, 20))
        r(6, 9, 9, 13, (60, 60, 60)); r(7, 10, 8, 12, lt)
    elif kind == "suit":
        r(4, 2, 11, 12, c); r(2, 3, 4, 10, dk); r(11, 3, 13, 10, dk); r(5, 12, 7, 14, dk); r(8, 12, 10, 14, dk)
        r(6, 3, 9, 5, (30, 30, 30))
    elif kind == "filter":
        r(4, 3, 11, 13, c); r(4, 3, 11, 4, (90, 90, 90)); r(4, 12, 11, 13, (90, 90, 90))
        for y in (6, 8, 10): r(5, y, 10, y, dk)
    elif kind == "flash":
        r(3, 9, 8, 11, c); r(9, 7, 13, 12, (60, 60, 60)); r(12, 8, 14, 11, (255, 235, 150))
    elif kind == "battery":
        r(4, 3, 11, 14, c); r(6, 1, 9, 2, (170, 170, 170)); r(4, 6, 11, 7, (240, 240, 240)); r(7, 9, 8, 12, (240, 240, 240))
    elif kind == "radio":
        r(2, 5, 13, 13, c); r(10, 1, 11, 5, (160, 160, 160)); r(3, 7, 8, 11, (30, 30, 30)); r(10, 8, 12, 10, dk)
    elif kind == "lighter":
        r(5, 6, 10, 14, c); r(5, 4, 10, 6, (150, 150, 150)); r(7, 1, 8, 3, (255, 160, 40))
    elif kind == "flask":
        r(5, 3, 10, 5, (80, 80, 80)); r(4, 5, 11, 14, c); r(5, 6, 10, 8, lt)
    elif kind == "canister":
        r(3, 4, 12, 14, c); r(3, 4, 12, 5, lt); r(9, 1, 11, 3, (70, 70, 70)); r(5, 8, 10, 10, dk)
    elif kind == "casing":
        r(6, 3, 9, 13, c); r(6, 3, 9, 5, lt); r(5, 12, 10, 14, dk)
    elif kind == "scrap":
        for _ in range(6):
            x, y = rnd.randint(2, 10), rnd.randint(2, 10)
            r(x, y, x + rnd.randint(2, 4), y + rnd.randint(1, 3), shade(c, rnd.uniform(0.7, 1.3)))
    elif kind == "wire":
        for i in range(4): d.arc([2 + i, 3 + i, 13 - i, 13 - i], 0, 360, fill=shade(c, 1 - 0.1 * i) + (255,))
    elif kind == "board":
        r(2, 3, 13, 12, c); r(4, 5, 6, 7, (200, 200, 60)); r(8, 6, 11, 9, (30, 30, 30))
        for x in (3, 6, 9, 12): r(x, 10, x, 11, (210, 180, 90))
    elif kind == "tape":
        d.ellipse([2, 3, 13, 13], fill=c + (255,)); d.ellipse([5, 6, 10, 10], fill=(0, 0, 0, 0))
    elif kind == "cloth":
        r(2, 3, 13, 12, c); r(2, 3, 13, 4, lt)
        for x in range(3, 13, 3): r(x, 5, x, 12, dk)
    elif kind == "engine":
        r(2, 5, 13, 12, c); r(4, 3, 6, 5, dk); r(8, 3, 10, 5, dk); r(5, 8, 10, 10, (30, 30, 30))
    elif kind == "wheel":
        d.ellipse([2, 2, 13, 13], fill=c + (255,)); d.ellipse([5, 5, 10, 10], fill=(110, 110, 110, 255))
    elif kind == "frame":
        r(2, 6, 13, 8, c); r(3, 3, 4, 11, dk); r(11, 3, 12, 11, dk); r(2, 4, 13, 4, lt)
    elif kind == "kit":
        r(2, 5, 13, 13, c); r(2, 5, 13, 6, lt); r(6, 8, 9, 11, (30, 30, 30)); d.line([(2, 9), (13, 9)], fill=dk + (255,))
    elif kind == "grenade":
        d.ellipse([4, 4, 12, 13], fill=c + (255,)); r(6, 2, 9, 4, (90, 90, 90)); r(10, 1, 12, 2, (160, 160, 160))
        r(6, 7, 9, 7, dk); r(6, 10, 9, 10, dk)
    elif kind == "molotov":
        r(6, 2, 9, 5, (120, 90, 60)); r(5, 6, 10, 14, (90, 120, 80)); r(6, 7, 9, 12, c); r(7, 0, 8, 2, (255, 150, 30))
    elif kind == "ammo":
        for x in (3, 6, 9): r(x, 4, x + 1, 12, c); r(x, 4, x + 1, 6, (170, 90, 50))
    elif kind == "shell":
        for x in (3, 7, 11): r(x, 4, x + 2, 12, c); r(x, 10, x + 2, 12, (190, 160, 70))
    elif kind == "note":
        r(3, 2, 12, 13, c); r(4, 4, 11, 4, dk); r(4, 7, 11, 7, dk); r(4, 10, 9, 10, dk)
    elif kind == "helmet":
        d.pieslice([3, 3, 13, 14], 180, 360, fill=c + (255,)); r(2, 8, 13, 9, dk); r(5, 4, 7, 5, lt)
    elif kind == "vest":
        r(4, 2, 11, 13, c); r(2, 3, 4, 7, dk); r(11, 3, 13, 7, dk); r(6, 2, 9, 4, (20, 20, 20, ))
        r(5, 8, 7, 11, lt); r(8, 8, 10, 11, lt)
    elif kind == "pants":
        r(4, 2, 11, 6, c); r(4, 7, 7, 14, c); r(8, 7, 11, 14, c); r(4, 2, 11, 3, lt); r(7, 6, 8, 14, (0, 0, 0))
    elif kind == "boots":
        r(3, 3, 7, 11, c); r(3, 11, 11, 13, dk); r(7, 9, 11, 11, c); r(3, 3, 7, 4, lt)
    elif kind == "jar":
        r(4, 2, 11, 3, (150, 150, 150)); r(3, 4, 12, 13, (200, 220, 215)); r(4, 6, 11, 12, c); r(4, 6, 11, 7, lt)
    elif kind == "wrench":
        d.line([(3, 13), (11, 5)], fill=c + (255,), width=2); d.ellipse([9, 1, 14, 6], fill=c + (255,))
    elif kind == "rope":
        for i in range(4): d.arc([2 + i, 2 + i, 13 - i, 13 - i], 30 * i, 300 + 30 * i, fill=shade(c, 1 - 0.1 * i) + (255,))
    elif kind == "magazine":
        r(5, 2, 10, 13, c); r(5, 2, 10, 3, dk); r(6, 5, 9, 5, (190, 150, 60)); r(6, 8, 9, 8, (190, 150, 60))
    elif kind == "book":
        r(3, 2, 12, 13, c); r(3, 2, 4, 13, dk); r(6, 4, 11, 5, lt); r(6, 7, 10, 7, lt)
    elif kind == "key":
        d.ellipse([3, 3, 8, 8], fill=c + (255,)); r(8, 5, 13, 6, c); r(11, 6, 12, 8, c)
    elif kind == "pouch":
        r(3, 5, 12, 13, c); r(3, 5, 12, 6, lt); r(6, 7, 9, 9, dk); r(4, 3, 11, 4, dk)
    elif kind == "nails":
        for x in (3, 6, 9, 12): r(x, 3, x, 12, c); r(x - 1, 3, x + 1, 3, lt)
    elif kind == "blueprint":
        r(2, 2, 13, 13, (30, 70, 140)); r(2, 2, 13, 3, (60, 110, 190))
        d.rectangle([4, 5, 11, 10], outline=(210, 225, 255, 255)); d.line([(4, 12), (11, 12)], fill=(210, 225, 255, 255))
    else:
        r(3, 3, 12, 12, c)
    return finish(img, seed)


# ====================================================================== текстуры блоков
def metal_base(seed, base=(86, 90, 94)):
    rnd = np.random.RandomState(seed)
    arr = np.zeros((32, 32, 4), dtype=np.uint8)
    for x in range(32):
        for y in range(32):
            n = rnd.uniform(0.85, 1.05)
            arr[x, y] = (int(base[0] * n), int(base[1] * n), int(base[2] * n), 255)
    img = Image.fromarray(arr.transpose(1, 0, 2), "RGBA")
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, 31, 31], outline=(30, 32, 34, 255))
    d.rectangle([1, 1, 30, 30], outline=(120, 124, 128, 255))
    for (x, y) in ((3, 3), (28, 3), (3, 28), (28, 28)):
        d.rectangle([x - 1, y - 1, x + 1, y + 1], fill=(40, 42, 44, 255))
        d.point((x - 1, y - 1), fill=(150, 150, 150, 255))
    return img


def block_tex(kind, tier, on=False):
    seed = zlib.crc32(f"{kind}{tier}".encode()) & 0xFFFF
    img = metal_base(seed)
    d = ImageDraw.Draw(img)
    tc = hexrgb(TIER_COLORS[tier - 1])
    # полоса уровня
    d.rectangle([6, 5, 25, 7], fill=tc + (255,))
    for i in range(tier):
        d.rectangle([7 + i * 3, 9, 8 + i * 3, 10], fill=shade(tc, 1.2) + (255,))

    def lamp(x, y, col):
        d.rectangle([x, y, x + 2, y + 2], fill=col + (255,))

    if kind == "generator":
        for y in range(13, 27, 3): d.line([(7, y), (24, y)], fill=(30, 30, 30, 255))
        lamp(23, 11, (255, 160, 40) if on else (80, 40, 20))
        if on: d.rectangle([9, 20, 22, 25], fill=(255, 130, 30, 255))
    elif kind == "battery":
        for i in range(4): d.rectangle([7, 13 + i * 4, 24, 15 + i * 4], fill=(60, 180, 80, 255) if i < 3 else (40, 70, 45, 255))
    elif kind == "cable":
        img = metal_base(seed, (40, 40, 44)); d = ImageDraw.Draw(img)
        for y in range(0, 32, 8): d.rectangle([0, y, 31, y + 3], fill=(200, 170, 40, 255))
        d.rectangle([6, 5, 25, 7], fill=tc + (255,))
    elif kind == "lamp":
        if on:
            img = Image.new("RGBA", (32, 32), (255, 240, 170, 255)); d = ImageDraw.Draw(img)
            d.rectangle([0, 0, 31, 31], outline=(120, 105, 60, 255), width=2); d.rectangle([6, 5, 25, 7], fill=tc + (255,))
        else:
            d.rectangle([7, 13, 24, 26], fill=(70, 72, 66, 255)); d.rectangle([9, 15, 22, 24], fill=(52, 54, 50, 255))
    elif kind == "air_filter":
        d.ellipse([7, 12, 24, 29], fill=(30, 34, 36, 255))
        for r_ in (3, 6): d.ellipse([15 - r_ + 0, 20 - r_, 15 + r_ + 1, 20 + r_], outline=(90, 100, 105, 255))
        lamp(23, 11, (90, 200, 255) if on else (30, 60, 80))
    elif kind == "water_filter":
        d.rectangle([8, 12, 23, 28], fill=(40, 90, 130, 255)); d.rectangle([10, 14, 21, 20], fill=(90, 160, 205, 255))
        d.rectangle([14, 24, 17, 28], fill=(30, 30, 30, 255))
    elif kind == "sensor":
        d.rectangle([8, 13, 23, 24], fill=(14, 20, 16, 255))
        d.line([(10, 22), (14, 17), (17, 20), (21, 15)], fill=(70, 220, 110, 255) if on else (190, 60, 50, 255))
        lamp(23, 11, (70, 220, 110) if on else (190, 60, 50))
    elif kind == "turret":
        d.ellipse([8, 12, 23, 27], fill=(26, 28, 30, 255)); d.rectangle([14, 17, 17, 28], fill=(14, 14, 14, 255))
        lamp(14, 14, (220, 40, 30))
    elif kind == "alarm":
        d.ellipse([9, 12, 22, 25], fill=(210, 50, 40, 255) if on else (110, 30, 26, 255))
        if on: d.ellipse([12, 15, 19, 22], fill=(255, 200, 190, 255))
    elif kind in ("door", "hatch"):
        img = metal_base(seed, (70, 74, 78) if kind == "door" else (92, 70, 52)); d = ImageDraw.Draw(img)
        d.rectangle([4, 4, 27, 27], outline=(30, 30, 30, 255), width=2)
        d.ellipse([11, 11, 20, 20], outline=(150, 150, 150, 255), width=2); d.line([(15, 11), (15, 20)], fill=(150, 150, 150, 255))
        d.rectangle([6, 5, 25, 6], fill=tc + (255,)) if kind == "door" else None
        for (x, y) in ((6, 6), (25, 6), (6, 25), (25, 25)): d.rectangle([x, y, x + 1, y + 1], fill=(30, 30, 30, 255))
    return img


def emergency_filter_tex():
    img = metal_base(77, (96, 90, 40)); d = ImageDraw.Draw(img)
    for i in range(-32, 32, 8): d.line([(i, 0), (i + 32, 32)], fill=(30, 30, 30, 255), width=3)
    d.ellipse([8, 8, 24, 24], fill=(20, 24, 26, 255))
    for r_ in (3, 6): d.ellipse([16 - r_, 16 - r_, 16 + r_, 16 + r_], outline=(100, 110, 115, 255))
    return img


# ====================================================================== текстуры существ
def noisy(size, base, seed, amp=0.18):
    rnd = np.random.RandomState(seed)
    n = rnd.uniform(1 - amp, 1 + amp, (size[1], size[0], 1))
    arr = np.clip(np.array(base + (255,), dtype=float)[None, None, :] * np.concatenate([n, n, n, np.ones_like(n)], axis=2), 0, 255)
    return Image.fromarray(arr.astype(np.uint8), "RGBA")


def humanoid_tex(path, skin, cloth, accent, eye, seed):
    img = noisy((64, 64), cloth, seed)
    d = ImageDraw.Draw(img)
    # голова (0..31 x 0..15)
    img.paste(noisy((32, 16), skin, seed + 1), (0, 0))
    d.rectangle([8, 8, 15, 15], fill=skin + (255,))
    d.rectangle([9, 11, 10, 12], fill=eye + (255,)); d.rectangle([13, 11, 14, 12], fill=eye + (255,))
    d.rectangle([10, 14, 13, 14], fill=shade(skin, 0.5) + (255,))
    # руки (40..55 x 16..31) и ноги
    img.paste(noisy((16, 16), skin, seed + 2), (40, 16))
    img.paste(noisy((16, 16), shade(cloth, 0.8), seed + 3), (0, 16))
    img.paste(noisy((16, 16), shade(cloth, 0.8), seed + 4), (16, 48))
    img.paste(noisy((16, 16), skin, seed + 5), (32, 48))
    d.rectangle([20, 20, 27, 31], fill=accent + (255,))
    rnd = random.Random(seed)
    for _ in range(40):  # грязь/кровь
        x, y = rnd.randint(0, 63), rnd.randint(0, 63)
        d.point((x, y), fill=shade(accent, rnd.uniform(0.3, 0.7)) + (255,))
    img.save(path)


def write_entity_textures():
    out = os.path.join(A, "textures/entity")
    os.makedirs(out, exist_ok=True)
    humanoid_tex(f"{out}/shade.png", (18, 18, 22), (10, 10, 14), (30, 30, 40), (255, 60, 40), 11)
    humanoid_tex(f"{out}/marauder.png", (150, 112, 90), (52, 52, 46), (90, 70, 40), (30, 30, 30), 12)
    humanoid_tex(f"{out}/survivor.png", (160, 126, 104), (82, 92, 58), (110, 100, 70), (40, 40, 40), 13)
    humanoid_tex(f"{out}/mutant.png", (96, 112, 78), (70, 76, 58), (110, 40, 40), (230, 220, 90), 14)
    humanoid_tex(f"{out}/leech.png", (60, 100, 96), (40, 78, 80), (90, 120, 60), (240, 240, 120), 15)
    # паук 64x32
    sp = noisy((64, 32), (36, 24, 20), 16, 0.25)
    d = ImageDraw.Draw(sp)
    d.rectangle([40, 12, 47, 19], fill=(48, 30, 26, 255))
    for (x, y) in ((41, 14), (42, 14), (45, 14), (46, 14), (43, 13), (44, 13)): d.point((x, y), fill=(255, 40, 30, 255))
    sp.save(f"{out}/crawler.png")
    # фантом 64x64
    ph = noisy((64, 64), (28, 34, 44), 17, 0.25)
    d = ImageDraw.Draw(ph)
    for (x, y) in ((6, 8), (7, 8), (9, 8), (10, 8)): d.point((x, y), fill=(200, 255, 120, 255))
    ph.save(f"{out}/screecher.png")


# ====================================================================== звуки
SR = 24000


def lp(x, cutoff):
    b, a = butter(2, cutoff / (SR / 2), btype="low")
    return lfilter(b, a, x)


def save_ogg(name, sig):
    sig = sig / (np.max(np.abs(sig)) + 1e-9) * 0.9
    wav = np.int16(sig * 32767)
    with tempfile.TemporaryDirectory() as td:
        w = os.path.join(td, "a.wav")
        wavfile.write(w, SR, wav)
        out = os.path.join(A, "sounds", name + ".ogg")
        os.makedirs(os.path.dirname(out), exist_ok=True)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", w, "-c:a", "libvorbis", "-q:a", "3", "-ac", "1", out], check=True)


def make_sounds():
    rnd = np.random.RandomState(5)
    t = lambda s: np.arange(int(SR * s)) / SR  # noqa
    # выстрелы
    for name, dur, cut, tail, thump in (("shot_pistol", 0.5, 5000, 9, 90), ("shot_rifle", 0.9, 4200, 6, 70), ("shot_shotgun", 1.1, 3000, 5, 55)):
        x = t(dur)
        noise = lp(rnd.randn(len(x)), cut) * np.exp(-x * tail * 2.0)
        boom = np.sin(2 * np.pi * thump * x) * np.exp(-x * tail)
        crack = rnd.randn(len(x)) * np.exp(-x * 90)
        save_ogg(name, noise * 0.8 + boom * 0.9 + crack * 0.4)
    # метро: тяжёлый дрон, капли, далёкие удары
    dur = 70
    x = t(dur)
    sig = np.zeros_like(x)
    for f, amp, lfo in ((41.2, 1.0, 0.07), (55.0, 0.7, 0.05), (58.3, 0.5, 0.09), (82.4, 0.35, 0.03), (110.7, 0.15, 0.11)):
        sig += amp * np.sin(2 * np.pi * f * x + 2 * np.sin(2 * np.pi * lfo * x)) * (0.65 + 0.35 * np.sin(2 * np.pi * lfo * x + f))
    sig += 0.25 * lp(rnd.randn(len(x)), 220) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.04 * x))
    for _ in range(14):  # капли и металлические удары
        s = int(rnd.uniform(1, dur - 3) * SR); L = int(1.6 * SR); xx = np.arange(L) / SR
        f = rnd.choice([310, 440, 620, 880, 140, 95])
        hit = np.sin(2 * np.pi * f * xx) * np.exp(-xx * rnd.uniform(2.5, 6)) * rnd.uniform(0.05, 0.25)
        sig[s:s + L] += hit[: len(sig) - s]
    save_ogg("amb_metro", lp(sig, 2500))
    # поверхность: ветер + редкая «надежда»
    dur = 70
    x = t(dur)
    wind = lp(rnd.randn(len(x)), 700) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.06 * x + 1)) ** 2
    sig = wind * 0.9
    sig += 0.3 * np.sin(2 * np.pi * 73.4 * x) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.05 * x))
    notes = [293.7, 349.2, 440.0, 392.0, 261.6, 349.2]  # Dm — тихая надежда вперемешку со страхом
    for i, f in enumerate(notes * 2):
        s = int((4 + i * 5.2) * SR)
        if s + 4 * SR > len(sig): break
        L = 4 * SR; xx = np.arange(L) / SR
        env = np.minimum(xx / 1.2, 1) * np.exp(-xx * 0.8)
        sig[s:s + L] += 0.12 * (np.sin(2 * np.pi * f * xx) + 0.3 * np.sin(2 * np.pi * f * 2.003 * xx)) * env
    save_ogg("amb_surface", lp(sig, 3500))
    write(f"{A}/sounds.json", {
        n: {"sounds": [f"{MOD}:{n}"]} for n in ("shot_pistol", "shot_rifle", "shot_shotgun", "amb_metro", "amb_surface")
    })
    # amb_* — стримим из файла
    sj = json.load(open(f"{A}/sounds.json", encoding="utf-8"))
    for n in ("amb_metro", "amb_surface"):
        sj[n] = {"sounds": [{"name": f"{MOD}:{n}", "stream": True}]}
    write(f"{A}/sounds.json", sj)


# ====================================================================== lang
def build_lang():
    en, ru = {}, {}
    en[f"itemGroup.{MOD}"] = "Under Metro"; ru[f"itemGroup.{MOD}"] = "Под Метро"
    for rows in (CONSUMABLES,):
        for r in rows: en[f"item.{MOD}.{r[0]}"], ru[f"item.{MOD}.{r[0]}"] = r[1], r[2]
    for r in MELEE + TOOLS + GUNS + MISC:
        en[f"item.{MOD}.{r[0]}"], ru[f"item.{MOD}.{r[0]}"] = r[1], r[2]
    for k, ken, kru in KINDS:
        for t in range(1, MAX_TIER + 1):
            n = machine_name(k, t)
            en[f"block.{MOD}.{n}"] = f"{ken} Mk.{t}"; ru[f"block.{MOD}.{n}"] = f"{kru} Мк.{t}"
            if t > 1:
                en[f"item.{MOD}.blueprint_{n}"] = f"Blueprint: {ken} Mk.{t}"; ru[f"item.{MOD}.blueprint_{n}"] = f"Чертёж: {kru} Мк.{t}"
    en[f"block.{MOD}.hatch"], ru[f"block.{MOD}.hatch"] = "Sealed Hatch", "Гермолюк"
    en[f"block.{MOD}.emergency_filter"], ru[f"block.{MOD}.emergency_filter"] = "Emergency Air Filter", "Аварийный фильтр воздуха"
    for d in DECOR: en[f"block.{MOD}.{d[0]}"], ru[f"block.{MOD}.{d[0]}"] = d[1], d[2]
    for e, n_en, n_ru in ENTITIES: en[f"entity.{MOD}.{e}"], ru[f"entity.{MOD}.{e}"] = n_en, n_ru
    for k, e, r in (
        ("hud.undermetro.hp", "HEALTH", "ЗДОРОВЬЕ"), ("hud.undermetro.food", "HUNGER", "ГОЛОД"), ("hud.undermetro.thirst", "THIRST", "ЖАЖДА"),
        ("hud.undermetro.stamina", "STAMINA", "ВЫНОСЛИВОСТЬ"), ("hud.undermetro.air", "OXYGEN", "КИСЛОРОД"),
        ("hud.undermetro.rad", "INFECTION", "ЗАРАЖЕНИЕ"), ("hud.undermetro.filter", "FILTER", "ФИЛЬТР"),
        ("skill.undermetro.hunger", "Hunger resistance", "Стойкость к голоду"), ("skill.undermetro.thirst", "Thirst resistance", "Стойкость к жажде"),
        ("skill.undermetro.strength", "Strength", "Сила"), ("skill.undermetro.accuracy", "Accuracy", "Меткость"), ("skill.undermetro.stamina", "Stamina", "Выносливость"),
        ("msg.undermetro.skill_up", "Skill improved: %s → %s", "Навык улучшен: %s → %s"),
        ("msg.undermetro.no_ammo", "No ammo", "Нет патронов"), ("msg.undermetro.no_power", "Not enough power", "Недостаточно энергии"),
        ("msg.undermetro.energy", "Energy: %s / %s FE", "Энергия: %s / %s FE"), ("msg.undermetro.gen_busy", "Generator is already burning fuel", "Генератор уже работает"),
        ("msg.undermetro.filter_spent", "Filter is spent!", "Фильтр отработан!"), ("msg.undermetro.no_filter", "No gas mask filter! The air is poisonous!", "Нет фильтра! Воздух отравлен!"),
        ("msg.undermetro.toxic_air", "Toxic air! Put on a gas mask!", "Ядовитый воздух! Нужен противогаз!"),
        ("msg.undermetro.rain", "Radioactive rain! Find shelter!", "Радиоактивный дождь! Найдите укрытие!"),
        ("msg.undermetro.fuel", "Fuel: %s s", "Топливо: %s с"), ("death.attack.radiation", "%1$s died from radiation", "%1$s погиб от радиации"),
    ):
        en[k], ru[k] = e, r
    write(f"{A}/lang/en_us.json", en)
    write(f"{A}/lang/ru_ru.json", ru)



# ====================================================================== декоративные блоки
def decor_tex(style, color, seed, light=0):
    rnd = np.random.RandomState(seed)
    base = hexrgb(color)
    img = noisy((32, 32), base, seed, 0.10)
    d = ImageDraw.Draw(img)
    dk, lt = shade(base, 0.55), shade(base, 1.25)
    def line(*a, **k): d.line(*a, **k)
    if style in ("tiles", "tiles_cracked", "tiles_dirty"):
        for i in range(0, 32, 8):
            line([(i, 0), (i, 31)], fill=dk + (255,)); line([(0, i), (31, i)], fill=dk + (255,))
        if style == "tiles_cracked":
            x, y = rnd.randint(4, 24), rnd.randint(2, 8)
            for _ in range(14): nx, ny = x + rnd.randint(-2, 3), y + rnd.randint(1, 3); line([(x, y), (nx, ny)], fill=(20, 20, 20, 255)); x, y = nx, ny
        if style == "tiles_dirty":
            for _ in range(80): d.point((rnd.randint(0, 31), rnd.randint(0, 31)), fill=(40, 34, 26, 255))
    elif style == "checker":
        for x in range(0, 32, 8):
            for y in range(0, 32, 8):
                if (x // 8 + y // 8) % 2: d.rectangle([x, y, x + 7, y + 7], fill=shade(base, 0.45) + (255,))
    elif style == "concrete":
        for _ in range(60): d.point((rnd.randint(0, 31), rnd.randint(0, 31)), fill=shade(base, rnd.uniform(0.5, 0.8)) + (255,))
        if "cracked" in color or seed % 3 == 0:
            x, y = rnd.randint(4, 28), 0
            while y < 31: nx, ny = x + rnd.randint(-2, 2), y + rnd.randint(2, 4); line([(x, y), (nx, ny)], fill=(25, 25, 25, 255)); x, y = nx, ny
    elif style == "slab":
        d.rectangle([0, 0, 31, 31], outline=dk + (255,)); line([(0, 16), (31, 16)], fill=dk + (255,)); line([(16, 0), (16, 16)], fill=dk + (255,)); line([(8, 16), (8, 31)], fill=dk + (255,))
        for (x, y) in ((2, 2), (29, 2), (2, 29), (29, 29)): d.rectangle([x, y, x + 1, y + 1], fill=(30, 30, 30, 255))
    elif style == "rust":
        for _ in range(26):
            x, y = rnd.randint(0, 28), rnd.randint(0, 28); w = rnd.randint(2, 7)
            d.ellipse([x, y, x + w, y + w], fill=shade((150, 70, 28), rnd.uniform(0.5, 1.1)) + (255,))
    elif style == "grate":
        d.rectangle([0, 0, 31, 31], fill=(20, 20, 20, 255))
        for i in range(2, 32, 6): d.rectangle([i, 0, i + 2, 31], fill=base + (255,)); d.rectangle([0, i, 31, i + 2], fill=dk + (255,))
    elif style == "panel":
        d.rectangle([1, 1, 30, 30], outline=dk + (255,)); d.rectangle([4, 4, 27, 27], outline=lt + (255,))
        for (x, y) in ((3, 3), (28, 3), (3, 28), (28, 28)): d.rectangle([x, y, x + 1, y + 1], fill=(30, 30, 30, 255))
    elif style == "crate":
        d.rectangle([0, 0, 31, 31], outline=dk + (255,), width=2); line([(0, 0), (31, 31)], fill=dk + (255,), width=2); line([(0, 31), (31, 0)], fill=dk + (255,), width=2)
        for y in (8, 16, 24): line([(2, y), (29, y)], fill=shade(base, 0.8) + (255,))
    elif style == "barrel":
        for y in (3, 12, 20, 28): d.rectangle([0, y, 31, y + 2], fill=dk + (255,))
        for x in range(2, 32, 6): line([(x, 0), (x, 31)], fill=shade(base, 0.85) + (255,))
    elif style == "locker":
        d.rectangle([0, 0, 31, 31], outline=dk + (255,), width=2); line([(16, 0), (16, 31)], fill=dk + (255,), width=2)
        for x in (4, 20):
            for y in (5, 8, 11): d.rectangle([x, y, x + 8, y], fill=(20, 20, 20, 255))
        d.rectangle([13, 16, 14, 19], fill=(180, 180, 170, 255)); d.rectangle([18, 16, 19, 19], fill=(180, 180, 170, 255))
    elif style == "pipes":
        for y in (2, 12, 22):
            d.rectangle([0, y, 31, y + 7], fill=shade(base, 0.9) + (255,)); d.rectangle([0, y, 31, y + 1], fill=lt + (255,)); d.rectangle([0, y + 6, 31, y + 7], fill=dk + (255,))
            for x in (6, 24): d.rectangle([x, y - 1, x + 2, y + 8], fill=dk + (255,))
    elif style == "vent":
        d.rectangle([2, 2, 29, 29], fill=(20, 22, 24, 255), outline=lt + (255,), width=2)
        for y in range(6, 28, 4): d.rectangle([5, y, 26, y + 1], fill=base + (255,))
    elif style == "hazard":
        d.rectangle([0, 0, 31, 31], fill=(26, 26, 26, 255))
        for i in range(-32, 32, 12): d.polygon([(i, 31), (i + 6, 31), (i + 38, 0), (i + 32, 0)], fill=base + (255,))
    elif style == "brick":
        for y in range(0, 32, 8):
            line([(0, y), (31, y)], fill=shade(base, 0.45) + (255,))
            off = 0 if (y // 8) % 2 == 0 else 8
            for x in range(off, 40, 16): line([(x, y), (x, y + 7)], fill=shade(base, 0.45) + (255,))
    elif style == "wallpaper":
        for x in range(0, 32, 8): d.rectangle([x, 0, x + 3, 31], fill=shade(base, 1.12) + (255,))
        for (x, y) in ((6, 6), (14, 20), (22, 10), (4, 26), (26, 26)): d.ellipse([x, y, x + 3, y + 3], fill=shade(base, 0.6) + (255,))
        for _ in range(40): d.point((rnd.randint(0, 31), rnd.randint(0, 31)), fill=(60, 50, 40, 255))
    elif style == "sandbag":
        for y in range(0, 32, 8):
            off = 0 if (y // 8) % 2 == 0 else 8
            for x in range(off - 16, 32, 16): d.ellipse([x, y, x + 15, y + 8], fill=shade(base, rnd.uniform(0.85, 1.1)) + (255,), outline=dk + (255,))
    elif style == "planks":
        for y in range(0, 32, 8):
            line([(0, y), (31, y)], fill=dk + (255,))
            for _ in range(10): x = rnd.randint(0, 30); line([(x, y + 2), (x + rnd.randint(2, 6), y + 2)], fill=shade(base, 0.75) + (255,))
    elif style == "graffiti":
        d.rectangle([0, 0, 31, 31], fill=(92, 92, 90, 255))
        for _ in range(60): d.point((rnd.randint(0, 31), rnd.randint(0, 31)), fill=(60, 60, 58, 255))
        line([(4, 24), (9, 7), (15, 20), (21, 6), (27, 24)], fill=base + (255,), width=3)
        d.ellipse([20, 22, 28, 30], outline=shade(base, 0.8) + (255,), width=2)
        for x in (6, 14, 22): d.line([(x, 25), (x, 31)], fill=base + (180,))
    elif style == "mesh":
        img = Image.new("RGBA", (32, 32), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
        for i in range(-32, 64, 6):
            line([(i, 0), (i + 32, 32)], fill=base + (255,)); line([(i, 32), (i + 32, 0)], fill=shade(base, 0.75) + (255,))
        d.rectangle([0, 0, 31, 31], outline=dk + (255,))
    elif style == "tarp":
        for y in range(0, 32, 2): d.line([(0, y), (31, y)], fill=shade(base, rnd.uniform(0.9, 1.1)) + (255,))
        for x in (3, 28):
            for y in (3, 28): d.ellipse([x - 1, y - 1, x + 1, y + 1], fill=(150, 150, 150, 255))
        for _ in range(3): x = rnd.randint(4, 26); d.line([(x, 0), (x + rnd.randint(-4, 4), 31)], fill=dk + (255,))
    elif style == "moss":
        img = noisy((32, 32), (60, 54, 48), seed, 0.18); d = ImageDraw.Draw(img)
        for _ in range(140):
            x, y = rnd.randint(0, 30), rnd.randint(0, 30)
            d.rectangle([x, y, x + rnd.randint(1, 3), y + rnd.randint(1, 3)], fill=shade(base, rnd.uniform(0.7, 1.4)) + (255,))
    elif style == "flesh":
        for _ in range(30):
            x, y = rnd.randint(0, 28), rnd.randint(0, 28); w = rnd.randint(3, 8)
            d.ellipse([x, y, x + w, y + w], fill=shade(base, rnd.uniform(0.6, 1.3)) + (255,), outline=dk + (255,))
        for _ in range(5): d.line([(rnd.randint(0, 31), rnd.randint(0, 31)), (rnd.randint(0, 31), rnd.randint(0, 31))], fill=(110, 20, 30, 255))
    elif style == "carpet":
        d.rectangle([2, 2, 29, 29], outline=shade(base, 1.4) + (255,))
        d.rectangle([5, 5, 26, 26], outline=shade(base, 0.6) + (255,))
        for i in range(8, 26, 4): d.line([(i, 8), (i, 24)], fill=shade(base, 1.2) + (255,))
        for _ in range(50): d.point((rnd.randint(0, 31), rnd.randint(0, 31)), fill=(40, 34, 30, 255))
    elif style == "switchboard":
        d.rectangle([2, 2, 29, 29], fill=shade(base, 0.7) + (255,), outline=dk + (255,), width=2)
        for y in (6, 13, 20):
            for x in (6, 11, 16, 21): d.rectangle([x, y, x + 2, y + 4], fill=(30, 30, 30, 255)); d.point((x + 1, y + 1), fill=(220, 200, 60, 255) if rnd.rand() > 0.5 else (60, 200, 90, 255))
    elif style in ("lamp", "neon"):
        img = Image.new("RGBA", (32, 32), shade(base, 0.9) + (255,)); d = ImageDraw.Draw(img)
        d.rectangle([0, 0, 31, 31], outline=shade(base, 0.45) + (255,), width=3)
        if style == "neon":
            line([(5, 22), (10, 8), (16, 22), (22, 8), (27, 22)], fill=(255, 255, 255, 255), width=3)
        else:
            d.rectangle([6, 6, 25, 25], fill=shade(base, 1.2) + (255,))
    elif style == "screen":
        img = Image.new("RGBA", (32, 32), (30, 30, 34, 255)); d = ImageDraw.Draw(img)
        d.rectangle([3, 4, 28, 24], fill=base + (255,), outline=(60, 60, 64, 255))
        if color == "#6a7a7a":
            for _ in range(160): d.point((rnd.randint(4, 27), rnd.randint(5, 23)), fill=(rnd.randint(60, 200),) * 3 + (255,))
        d.rectangle([13, 26, 18, 29], fill=(50, 50, 54, 255))
    elif style == "rack":
        img = Image.new("RGBA", (32, 32), (30, 32, 36, 255)); d = ImageDraw.Draw(img)
        for y in range(2, 30, 5):
            d.rectangle([2, y, 29, y + 3], fill=(48, 52, 58, 255))
            for x in (4, 8, 12): d.point((x, y + 1), fill=(60, 220, 90, 255) if rnd.rand() > 0.5 else (200, 60, 50, 255))
    elif style == "sign":
        img = Image.new("RGBA", (32, 32), base + (255,)); d = ImageDraw.Draw(img)
        d.rectangle([1, 1, 30, 30], outline=(235, 235, 225, 255), width=2)
        d.polygon([(8, 22), (16, 8), (24, 22)], outline=(235, 235, 225, 255), fill=None); d.rectangle([14, 14, 17, 19], fill=(235, 235, 225, 255))
    d.rectangle([0, 0, 31, 31], outline=shade(base, 0.35) + (255,)) if style not in ("lamp", "neon", "mesh") else None
    return img


def build_decor():
    bt = f"{A}/textures/block"
    os.makedirs(bt, exist_ok=True)
    for (i, en, ru, style, color, light, strength) in DECOR:
        decor_tex(style, color, zlib.crc32(i.encode()) & 0xFFFF, light).save(f"{bt}/{i}.png")
        write(f"{A}/models/block/{i}.json", {"parent": "minecraft:block/cube_all", "textures": {"all": f"{MOD}:block/{i}"}})
        write(f"{A}/blockstates/{i}.json", {"variants": {"": {"model": f"{MOD}:block/{i}"}}})
        write(f"{A}/models/item/{i}.json", {"parent": f"{MOD}:block/{i}"})

# ====================================================================== всё остальное
def block_names():
    names = []
    for k, _, _ in KINDS:
        for t in range(1, MAX_TIER + 1): names.append(machine_name(k, t))
    names += ["hatch", "emergency_filter"] + [d[0] for d in DECOR]
    return names


def kind_of(name):
    for k, _, _ in KINDS:
        if name.startswith(k + "_t"): return k
    return name


def build_content_json():
    c = {"consumables": [], "melee": [], "tools": [], "guns": [], "misc": []}
    for (i, _, _, kind, hu, sat, th, hp, ar, fx, _, _) in CONSUMABLES:
        c["consumables"].append({"id": i, "kind": kind, "hunger": hu, "sat": sat, "thirst": th, "health": hp, "antirad": ar,
                                 "fx": [{"effect": e, "duration": d, "amplifier": a} for (e, d, a) in fx]})
    for (i, _, _, dmg, sp, du, _, _) in MELEE:
        c["melee"].append({"id": i, "damage": dmg, "speed": sp, "durability": du})
    for (i, _, _, ty, dmg, sp, du, ms, _, _) in TOOLS:
        c["tools"].append({"id": i, "type": ty, "damage": dmg, "speed": sp, "durability": du, "mine_speed": ms})
    for (i, _, _, dmg, delay, pel, spr, rng, ammo, du, snd, _, _) in GUNS:
        c["guns"].append({"id": i, "damage": dmg, "delay": delay, "pellets": pel, "spread": spr, "range": rng, "ammo": ammo, "durability": du, "sound": snd})
    for (i, _, _, ty, st, du, _, _) in MISC:
        c["misc"].append({"id": i, "type": ty, "stack": st, "durability": du, "armor": ARMOR_VALUES.get(i, 0)})
    c["decor"] = [{"id": d[0], "strength": d[6], "light": d[5]} for d in DECOR]
    write(f"{RES}/undermetro_content.json", c)


def build_items_and_blocks():
    handheld = {r[0] for r in MELEE + TOOLS + GUNS}
    all_items = [(r[0], r[10], r[11]) for r in CONSUMABLES] + [(r[0], r[6], r[7]) for r in MELEE] + \
                [(r[0], r[8], r[9]) for r in TOOLS] + [(r[0], r[11], r[12]) for r in GUNS] + [(r[0], r[6], r[7]) for r in MISC]
    tex_dir = f"{A}/textures/item"; os.makedirs(tex_dir, exist_ok=True)
    for n, ic, col in all_items:
        icon(ic, col, zlib.crc32(n.encode()) & 0xFFFF).save(f"{tex_dir}/{n}.png")
        write(f"{A}/models/item/{n}.json", {"parent": "minecraft:item/handheld" if n in handheld else "minecraft:item/generated",
                                              "textures": {"layer0": f"{MOD}:item/{n}"}})
    # чертежи
    for k, _, _ in KINDS:
        for t in range(2, MAX_TIER + 1):
            n = f"blueprint_{machine_name(k, t)}"
            img = icon("blueprint", "#2a4a8a", zlib.crc32(n.encode()) & 0xFFFF)
            d = ImageDraw.Draw(img)
            tc = hexrgb(TIER_COLORS[t - 1])
            d.rectangle([6, 22, 25, 25], fill=tc + (255,))
            img.save(f"{tex_dir}/{n}.png")
            write(f"{A}/models/item/{n}.json", {"parent": "minecraft:item/generated", "textures": {"layer0": f"{MOD}:item/{n}"}})
    # блоки
    bt = f"{A}/textures/block"; os.makedirs(bt, exist_ok=True)
    for k, _, _ in KINDS + [("hatch", "", "")]:
        tiers = range(1, MAX_TIER + 1) if k != "hatch" else [1]
        for t in tiers:
            n = machine_name(k, t)
            block_tex(k, t, False).save(f"{bt}/{n}.png")
            on_state = {"generator": "lit", "lamp": "lit", "air_filter": "lit", "alarm": "lit", "sensor": "powered", "door": "open", "hatch": "open"}.get(k)
            cube = lambda tex: {"parent": "minecraft:block/cube_all", "textures": {"all": f"{MOD}:block/{tex}"}}  # noqa
            thin = lambda tex: {"parent": "minecraft:block/block", "textures": {"all": f"{MOD}:block/{tex}", "particle": f"{MOD}:block/{tex}"},  # noqa
                                "elements": [{"from": [0, 0, 14], "to": [16, 16, 16], "faces": {
                                    f: {"uv": [0, 0, 16, 16], "texture": "#all"} for f in ("north", "south", "east", "west", "up", "down")}}]}
            write(f"{A}/models/block/{n}.json", cube(n))
            if on_state in ("lit", "powered"):
                block_tex(k, t, True).save(f"{bt}/{n}_on.png")
                write(f"{A}/models/block/{n}_on.json", cube(n + "_on"))
                write(f"{A}/blockstates/{n}.json", {"multipart": [
                    {"when": {on_state: "false"}, "apply": {"model": f"{MOD}:block/{n}"}},
                    {"when": {on_state: "true"}, "apply": {"model": f"{MOD}:block/{n}_on"}}]})
            elif on_state == "open":
                write(f"{A}/models/block/{n}_open.json", thin(n))
                write(f"{A}/blockstates/{n}.json", {"multipart": [
                    {"when": {"open": "false"}, "apply": {"model": f"{MOD}:block/{n}"}},
                    {"when": {"open": "true"}, "apply": {"model": f"{MOD}:block/{n}_open"}}]})
            else:
                write(f"{A}/blockstates/{n}.json", {"variants": {"": {"model": f"{MOD}:block/{n}"}}})
            write(f"{A}/models/item/{n}.json", {"parent": f"{MOD}:block/{n}"})
    emergency_filter_tex().save(f"{bt}/emergency_filter.png")
    write(f"{A}/models/block/emergency_filter.json", {"parent": "minecraft:block/cube_all", "textures": {"all": f"{MOD}:block/emergency_filter"}})
    write(f"{A}/blockstates/emergency_filter.json", {"variants": {"": {"model": f"{MOD}:block/emergency_filter"}}})
    write(f"{A}/models/item/emergency_filter.json", {"parent": f"{MOD}:block/emergency_filter"})


def item_ref(i): return f"{MOD}:{i}"


def build_recipes():
    rd = f"{D}/recipe"
    def shaped(name, pattern, key, result, count=1):
        write(f"{rd}/{name}.json", {"type": "minecraft:crafting_shaped", "category": "misc", "pattern": pattern,
                                     "key": {k: {"item": v if ":" in v else item_ref(v)} for k, v in key.items()},
                                     "result": {"id": item_ref(result), "count": count}})
    def shapeless(name, ings, result, count=1):
        write(f"{rd}/{name}.json", {"type": "minecraft:crafting_shapeless", "category": "misc",
                                     "ingredients": [{"item": i if ":" in i else item_ref(i)} for i in ings],
                                     "result": {"id": item_ref(result), "count": count}})
    for k, (pat, key) in T1_RECIPES.items():
        shaped(f"{k}_t1", pat, key, f"{k}_t1")
        for t in range(2, MAX_TIER + 1):
            # чертёж не расходуется (см. BlueprintItem); два предмета прошлого уровня идут на разбор
            shapeless(f"{k}_t{t}", [f"blueprint_{k}_t{t}", f"{k}_t{t-1}", f"{k}_t{t-1}"], f"{k}_t{t}")
    shaped("hatch", ["SSS", "SBS", "SSS"], {"S": "scrap_metal", "B": "duct_tape"}, "hatch")
    shaped("emergency_filter", ["SSS", "SFS", "SWS"], {"S": "scrap_metal", "F": "filter_basic", "W": "copper_wire"}, "emergency_filter")
    shaped("battery_small", ["WSW", "SPS", "WSW"], {"W": "copper_wire", "S": "scrap_metal", "P": "plastic_scrap"}, "battery_small")
    shaped("flashlight", ["PBP", "PEP", "SSS"], {"P": "plastic_scrap", "B": "battery_small", "E": "electronic_scrap", "S": "scrap_metal"}, "flashlight")
    shaped("gas_mask", ["RRR", "PFP", "RTR"], {"R": "rubber", "P": "plastic_scrap", "F": "filter_basic", "T": "duct_tape"}, "gas_mask")
    shaped("hazmat_suit", ["RCR", "RCR", "T T"], {"R": "rubber", "C": "cloth_scrap", "T": "duct_tape"}, "hazmat_suit")
    shaped("filter_basic", ["PSP", "SCS", "PSP"], {"P": "plastic_scrap", "S": "scrap_metal", "C": "cloth_scrap"}, "filter_basic")
    shaped("radio", ["SES", "WBW", "SSS"], {"S": "scrap_metal", "E": "electronic_scrap", "W": "copper_wire", "B": "battery_small"}, "radio")
    shaped("flask_empty", ["P", "S"], {"P": "plastic_scrap", "S": "scrap_metal"}, "flask_empty")
    shaped("vehicle_kit_buggy", ["WEW", "TFT", "WGW"], {"W": "wheel_worn", "E": "engine_part", "T": "duct_tape", "F": "car_frame", "G": "scrap_metal"}, "vehicle_kit_buggy")
    shaped("grenade", ["S", "G", "S"], {"S": "scrap_metal", "G": "minecraft:gunpowder"}, "grenade", 2)
    shaped("molotov", ["C", "B", "F"], {"C": "cloth_scrap", "B": "minecraft:glass_bottle", "F": "fuel_clean"}, "molotov")
    shapeless("bandage", ["cloth_scrap", "cloth_scrap"], "bandage")
    shapeless("clean_water_tablet", ["dirty_water", "water_tablet"], "clean_water")
    shapeless("canister_fuel", ["canister_empty", "fuel_clean", "fuel_clean"], "canister_fuel")
    shapeless("ammo_9mm", ["gold_casing", "minecraft:gunpowder", "scrap_metal"], "ammo_9mm", 6)
    shapeless("ammo_12g", ["gold_casing", "minecraft:gunpowder", "plastic_scrap"], "ammo_12g", 4)
    shaped("bandage_sterile", ["CAC"], {"C": "cloth_scrap", "A": "antiseptic"}, "bandage_sterile")
    shapeless("ammo_44", ["gold_casing", "minecraft:gunpowder", "lead_ingot"], "ammo_44", 6)
    shapeless("ammo_556", ["gold_casing", "minecraft:gunpowder", "copper_scrap"], "ammo_556", 6)
    shapeless("ammo_9mm_ap", ["ammo_9mm", "ammo_9mm", "steel_plate"], "ammo_9mm_ap", 2)
    shapeless("ammo_12g_slug", ["ammo_12g", "lead_ingot"], "ammo_12g_slug", 2)
    shaped("battery_medium", ["WCW", "SPS", "WCW"], {"W": "copper_wire", "C": "capacitor", "S": "steel_plate", "P": "plastic_scrap"}, "battery_medium")
    shaped("battery_large", ["CBC", "SBS", "CBC"], {"C": "capacitor", "B": "battery_medium", "S": "steel_plate"}, "battery_large")
    shaped("grenade_smoke", ["S", "C", "S"], {"S": "scrap_metal", "C": "chemicals"}, "grenade_smoke", 2)
    shaped("respirator", ["RRR", "PFP", "TTT"], {"R": "rubber", "P": "plastic_scrap", "F": "filter_basic", "T": "duct_tape"}, "respirator")
    shaped("flask_steel", ["S", "S"], {"S": "steel_plate"}, "flask_steel")
    shaped("repair_kit", ["TSB", "RLR"], {"T": "duct_tape", "S": "steel_plate", "B": "bolts_nuts", "R": "rope", "L": "lubricant"}, "repair_kit")
    shaped("filter_cartridge_a", ["PSP", "CCC", "PSP"], {"P": "plastic_scrap", "S": "steel_plate", "C": "charcoal_pills"}, "filter_cartridge_a")
    shapeless("canister_fuel_big", ["canister_empty_big", "fuel_clean", "fuel_clean", "fuel_clean", "fuel_clean"], "canister_fuel_big")
    # печь: очистка воды кипячением и очистка топлива
    for n, a, b, t in (("clean_water_boil", "dirty_water", "clean_water", 200), ("fuel_refine", "fuel_raw", "fuel_clean", 300)):
        write(f"{rd}/{n}.json", {"type": "minecraft:smelting", "category": "misc", "ingredient": {"item": item_ref(a)},
                                  "result": {"id": item_ref(b)}, "experience": 0.0, "cookingtime": t})
    # убираем ванильные инструменты
    dummy = {"neoforge:conditions": [{"type": "neoforge:false"}], "type": "minecraft:crafting_shapeless",
             "ingredients": [{"item": "minecraft:stick"}], "result": {"id": "minecraft:stick", "count": 1}}
    for mat in ("wooden", "stone", "iron", "golden", "diamond"):
        for tool in ("pickaxe", "axe", "shovel", "hoe", "sword"):
            write(f"{RES}/data/minecraft/recipe/{mat}_{tool}.json", dummy)
    for tool in ("pickaxe", "axe", "shovel", "hoe", "sword"):
        write(f"{RES}/data/minecraft/recipe/netherite_{tool}_smithing.json", dummy)
        write(f"{RES}/data/minecraft/recipe/netherite_{tool}.json", dummy)


def entry(item, w=1, cmin=1, cmax=1):
    e = {"type": "minecraft:item", "name": item_ref(item), "weight": w}
    if (cmin, cmax) != (1, 1):
        e["functions"] = [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": cmin, "max": cmax}}]
    return e


def table(pools):
    return {"type": "minecraft:chest", "pools": pools}


def pool(rmin, rmax, entries):
    return {"rolls": {"type": "minecraft:uniform", "min": rmin, "max": rmax}, "entries": entries}


def guaranteed(item, cmin=1, cmax=1):
    e = {"type": "minecraft:item", "name": item_ref(item)}
    if (cmin, cmax) != (1, 1):
        e["functions"] = [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": cmin, "max": cmax}}]
    return {"rolls": 1, "entries": [e]}


def blueprints(tiers=range(2, 8)):
    return [entry(f"blueprint_{machine_name(k, t)}", max(1, 9 - 2 * t)) for k, _, _ in KINDS for t in tiers]


def build_loot():
    ld = f"{D}/loot_table/chests"
    food = ["canned_stew", "canned_beans", "canned_fish", "canned_corn", "canned_peaches", "canned_pate", "condensed_milk", "crackers",
            "instant_noodles", "chocolate_bar", "candy", "cookies", "dried_meat", "sausage"]
    drinks = ["clean_water", "lemonade_lime", "lemonade_orange", "cola", "kvass", "juice_apple", "tea_cold", "beer", "dirty_water", "energy_drink"]
    meds = ["bandage", "painkillers", "medkit", "antirad_pills", "antidote", "stimulant"]
    junk = ["scrap_metal", "copper_wire", "circuit_board", "electronic_scrap", "plastic_scrap", "rubber", "duct_tape", "cloth_scrap", "gold_casing", "fuel_raw", "water_tablet"]
    ammo = ["ammo_9mm", "ammo_545", "ammo_762", "ammo_308", "ammo_12g"]
    # --- расширение: всё новое попадает в таблицы по категориям
    food = [r[0] for r in CONSUMABLES if r[3] == "food" and "ration_pack_mil" != r[0]]
    drinks = [r[0] for r in CONSUMABLES if r[3] == "drink"]
    meds = [r[0] for r in CONSUMABLES if r[3] == "med"]
    junk += ["lead_ingot", "steel_plate", "aluminium_scrap", "copper_scrap", "glass_shards", "nails", "bolts_nuts", "rope", "chemicals", "capacitor",
             "transistor", "microchip", "motor_small", "magnet", "lubricant", "primer_box", "gunpowder_pack", "magazine_empty"]
    ammo += ["ammo_44", "ammo_556", "ammo_9mm_ap", "ammo_12g_slug"]
    extra_melee = [r[0] for r in MELEE]
    extra_tools = [r[0] for r in TOOLS]
    extra_guns = [r[0] for r in GUNS]
    helmets = [r[0] for r in MISC if r[3] == "head" and r[0].startswith(("helmet", "cap", "ushanka"))]
    masks = ["gas_mask", "gas_mask_gp5", "gas_mask_gp7", "gas_mask_military", "respirator"]
    suits = [r[0] for r in MISC if r[0].startswith("hazmat_suit")]
    armor_all = [r[0] for r in MISC if r[3] in ("head", "chest", "legs", "feet") and r[0] not in masks + suits]
    filters_all = [r[0] for r in MISC if r[3] == "filter"]
    gear = ["flashlight_tactical", "flashlight_dynamo", "battery_medium", "battery_large", "lighter_zippo", "matches", "flask_steel", "flask_glass", "geiger_counter",
            "radio_handheld", "compass", "binoculars", "toolbox", "repair_kit", "backpack_scrap", "pouch_small"]
    lore = ["map_metro", "map_city", "book_survival", "book_medical", "book_engineering", "journal_old", "key_card", "key_rusty", "cigarettes", "playing_cards", "toy_old", "watch_wrist", "gold_casing_bundle"]
    write(f"{ld}/start_supplies.json", table([
        guaranteed("ration_pack", 2, 3), guaranteed("canned_stew", 1, 2), guaranteed("clean_water", 2, 3), guaranteed("lemonade_lime"),
        guaranteed("bandage", 2, 3), guaranteed("painkillers"), guaranteed("antirad_pills"), guaranteed("medkit"), guaranteed("water_tablet", 3, 5),
        guaranteed("note_old")]))
    write(f"{ld}/start_gear.json", table([
        guaranteed("gas_mask"), guaranteed("filter_basic", 2, 2), guaranteed("flashlight"), guaranteed("battery_small", 1, 2),
        guaranteed("knife_kitchen"), guaranteed("lighter"), guaranteed("pickaxe_rusty"), guaranteed("flask_empty")]))
    write(f"{ld}/metro_common.json", table([
        pool(2, 4, [entry(i, 6, 1, 3) for i in junk] + [entry(i, 5) for i in food[:6]] + [entry(i, 4) for i in drinks[:5]]),
        pool(0, 1, [entry(i, 3) for i in meds[:3]] + [entry("filter_basic", 3), entry("battery_small", 3), entry("ammo_9mm", 3, 4, 12)])]))
    write(f"{ld}/metro_rare.json", table([
        pool(2, 3, [entry(i, 4) for i in meds] + [entry("filter_advanced", 3), entry("flashlight", 2), entry("hazmat_suit", 1)]),
        pool(1, 2, [entry(i, 3, 6, 20) for i in ammo]),
        pool(0, 1, [entry(i, 2) for i in ("pistol_pm", "pistol_tt", "shotgun_toz", "machete", "pickaxe_miner")] + blueprints(range(2, 4)))]))
    write(f"{ld}/city_apartment.json", table([
        pool(2, 4, [entry(i, 5, 1, 2) for i in food + drinks] + [entry(i, 6, 1, 3) for i in junk]),
        pool(0, 1, [entry(i, 3) for i in meds[:3]] + [entry(i, 2) for i in ("knife_kitchen", "bat_wood", "lighter", "radio", "flashlight", "battery_small")])]))
    write(f"{ld}/city_medical.json", table([pool(3, 5, [entry(i, 6, 1, 3) for i in meds] + [entry("clean_water", 3, 1, 2)])]))
    write(f"{ld}/city_hospital.json", table([
        pool(3, 6, [entry(i, 6, 1, 3) for i in meds] + [entry("antirad_pills", 5, 1, 3), entry("hazmat_suit", 1)]),
        pool(0, 1, [entry("filter_advanced", 3), entry("gas_mask", 2)] + blueprints(range(2, 3)))]))
    write(f"{ld}/city_police.json", table([
        pool(2, 4, [entry(i, 5, 6, 20) for i in ("ammo_9mm", "ammo_762")] + [entry("bandage", 4, 1, 2), entry("flashlight", 3), entry("battery_small", 3)]),
        pool(1, 2, [entry("pistol_pm", 4), entry("pistol_tt", 3), entry("revolver_nagant", 3), entry("shotgun_pump", 2), entry("smg_pp", 1), entry("knife_combat", 3), entry("crowbar", 3)])]))
    write(f"{ld}/city_weapons.json", table([
        pool(2, 3, [entry(i, 4, 8, 24) for i in ammo]),
        pool(1, 2, [entry(r[0], 3) for r in GUNS] + [entry("grenade", 2, 1, 3), entry("molotov", 3, 1, 3), entry("katana", 1)])]))
    write(f"{ld}/city_fire.json", table([
        pool(2, 4, [entry("axe_fire", 3), entry("crowbar", 3), entry("hazmat_suit", 2), entry("gas_mask", 3), entry("filter_basic", 5, 1, 2), entry("medkit", 2),
                    entry("canister_empty", 3), entry("fuel_raw", 3, 1, 3), entry("rubber", 3, 2, 6), entry("flask_empty", 3)])]))
    write(f"{ld}/city_tools.json", table([
        pool(1, 3, [entry(i, 4) for i in ("pickaxe_rusty", "pickaxe_miner", "shovel_rusty", "shovel_sapper", "axe_hatchet", "hoe_garden", "sledgehammer", "crowbar")]
             + [entry(i, 5, 1, 4) for i in ("scrap_metal", "duct_tape", "engine_part", "wheel_worn", "car_frame")])]))
    write(f"{ld}/city_military.json", table([
        pool(2, 4, [entry(i, 5, 10, 32) for i in ammo]),
        pool(1, 3, [entry(r[0], 3) for r in GUNS if r[0].startswith(("rifle", "sniper", "smg"))] + [entry("grenade", 4, 2, 4), entry("filter_military", 4, 1, 2), entry("hazmat_suit", 3), entry("gas_mask", 3)]),
        pool(0, 1, blueprints(range(3, 6)))]))
    write(f"{ld}/city_lab.json", table([
        pool(2, 4, [entry(i, 5, 1, 3) for i in ("circuit_board", "electronic_scrap", "copper_wire", "battery_small", "antidote", "antirad_pills", "stimulant")]
             + [entry("filter_advanced", 3), entry("filter_military", 1), entry("hazmat_suit", 2)]),
        pool(1, 2, blueprints(range(2, 8)))]))
    write(f"{ld}/city_blueprints.json", table([pool(1, 2, blueprints(range(2, 8)) + [entry("note_old", 6)])]))
    def merge(name, extra_pools):
        p = f"{ld}/{name}.json"
        j = json.load(open(p, encoding="utf-8")); j["pools"] += extra_pools
        write(p, j)
    merge("metro_common", [pool(0, 2, [entry(i, 3) for i in food + drinks] + [entry(i, 2) for i in lore + gear[:8]])])
    merge("metro_rare", [pool(1, 2, [entry(i, 3) for i in armor_all + helmets + filters_all[:3]] + [entry(i, 2) for i in masks + gear[8:]] + [entry(i, 1) for i in extra_tools])])
    merge("city_apartment", [pool(0, 2, [entry(i, 3) for i in lore] + [entry(i, 2) for i in extra_melee[:6] + gear[:6]] + [entry(i, 3, 1, 2) for i in junk[-18:]])])
    merge("city_medical", [pool(1, 3, [entry(i, 3) for i in meds])])
    merge("city_hospital", [pool(1, 2, [entry("coat_lab", 3), entry("hazmat_suit_lab", 1), entry("book_medical", 2), entry("sedative", 3), entry("morphine", 2), entry("adrenaline", 2)])])
    merge("city_police", [pool(1, 2, [entry(i, 3) for i in ("vest_police", "helmet_riot", "baton", "pants_kevlar", "boots_tactical", "knife_throwing", "pistol_makarov_mod", "pistol_stechkin", "smg_kedr", "vest_kevlar", "key_card")])])
    merge("city_weapons", [pool(1, 2, [entry(i, 3) for i in extra_guns] + [entry(i, 2) for i in ("grenade_smoke", "grenade_frag_heavy", "molotov_improved")])])
    merge("city_fire", [pool(1, 3, [entry(i, 3) for i in ("vest_firefighter", "pants_firefighter", "helmet_steel", "boots_rubber", "axe_lumber", "pickaxe_pneumatic", "pickaxe_ice", "flashlight_tactical", "respirator", "filter_cartridge_a")])])
    merge("city_tools", [pool(1, 2, [entry(i, 3) for i in extra_tools + extra_melee[6:]])])
    merge("city_military", [pool(1, 3, [entry(i, 3) for i in ("helmet_military", "vest_heavy", "vest_tactical", "pants_military", "boots_army", "hazmat_suit_military", "gas_mask_military",
                                                               "medkit_military", "combat_stim", "filter_cartridge_c", "rifle_lmg", "sniper_dragunov_mod", "rifle_vss", "ammo_9mm_ap", "grenade_frag_heavy", "vehicle_kit_buggy_armored")])])
    merge("city_lab", [pool(1, 3, [entry(i, 3) for i in ("filter_lab", "hazmat_suit_lab", "hazmat_suit_mk2", "geiger_counter", "potassium_iodide", "rad_x", "display_screen", "microchip", "chemicals", "acid", "battery_acid", "book_engineering", "key_card")])])
    # --- всё, что ещё не лежит ни в одной таблице, раскидываем по тематике
    import re as _re
    placed = set()
    for _f in os.listdir(ld):
        placed |= set(_re.findall(r'undermetro:([a-z0-9_]+)', open(os.path.join(ld, _f), encoding="utf-8").read()))
    allitems = [r[0] for r in CONSUMABLES + MELEE + TOOLS + GUNS + MISC]
    rest = [i for i in allitems if i not in placed]
    techy = [i for i in rest if any(k in i for k in ("circuit", "processor", "power_cell", "solar", "relay", "fuse", "coil", "wire", "battery", "headlamp", "flashlight"))]
    car = [i for i in rest if any(k in i for k in ("piston", "gearbox", "axle", "spark", "radiator", "car_", "headlight", "steering", "seat", "armor_plate", "wheel", "generator_part", "turbine", "pump", "pipe_", "valve"))]
    chem = [i for i in rest if any(k in i for k in ("sulfur", "saltpeter", "alcohol", "solvent", "glue", "epoxy", "ore", "coal", "filter_", "gas_mask"))]
    camp = [i for i in rest if i not in techy + car + chem]
    merge("city_lab", [pool(0, 2, [entry(i, 3) for i in techy + chem])])
    merge("city_tools", [pool(0, 2, [entry(i, 3) for i in car])])
    merge("metro_rare", [pool(0, 2, [entry(i, 2) for i in camp + chem])])
    merge("city_apartment", [pool(0, 2, [entry(i, 2) for i in camp])])
    merge("city_military", [pool(0, 1, [entry(i, 2) for i in techy[:12] + chem[:6]])])
    # добыча с существ
    ed = f"{D}/loot_table/entities"
    def mob(name, entries):
        write(f"{ed}/{name}.json", {"type": "minecraft:entity", "pools": [pool(0, 2, entries)]})
    mob("shade", [entry("gold_casing", 3, 1, 2), entry("cloth_scrap", 3, 1, 2)])
    mob("crawler", [entry("gold_casing", 2), entry("plastic_scrap", 3)])
    mob("mutant", [entry("gold_casing", 3, 1, 3), entry("cloth_scrap", 3), entry("antirad_pills", 1)])
    mob("screecher", [entry("gold_casing", 2), entry("electronic_scrap", 2)])
    mob("leech", [entry("gold_casing", 2), entry("rubber", 3)])
    mob("marauder", [entry("gold_casing", 4, 1, 3), entry("ammo_9mm", 4, 2, 8), entry("bandage", 2), entry("canned_stew", 2), entry("scrap_metal", 2)])
    # блоки дропают себя
    for n in block_names():
        write(f"{D}/loot_table/blocks/{n}.json", {"type": "minecraft:block", "pools": [{"rolls": 1.0, "bonus_rolls": 0.0,
              "entries": [{"type": "minecraft:item", "name": item_ref(n)}], "conditions": [{"condition": "minecraft:survives_explosion"}]}],
              "random_sequence": f"{MOD}:blocks/{n}"})


def build_data_misc():
    tags = f"{D}/tags/item"
    write(f"{tags}/filters.json", {"values": [item_ref(r[0]) for r in MISC if r[3] == "filter"]})
    write(f"{tags}/rechargeable.json", {"values": [item_ref(r[0]) for r in MISC if r[3] in ("flashlight", "battery")]})
    write(f"{tags}/masks.json", {"values": [item_ref(r[0]) for r in MISC if r[0] in ("gas_mask", "gas_mask_gp5", "gas_mask_gp7", "gas_mask_military", "respirator")]})
    write(f"{tags}/hazmat.json", {"values": [item_ref(r[0]) for r in MISC if r[0].startswith("hazmat_suit")]})
    write(f"{tags}/digging_tools.json", {"values": [item_ref(r[0]) for r in TOOLS if r[3] == "pickaxe"]})
    write(f"{RES}/data/minecraft/tags/block/mineable/pickaxe.json", {"values": [item_ref(n) for n in block_names()]})
    write(f"{RES}/data/minecraft/tags/damage_type/bypasses_armor.json", {"values": [item_ref("radiation")]})
    write(f"{D}/damage_type/radiation.json", {"message_id": "radiation", "scaling": "never", "exhaustion": 0.0})
    write(f"{RES}/data/neoforge/data_maps/item/furnace_fuels.json", {"values": {item_ref("canister_fuel"): {"burn_time": 6400},
                                                                           item_ref("fuel_clean"): {"burn_time": 1600}, item_ref("fuel_raw"): {"burn_time": 800}}})
    for f in ("metro", "city"):
        write(f"{D}/worldgen/configured_feature/{f}.json", {"type": f"{MOD}:{f}", "config": {}})
        write(f"{D}/worldgen/placed_feature/{f}.json", {"feature": f"{MOD}:{f}", "placement": []})
        write(f"{D}/neoforge/biome_modifier/add_{f}.json", {"type": "neoforge:add_features", "biomes": "#minecraft:is_overworld",
                                                              "features": f"{MOD}:{f}", "step": "top_layer_modification"})
    def spawns(name, lst):
        write(f"{D}/neoforge/biome_modifier/spawns_{name}.json", {"type": "neoforge:add_spawns", "biomes": "#minecraft:is_overworld",
              "spawners": [{"type": f"{MOD}:{t}", "weight": w, "minCount": a, "maxCount": b} for (t, w, a, b) in lst]})
    spawns("monsters", [("shade", 70, 1, 3), ("crawler", 40, 1, 3), ("mutant", 50, 1, 4), ("screecher", 12, 1, 2), ("leech", 25, 1, 3), ("marauder", 8, 1, 3)])
    write(f"{D}/neoforge/biome_modifier/spawns_survivors.json", {"type": "neoforge:add_spawns", "biomes": "#minecraft:is_overworld",
          "spawners": {"type": f"{MOD}:survivor", "weight": 6, "minCount": 1, "maxCount": 2}})


def main():
    build_content_json()
    build_items_and_blocks()
    build_decor()
    write_entity_textures()
    build_lang()
    build_recipes()
    build_loot()
    build_data_misc()
    make_sounds()
    print("OK")


if __name__ == "__main__":
    main()
