package dev.undermetro.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.undermetro.ModEntities;
import dev.undermetro.ModRegistry;
import dev.undermetro.UnderMetro;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.PhantomRenderer;
import net.minecraft.client.renderer.entity.SpiderRenderer;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Phantom;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;

@EventBusSubscriber(modid = UnderMetro.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {

    private static ResourceLocation tex(String name) {
        return ResourceLocation.fromNamespaceAndPath(UnderMetro.MODID, "textures/entity/" + name + ".png");
    }

    /** Гуманоид на модели зомби/игрока с собственной текстурой. */
    static class HumanoidTex<T extends Mob> extends HumanoidMobRenderer<T, HumanoidModel<T>> {
        private final ResourceLocation texture;

        HumanoidTex(EntityRendererProvider.Context ctx, ModelLayerLocation layer, String name) {
            super(ctx, new HumanoidModel<>(ctx.bakeLayer(layer)), 0.5f);
            this.texture = tex(name);
        }

        @Override
        public ResourceLocation getTextureLocation(T entity) {
            return texture;
        }
    }

    /** Временная «заглушка» модели багги: блоки Minecraft, масштабированные в кузов и колёса. */
    static class BuggyRenderer extends EntityRenderer<ModEntities.RustBuggy> {
        private final EntityRendererProvider.Context ctx;

        BuggyRenderer(EntityRendererProvider.Context ctx) {
            super(ctx);
            this.ctx = ctx;
        }

        @Override
        public void render(ModEntities.RustBuggy e, float yaw, float partial, PoseStack ps, MultiBufferSource buf, int light) {
            ps.pushPose();
            ps.mulPose(Axis.YP.rotationDegrees(180f - yaw));
            var disp = ctx.getBlockRenderDispatcher();
            ps.pushPose();
            ps.translate(-0.7, 0.3, -1.1);
            ps.scale(1.4f, 0.5f, 2.2f);
            disp.renderSingleBlock(Blocks.IRON_BLOCK.defaultBlockState(), ps, buf, light, OverlayTexture.NO_OVERLAY);
            ps.popPose();
            ps.pushPose();
            ps.translate(-0.7, 0.8, -0.3);
            ps.scale(1.4f, 0.4f, 0.8f);
            disp.renderSingleBlock(Blocks.GLASS.defaultBlockState(), ps, buf, light, OverlayTexture.NO_OVERLAY);
            ps.popPose();
            for (int sx = -1; sx <= 1; sx += 2)
                for (int sz = -1; sz <= 1; sz += 2) {
                    ps.pushPose();
                    ps.translate(sx * 0.8 - 0.2, 0.0, sz * 0.7 - 0.2);
                    ps.scale(0.4f, 0.4f, 0.4f);
                    disp.renderSingleBlock(Blocks.BLACK_CONCRETE.defaultBlockState(), ps, buf, light, OverlayTexture.NO_OVERLAY);
                    ps.popPose();
                }
            ps.popPose();
            super.render(e, yaw, partial, ps, buf, light);
        }

        @Override
        public ResourceLocation getTextureLocation(ModEntities.RustBuggy e) {
            return TextureAtlas.LOCATION_BLOCKS;
        }
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModRegistry.SHADE.get(), ctx -> new HumanoidTex<ModEntities.Shade>(ctx, ModelLayers.ZOMBIE, "shade"));
        e.registerEntityRenderer(ModRegistry.MARAUDER.get(), ctx -> new HumanoidTex<ModEntities.Marauder>(ctx, ModelLayers.ZOMBIE, "marauder"));
        e.registerEntityRenderer(ModRegistry.SURVIVOR.get(), ctx -> new HumanoidTex<ModEntities.Survivor>(ctx, ModelLayers.ZOMBIE, "survivor"));

        e.registerEntityRenderer(ModRegistry.MUTANT.get(), ctx -> new ZombieRenderer(ctx) {
            @Override
            public ResourceLocation getTextureLocation(Zombie z) {
                return tex("mutant");
            }
        });
        e.registerEntityRenderer(ModRegistry.LEECH.get(), ctx -> new ZombieRenderer(ctx) {
            @Override
            public ResourceLocation getTextureLocation(Zombie z) {
                return tex("leech");
            }
        });
        e.registerEntityRenderer(ModRegistry.CRAWLER.get(), ctx -> new SpiderRenderer<ModEntities.Crawler>(ctx) {
            @Override
            public ResourceLocation getTextureLocation(ModEntities.Crawler s) {
                return tex("crawler");
            }
        });
        e.registerEntityRenderer(ModRegistry.SCREECHER.get(), ctx -> new PhantomRenderer(ctx) {
            @Override
            public ResourceLocation getTextureLocation(Phantom p) {
                return tex("screecher");
            }
        });
        e.registerEntityRenderer(ModRegistry.GRENADE.get(), ctx -> new ThrownItemRenderer<ModEntities.ThrownBomb>(ctx));
        e.registerEntityRenderer(ModRegistry.MOLOTOV.get(), ctx -> new ThrownItemRenderer<ModEntities.ThrownBomb>(ctx));
        e.registerEntityRenderer(ModRegistry.BUGGY.get(), BuggyRenderer::new);
    }

    @SubscribeEvent
    public static void guiLayers(RegisterGuiLayersEvent e) {
        e.registerAboveAll(ResourceLocation.fromNamespaceAndPath(UnderMetro.MODID, "survival_hud"), Hud::render);
    }

    private ClientSetup() {}
}
