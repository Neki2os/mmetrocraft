package dev.undermetro;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;

/** Универсальный блок электроники. kind определяет поведение, tier (1..7) — характеристики. */
public class MachineBlock extends Block implements EntityBlock {
    public enum Kind {
        GENERATOR, BATTERY, CABLE, LAMP, AIR_FILTER, WATER_FILTER, SENSOR, TURRET, ALARM, DOOR, HATCH;

        public String id() {
            return name().toLowerCase();
        }

        /** Нужен ли чертёж для уровней выше первого. */
        public boolean tiered() {
            return this != HATCH;
        }
    }

    public static final BooleanProperty LIT = BlockStateProperties.LIT;
    public static final BooleanProperty POWERED = BlockStateProperties.POWERED;
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;
    private static final VoxelShape OPEN_SHAPE = Block.box(0, 0, 14, 16, 16, 16);

    public static final MapCodec<MachineBlock> CODEC = simpleCodec(p -> new MachineBlock(p, Kind.CABLE, 1));

    public final Kind kind;
    public final int tier;

    public MachineBlock(Properties props, Kind kind, int tier) {
        super(props);
        this.kind = kind;
        this.tier = tier;
        registerDefaultState(stateDefinition.any().setValue(LIT, false).setValue(POWERED, false).setValue(OPEN, false));
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(LIT, POWERED, OPEN);
    }

    private boolean isDoorLike() {
        return kind == Kind.DOOR || kind == Kind.HATCH;
    }

    @Override
    protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
        return isDoorLike() && s.getValue(OPEN) ? OPEN_SHAPE : Shapes.block();
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
        return isDoorLike() && s.getValue(OPEN) ? Shapes.empty() : Shapes.block();
    }

    @Override
    protected boolean isSignalSource(BlockState state) {
        return kind == Kind.SENSOR;
    }

    @Override
    protected int getSignal(BlockState s, BlockGetter l, BlockPos p, net.minecraft.core.Direction d) {
        return kind == Kind.SENSOR && s.getValue(POWERED) ? 15 : 0;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return kind == Kind.HATCH ? null : new MachineBE(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide || kind == Kind.HATCH || type != ModRegistry.MACHINE_BE.get()) return null;
        return (lvl, pos, st, be) -> MachineBE.serverTick(lvl, pos, st, (MachineBE) be);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (isDoorLike()) {
            if (level.isClientSide) return InteractionResult.SUCCESS;
            if (kind == Kind.DOOR) {
                BlockEntity be = level.getBlockEntity(pos);
                if (!(be instanceof MachineBE m) || !m.energy.drain(Grade.doorCost(tier))) {
                    player.displayClientMessage(Component.translatable("msg.undermetro.no_power"), true);
                    return InteractionResult.CONSUME;
                }
            }
            boolean open = !state.getValue(OPEN);
            level.setBlock(pos, state.setValue(OPEN, open), 3);
            level.playSound(null, pos, open ? SoundEvents.IRON_DOOR_OPEN : SoundEvents.IRON_DOOR_CLOSE,
                    SoundSource.BLOCKS, 1f, 0.7f);
            return InteractionResult.CONSUME;
        }
        if (kind == Kind.BATTERY && !level.isClientSide) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof MachineBE m) {
                player.displayClientMessage(Component.translatable("msg.undermetro.energy",
                        m.energy.getEnergyStored(), m.energy.getMaxEnergyStored()), true);
            }
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        BlockEntity be = level.getBlockEntity(pos);
        if (!(be instanceof MachineBE m)) return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;

        // Генератор: засунуть топливо.
        if (kind == Kind.GENERATOR) {
            int burn = stack.getBurnTime(RecipeType.SMELTING);
            if (burn > 0) {
                if (!level.isClientSide && m.burn <= 0) {
                    m.burn = burn;
                    boolean canister = BuiltInRegistries_path(stack).equals("canister_fuel");
                    if (!player.isCreative()) stack.shrink(1);
                    if (canister) player.getInventory().add(new ItemStack(ModRegistry.item("canister_empty")));
                    m.setChanged();
                } else if (!level.isClientSide) {
                    player.displayClientMessage(Component.translatable("msg.undermetro.gen_busy"), true);
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
        }

        // Аккумулятор: зарядить батарейку / фонарик.
        if (kind == Kind.BATTERY && stack.isDamaged() && stack.is(ModRegistry.RECHARGEABLE)) {
            if (!level.isClientSide) {
                int missing = stack.getDamageValue();
                int canGive = m.energy.getEnergyStored() / Grade.FE_PER_CHARGE_POINT;
                int pts = Math.min(missing, Math.min(canGive, 200));
                if (pts > 0) {
                    m.energy.drain(pts * Grade.FE_PER_CHARGE_POINT);
                    stack.setDamageValue(stack.getDamageValue() - pts);
                    level.playSound(null, pos, SoundEvents.BEACON_POWER_SELECT, SoundSource.BLOCKS, 0.5f, 1.8f);
                } else {
                    player.displayClientMessage(Component.translatable("msg.undermetro.no_power"), true);
                }
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }

        // Фильтр воды: очистка заражённой воды.
        if (kind == Kind.WATER_FILTER && BuiltInRegistries_path(stack).equals("dirty_water")) {
            if (!level.isClientSide) {
                if (m.energy.drain(Grade.waterFilterCost(tier))) {
                    if (!player.isCreative()) stack.shrink(1);
                    ItemStack clean = new ItemStack(ModRegistry.item("clean_water"));
                    if (!player.getInventory().add(clean)) player.drop(clean, false);
                    level.playSound(null, pos, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 1f, 1f);
                } else {
                    player.displayClientMessage(Component.translatable("msg.undermetro.no_power"), true);
                }
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    private static String BuiltInRegistries_path(ItemStack s) {
        return net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
    }
}
