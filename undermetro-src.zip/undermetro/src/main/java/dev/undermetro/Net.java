package dev.undermetro;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/** Синхронизация статов игрока с клиентом (для HUD). */
@EventBusSubscriber(modid = UnderMetro.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class Net {

    /** Клиентская копия — обычные статические поля, без обращения к классам Minecraft-клиента. */
    public static final class ClientStats {
        public static int thirst = 100, stamina = 100, rad = 0, purity = 100;
        /** -1: фильтр не используется; иначе остаток 0..100. */
        public static int filter = -1;
        public static boolean mask = false;
        public static int[] skills = new int[5];
    }

    public record StatsPayload(int thirst, int stamina, int rad, int purity, int filter, boolean mask,
                               int[] skills) implements CustomPacketPayload {
        public static final Type<StatsPayload> TYPE =
                new Type<>(ResourceLocation.fromNamespaceAndPath(UnderMetro.MODID, "stats"));

        public static final StreamCodec<RegistryFriendlyByteBuf, StatsPayload> CODEC = StreamCodec.of(
                (buf, p) -> {
                    buf.writeVarInt(p.thirst);
                    buf.writeVarInt(p.stamina);
                    buf.writeVarInt(p.rad);
                    buf.writeVarInt(p.purity);
                    buf.writeVarInt(p.filter + 1);
                    buf.writeBoolean(p.mask);
                    for (int s : p.skills) buf.writeVarInt(s);
                },
                buf -> {
                    int th = buf.readVarInt(), st = buf.readVarInt(), ra = buf.readVarInt(), pu = buf.readVarInt();
                    int fi = buf.readVarInt() - 1;
                    boolean mask = buf.readBoolean();
                    int[] sk = new int[5];
                    for (int i = 0; i < 5; i++) sk[i] = buf.readVarInt();
                    return new StatsPayload(th, st, ra, pu, fi, mask, sk);
                });

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar reg = event.registrar("1");
        reg.playToClient(StatsPayload.TYPE, StatsPayload.CODEC, (payload, ctx) -> {
            ClientStats.thirst = payload.thirst();
            ClientStats.stamina = payload.stamina();
            ClientStats.rad = payload.rad();
            ClientStats.purity = payload.purity();
            ClientStats.filter = payload.filter();
            ClientStats.mask = payload.mask();
            ClientStats.skills = payload.skills();
        });
    }

    private Net() {}
}
