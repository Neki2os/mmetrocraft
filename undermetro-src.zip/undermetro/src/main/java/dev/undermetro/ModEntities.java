package dev.undermetro;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.InteractGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.LookAtTradingPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.ai.goal.TradeWithPlayerGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Phantom;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.monster.Spider;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/** Существа и транспорт. */
public final class ModEntities {

    // ------------------------------------------------------------------ монстры

    /** Тень метро: прячется от света, но не горит. Слепит при ударе. */
    public static class Shade extends Monster {
        public Shade(EntityType<? extends Shade> type, Level level) {
            super(type, level);
        }

        public static AttributeSupplier.Builder createAttributes() {
            return Monster.createMonsterAttributes()
                    .add(Attributes.MAX_HEALTH, 28)
                    .add(Attributes.ATTACK_DAMAGE, 6)
                    .add(Attributes.MOVEMENT_SPEED, 0.33)
                    .add(Attributes.FOLLOW_RANGE, 32);
        }

        @Override
        protected void registerGoals() {
            goalSelector.addGoal(0, new FloatGoal(this));
            goalSelector.addGoal(1, new FleeLightGoal(this));
            goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15, false));
            goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
            goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 10f));
            goalSelector.addGoal(7, new RandomLookAroundGoal(this));
            targetSelector.addGoal(1, new HurtByTargetGoal(this));
            targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        }

        @Override
        public boolean doHurtTarget(Entity target) {
            boolean ok = super.doHurtTarget(target);
            if (ok && target instanceof LivingEntity l) l.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60));
            return ok;
        }
    }

    /** Убегает в темноту, если стоит на свету (и не пытается атаковать пока ярко). */
    public static class FleeLightGoal extends Goal {
        private final net.minecraft.world.entity.PathfinderMob mob;
        private Vec3 target;

        public FleeLightGoal(net.minecraft.world.entity.PathfinderMob mob) {
            this.mob = mob;
            setFlags(EnumSet.of(Flag.MOVE));
        }

        private int light(BlockPos p) {
            return mob.level().getMaxLocalRawBrightness(p);
        }

        @Override
        public boolean canUse() {
            if (light(mob.blockPosition()) < 9) return false;
            for (int i = 0; i < 12; i++) {
                BlockPos p = mob.blockPosition().offset(mob.getRandom().nextInt(17) - 8,
                        mob.getRandom().nextInt(5) - 2, mob.getRandom().nextInt(17) - 8);
                if (light(p) <= 4 && mob.level().getBlockState(p.below()).isSolid()) {
                    target = Vec3.atBottomCenterOf(p);
                    return true;
                }
            }
            return false;
        }

        @Override
        public void start() {
            mob.getNavigation().moveTo(target.x, target.y, target.z, 1.4);
        }

        @Override
        public boolean canContinueToUse() {
            return !mob.getNavigation().isDone() && light(mob.blockPosition()) >= 9;
        }
    }

    /** Паукообразный: страдает от огня (x2.5 урона). */
    public static class Crawler extends Spider {
        public Crawler(EntityType<? extends Crawler> type, Level level) {
            super(type, level);
        }

        public static AttributeSupplier.Builder createAttributes() {
            return Spider.createAttributes().add(Attributes.MAX_HEALTH, 34).add(Attributes.ATTACK_DAMAGE, 4);
        }

        @Override
        public boolean hurt(DamageSource source, float amount) {
            if (source.is(DamageTypeTags.IS_FIRE)) amount *= 2.5f;
            return super.hurt(source, amount);
        }
    }

    /** Мутант поверхности: не горит на солнце, заражает радиацией при ударе. */
    public static class Mutant extends Zombie {
        public Mutant(EntityType<? extends Mutant> type, Level level) {
            super(type, level);
        }

        public static AttributeSupplier.Builder createAttributes() {
            return Zombie.createAttributes().add(Attributes.MAX_HEALTH, 42).add(Attributes.ATTACK_DAMAGE, 7)
                    .add(Attributes.FOLLOW_RANGE, 40);
        }

        @Override
        protected boolean isSunSensitive() {
            return false;
        }

        @Override
        public boolean doHurtTarget(Entity target) {
            boolean ok = super.doHurtTarget(target);
            if (ok && target instanceof Player p) PlayerStats.get(p).rad = Math.min(100f, PlayerStats.get(p).rad + 8f);
            return ok;
        }
    }

    /** Летающая тварь. Не горит днём. */
    public static class Screecher extends Phantom {
        public Screecher(EntityType<? extends Screecher> type, Level level) {
            super(type, level);
        }

        public static AttributeSupplier.Builder createAttributes() {
            return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 24).add(Attributes.ATTACK_DAMAGE, 5);
        }

        @Override
        public boolean isSunBurnTick() {
            return false;
        }
    }

    /** Водный мутант. */
    public static class Leech extends Zombie {
        public Leech(EntityType<? extends Leech> type, Level level) {
            super(type, level);
        }

        public static AttributeSupplier.Builder createAttributes() {
            return Zombie.createAttributes().add(Attributes.MAX_HEALTH, 30).add(Attributes.ATTACK_DAMAGE, 5)
                    .add(Attributes.MOVEMENT_SPEED, 0.3);
        }

        @Override
        protected boolean isSunSensitive() {
            return false;
        }

        @Override
        protected boolean convertsInWater() {
            return false;
        }
    }

    // ------------------------------------------------------------------ NPC

    /** Мародёр: стреляет из пистолета. */
    public static class Marauder extends Monster implements RangedAttackMob {
        public Marauder(EntityType<? extends Marauder> type, Level level) {
            super(type, level);
            setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModRegistry.item("pistol_pm")));
        }

        public static AttributeSupplier.Builder createAttributes() {
            return Monster.createMonsterAttributes().add(Attributes.MAX_HEALTH, 24).add(Attributes.MOVEMENT_SPEED, 0.28)
                    .add(Attributes.FOLLOW_RANGE, 28);
        }

        @Override
        protected void registerGoals() {
            goalSelector.addGoal(0, new FloatGoal(this));
            goalSelector.addGoal(2, new RangedAttackGoal(this, 1.0, 24, 16f));
            goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
            goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 12f));
            targetSelector.addGoal(1, new HurtByTargetGoal(this));
            targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        }

        @Override
        public void performRangedAttack(LivingEntity target, float velocity) {
            level().playSound(null, getX(), getY(), getZ(), ModRegistry.gunSound("pistol"), SoundSource.HOSTILE, 1.5f, 1f);
            if (random.nextFloat() < 0.65f) target.hurt(damageSources().mobAttack(this), 4f);
        }
    }

    /** Выживший: торгует (бартер / золотые гильзы). */
    public static class Survivor extends AbstractVillager {
        public Survivor(EntityType<? extends Survivor> type, Level level) {
            super(type, level);
        }

        public static AttributeSupplier.Builder createAttributes() {
            return net.minecraft.world.entity.Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 20)
                    .add(Attributes.MOVEMENT_SPEED, 0.5);
        }

        @Override
        protected void registerGoals() {
            goalSelector.addGoal(0, new FloatGoal(this));
            goalSelector.addGoal(1, new TradeWithPlayerGoal(this));
            goalSelector.addGoal(1, new LookAtTradingPlayerGoal(this));
            goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.5));
            goalSelector.addGoal(5, new InteractGoal(this, Player.class, 3f, 1f));
            goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8f));
        }

        @Override
        public InteractionResult mobInteract(Player player, InteractionHand hand) {
            if (isAlive() && !isTrading() && !isBaby()) {
                if (!level().isClientSide) {
                    if (getOffers().isEmpty()) return InteractionResult.PASS;
                    setTradingPlayer(player);
                    openTradingScreen(player, getDisplayName(), 1);
                }
                return InteractionResult.sidedSuccess(level().isClientSide);
            }
            return super.mobInteract(player, hand);
        }

        private void offer(String payId, int pay, String getId, int get, int uses) {
            getOffers().add(new MerchantOffer(new ItemCost(ModRegistry.item(payId), pay),
                    new ItemStack(ModRegistry.item(getId), get), uses, 2, 0.05f));
        }

        @Override
        protected void updateTrades() {
            // Золотые гильзы — валюта; бартер — «я тебе, ты мне».
            offer("gold_casing", 2, "clean_water", 1, 12);
            offer("gold_casing", 3, "canned_stew", 1, 8);
            offer("gold_casing", 5, "bandage", 1, 6);
            offer("gold_casing", 14, "filter_basic", 1, 4);
            offer("gold_casing", 6, "ammo_9mm", 8, 6);
            offer("gold_casing", 30, "medkit", 1, 2);
            offer("scrap_metal", 8, "gold_casing", 3, 10);
            offer("canned_stew", 2, "gold_casing", 3, 6);
        }

        @Override
        protected void rewardTradeXp(MerchantOffer offer) {
            if (offer.shouldRewardExp()) {
                level().addFreshEntity(new net.minecraft.world.entity.ExperienceOrb(level(), getX(), getY() + 0.5, getZ(),
                        3 + random.nextInt(4)));
            }
        }

        @Override
        public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob other) {
            return null;
        }
    }

    // ------------------------------------------------------------------ снаряды

    /** Граната и коктейль Молотова (разные EntityType, один класс). */
    public static class ThrownBomb extends ThrowableItemProjectile {
        public ThrownBomb(EntityType<? extends ThrownBomb> type, Level level) {
            super(type, level);
        }

        private boolean molotov() {
            return getType() == ModRegistry.MOLOTOV.get();
        }

        @Override
        protected Item getDefaultItem() {
            return ModRegistry.item(molotov() ? "molotov" : "grenade");
        }

        @Override
        protected void onHit(HitResult result) {
            super.onHit(result);
            if (level().isClientSide) return;
            if (molotov()) {
                BlockPos c = blockPosition();
                for (int dx = -2; dx <= 2; dx++)
                    for (int dz = -2; dz <= 2; dz++)
                        for (int dy = -1; dy <= 1; dy++) {
                            BlockPos p = c.offset(dx, dy, dz);
                            if (level().isEmptyBlock(p) && Blocks.FIRE.defaultBlockState().canSurvive(level(), p)
                                    && random.nextFloat() < 0.7f)
                                level().setBlockAndUpdate(p, Blocks.FIRE.defaultBlockState());
                        }
                for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(3)))
                    e.setRemainingFireTicks(160);
                level().playSound(null, getX(), getY(), getZ(), SoundEvents.GLASS_BREAK, SoundSource.NEUTRAL, 1f, 0.8f);
            } else {
                level().explode(this, getX(), getY(), getZ(), 2.8f, Level.ExplosionInteraction.NONE);
            }
            discard();
        }
    }

    // ------------------------------------------------------------------ транспорт

    /** Багги из обломков: ездит на топливе из канистр. */
    public static class RustBuggy extends Entity {
        public int fuel = 0;

        public RustBuggy(EntityType<? extends RustBuggy> type, Level level) {
            super(type, level);
        }

        @Override
        protected void defineSynchedData(SynchedEntityData.Builder builder) {}

        @Override
        protected void readAdditionalSaveData(CompoundTag tag) {
            fuel = tag.getInt("fuel");
        }

        @Override
        protected void addAdditionalSaveData(CompoundTag tag) {
            tag.putInt("fuel", fuel);
        }

        @Override
        public boolean isPickable() {
            return true;
        }

        @Override
        protected boolean canAddPassenger(Entity e) {
            return getPassengers().size() < 2;
        }

        @Override
        public LivingEntity getControllingPassenger() {
            return getFirstPassenger() instanceof LivingEntity l ? l : null;
        }

        @Override
        public InteractionResult interact(Player player, InteractionHand hand) {
            ItemStack held = player.getItemInHand(hand);
            if (held.is(ModRegistry.item("canister_fuel"))) {
                if (!level().isClientSide) {
                    fuel += 1200;
                    if (!player.isCreative()) {
                        held.shrink(1);
                        player.getInventory().add(new ItemStack(ModRegistry.item("canister_empty")));
                    }
                    player.displayClientMessage(Component.translatable("msg.undermetro.fuel", fuel / 20), true);
                }
                return InteractionResult.sidedSuccess(level().isClientSide);
            }
            if (!level().isClientSide) player.startRiding(this);
            return InteractionResult.sidedSuccess(level().isClientSide);
        }

        @Override
        public boolean hurt(DamageSource source, float amount) {
            if (level().isClientSide || isRemoved()) return true;
            if (source.getEntity() instanceof Player) {
                spawnAtLocation(new ItemStack(ModRegistry.item("scrap_metal"), 6));
                discard();
            }
            return true;
        }

        @Override
        public void tick() {
            super.tick();
            if (level().isClientSide) return;
            Vec3 dm = getDeltaMovement();
            LivingEntity pilot = getControllingPassenger();
            if (pilot != null && fuel > 0) {
                float z = pilot.zza, x = pilot.xxa;
                if (z != 0) {
                    double a = z > 0 ? 0.055 : -0.03;
                    double yaw = Math.toRadians(getYRot());
                    dm = dm.add(-Math.sin(yaw) * a, 0, Math.cos(yaw) * a);
                    fuel--;
                }
                if (x != 0) setYRot(getYRot() - x * 3.5f * (float) Math.min(1.0, dm.horizontalDistance() * 4));
                if (pilot instanceof ServerPlayer sp && tickCount % 20 == 0)
                    sp.displayClientMessage(Component.translatable("msg.undermetro.fuel", fuel / 20), true);
            }
            if (horizontalCollision && onGround()) dm = new Vec3(dm.x, 0.42, dm.z);
            dm = new Vec3(dm.x * 0.88, dm.y - 0.06, dm.z * 0.88);
            move(MoverType.SELF, dm);
            setDeltaMovement(onGround() ? new Vec3(dm.x, 0, dm.z) : dm);
        }
    }

    private ModEntities() {}
}
