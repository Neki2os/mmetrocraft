package dev.undermetro.client;

import dev.undermetro.Net.ClientStats;
import dev.undermetro.PlayerStats;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Древо навыков: 5 веток по 10 узлов; уровень растёт от использования. */
public class SkillScreen extends Screen {
    private static final int PW = 300, PH = 214;
    private static final int[] COLORS = {0xFFB5762E, 0xFF2F8FC0, 0xFFC0452E, 0xFF8AC03A, 0xFFC0B02E};
    /** Бонус за один уровень (число подставляется в %s вместе с суммой). */
    private static final int[] PER_LEVEL = {3, 5, 5, 6, 4};

    private int left, top;

    public SkillScreen() {
        super(Component.translatable("tab.undermetro.skills"));
    }

    @Override
    protected void init() {
        left = (width - PW) / 2;
        top = (height - PH) / 2 + 10;
        Tabs.add(this::addRenderableWidget, left, top - 22, 1);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderTransparentBackground(g);
        g.fill(left - 2, top - 2, left + PW + 2, top + PH + 2, 0xEE060606);
        g.fill(left, top, left + PW, top + PH, 0xF0151512);
        g.drawCenteredString(font, Component.translatable("ui.undermetro.skills_title"), left + PW / 2, top + 6, 0xFFD0C080);

        int rowH = 36;
        List<Component> tip = null;
        for (int s = 0; s < 5; s++) {
            int y = top + 24 + s * rowH;
            int lvl = ClientStats.skills[s];
            int pct = ClientStats.xpPct[s];
            g.drawString(font, Component.translatable("skill.undermetro." + PlayerStats.SKILL_NAMES[s]), left + 8, y, 0xFFE0E0D0, false);
            g.drawString(font, lvl + "/" + PlayerStats.MAX_LEVEL, left + PW - 8 - font.width(lvl + "/" + PlayerStats.MAX_LEVEL), y, COLORS[s], false);
            int x0 = left + 12, ny = y + 14;
            // линия ветки
            g.fill(x0 + 5, ny + 5, x0 + 5 + 9 * 27, ny + 7, 0xFF2A2A26);
            g.fill(x0 + 5, ny + 5, x0 + 5 + Math.max(0, lvl) * 27 - (lvl > 0 ? 27 : 0), ny + 7, COLORS[s]);
            for (int k = 0; k < PlayerStats.MAX_LEVEL; k++) {
                int nx = x0 + k * 27;
                boolean got = k < lvl, cur = k == lvl;
                g.fill(nx - 1, ny - 1, nx + 13, ny + 13, got ? 0xFF000000 : 0xFF0A0A0A);
                g.fill(nx, ny, nx + 12, ny + 12, got ? COLORS[s] : cur ? 0xFF3A3A32 : 0xFF202020);
                if (cur) {
                    int fh = 12 * pct / 100;
                    g.fill(nx, ny + 12 - fh, nx + 12, ny + 12, (COLORS[s] & 0x00FFFFFF) | 0x99000000);
                }
                String n = String.valueOf(k + 1);
                g.drawString(font, n, nx + 6 - font.width(n) / 2, ny + 2, got ? 0xFF101010 : 0xFF777770, false);
                if (mx >= nx && mx < nx + 13 && my >= ny && my < ny + 13) {
                    tip = new ArrayList<>();
                    tip.add(Component.translatable("skill.undermetro." + PlayerStats.SKILL_NAMES[s]).withStyle(st -> st.withColor(COLORS[0] & 0xFFFFFF)));
                    tip.add(Component.translatable("ui.undermetro.skill_node", k + 1, Component.translatable(
                            "skill.undermetro." + PlayerStats.SKILL_NAMES[s] + ".bonus", PER_LEVEL[s] * (k + 1))));
                    tip.add(Component.translatable("skill.undermetro." + PlayerStats.SKILL_NAMES[s] + ".how").withStyle(st -> st.withColor(0x909088)));
                    if (cur) tip.add(Component.translatable("ui.undermetro.skill_progress", pct));
                }
            }
        }
        super.render(g, mx, my, pt);
        if (tip != null) g.renderComponentTooltip(font, tip, mx, my);
    }
}
