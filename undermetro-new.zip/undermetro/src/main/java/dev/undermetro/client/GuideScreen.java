package dev.undermetro.client;

import dev.undermetro.Content;
import dev.undermetro.ModRegistry;
import dev.undermetro.UnderMetro;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Справочник: какие патроны к какому оружию подходят. */
public class GuideScreen extends Screen {
    private static final int PW = 300, PH = 214;
    private record Row(ItemStack icon, Component text, boolean header, Component sub) {}

    private int left, top;
    private double scroll = 0;
    private final List<Row> rows = new ArrayList<>();

    public GuideScreen() {
        super(Component.translatable("tab.undermetro.guide"));
    }

    @Override
    protected void init() {
        left = (width - PW) / 2;
        top = (height - PH) / 2 + 10;
        Tabs.add(this::addRenderableWidget, left, top - 22, 2);
        if (rows.isEmpty()) build();
    }

    private void build() {
        Map<String, List<Content.Gun>> by = new LinkedHashMap<>();
        for (Content.Gun gun : Content.GUNS) by.computeIfAbsent(gun.ammo(), k -> new ArrayList<>()).add(gun);
        for (var e : by.entrySet()) {
            String ammo = e.getKey();
            Item ai = item(ammo);
            if (ai == null) continue;
            List<String> variants = new ArrayList<>();
            for (Item it : BuiltInRegistries.ITEM) {
                var key = BuiltInRegistries.ITEM.getKey(it);
                if (key.getNamespace().equals(UnderMetro.MODID) && key.getPath().startsWith(ammo + "_"))
                    variants.add(new ItemStack(it).getHoverName().getString());
            }
            Component sub = variants.isEmpty() ? Component.empty()
                    : Component.translatable("ui.undermetro.variants", String.join(", ", variants));
            rows.add(new Row(new ItemStack(ai), new ItemStack(ai).getHoverName(), true, sub));
            for (Content.Gun gun : e.getValue()) {
                Item gi = item(gun.id());
                if (gi == null) continue;
                rows.add(new Row(new ItemStack(gi), new ItemStack(gi).getHoverName(), false,
                        Component.translatable("ui.undermetro.gun_stats", gun.mag(), String.valueOf(gun.damage()))));
            }
        }
    }

    private static Item item(String id) {
        try {
            return ModRegistry.item(id);
        } catch (RuntimeException ex) {
            return null;
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private int contentHeight() {
        int h = 0;
        for (Row r : rows) h += r.header ? 30 : 20;
        return h;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        double max = Math.max(0, contentHeight() - (PH - 30));
        scroll = Math.max(0, Math.min(max, scroll - sy * 18));
        return true;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderTransparentBackground(g);
        g.fill(left - 2, top - 2, left + PW + 2, top + PH + 2, 0xEE060606);
        g.fill(left, top, left + PW, top + PH, 0xF0151512);
        g.drawCenteredString(font, Component.translatable("ui.undermetro.guide_title"), left + PW / 2, top + 6, 0xFFD0C080);
        g.enableScissor(left, top + 20, left + PW, top + PH - 4);
        int y = top + 22 - (int) scroll;
        for (Row r : rows) {
            int h = r.header ? 30 : 20;
            if (y + h > top + 18 && y < top + PH) {
                if (r.header) {
                    g.fill(left + 4, y, left + PW - 4, y + 28, 0xFF2A2820);
                    g.renderItem(r.icon, left + 8, y + 6);
                    g.drawString(font, r.text, left + 30, y + 4, 0xFFE8C860, false);
                    if (!r.sub.getString().isEmpty()) g.drawString(font, r.sub, left + 30, y + 16, 0xFF909088, false);
                } else {
                    g.renderItem(r.icon, left + 22, y + 1);
                    g.drawString(font, r.text, left + 44, y + 2, 0xFFD0D0C8, false);
                    g.drawString(font, r.sub, left + PW - 8 - font.width(r.sub), y + 6, 0xFF888880, false);
                }
            }
            y += h;
        }
        g.disableScissor();
        super.render(g, mx, my, pt);
    }
}
