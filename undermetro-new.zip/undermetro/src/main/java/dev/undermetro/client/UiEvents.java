package dev.undermetro.client;

import dev.undermetro.Content;
import dev.undermetro.ModRegistry;
import dev.undermetro.UnderMetro;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

import java.util.ArrayList;
import java.util.List;

/** Вкладки в инвентаре и подсказки «какие патроны к какому оружию». */
@EventBusSubscriber(modid = UnderMetro.MODID, value = Dist.CLIENT)
public final class UiEvents {

    @SubscribeEvent
    public static void inventoryTabs(ScreenEvent.Init.Post e) {
        if (e.getScreen() instanceof InventoryScreen inv) {
            INV_BUTTONS.clear();
            Tabs.add(b -> { INV_BUTTONS.add(b); e.addListener(b); }, inv.getGuiLeft(), inv.getGuiTop() - 21, 0);
        }
    }

    private static final List<Button> INV_BUTTONS = new ArrayList<>();

    @SubscribeEvent
    public static void inventoryTabsRender(ScreenEvent.Render.Post e) {
        if (e.getScreen() instanceof InventoryScreen)
            for (Button b : INV_BUTTONS) b.render(e.getGuiGraphics(), e.getMouseX(), e.getMouseY(), e.getPartialTick());
    }

    @SubscribeEvent
    public static void tooltip(ItemTooltipEvent e) {
        ItemStack s = e.getItemStack();
        if (s.isEmpty()) return;
        var key = BuiltInRegistries.ITEM.getKey(s.getItem());
        if (!key.getNamespace().equals(UnderMetro.MODID)) return;
        String path = key.getPath();
        List<Component> t = e.getToolTip();
        Content.Gun gun = Content.GUN_BY_ID.get(path);
        if (gun != null) {
            try {
                t.add(1, Component.translatable("tip.undermetro.ammo", new ItemStack(ModRegistry.item(gun.ammo())).getHoverName())
                        .withStyle(st -> st.withColor(0xE8C860)));
            } catch (RuntimeException ignored) { }
            t.add(2, Component.translatable("tip.undermetro.gun_stats", gun.mag(), String.valueOf(gun.damage()), gun.range())
                    .withStyle(st -> st.withColor(0x909088)));
            return;
        }
        if (path.startsWith("ammo_")) {
            List<String> names = new ArrayList<>();
            for (Content.Gun g : Content.GUNS)
                if (path.equals(g.ammo()) || path.startsWith(g.ammo() + "_"))
                    names.add(new ItemStack(ModRegistry.item(g.id())).getHoverName().getString());
            if (!names.isEmpty())
                t.add(1, Component.translatable("tip.undermetro.fits", String.join(", ", names)).withStyle(st -> st.withColor(0xE8C860)));
        }
    }

    private UiEvents() {}
}
