package dev.undermetro.client;

import dev.undermetro.ModRegistry;
import dev.undermetro.UnderMetro;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.FogType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;

@EventBusSubscriber(modid = UnderMetro.MODID, value = Dist.CLIENT)
public final class ClientEvents {
    private static SoundInstance current;
    private static boolean currentSurface;
    private static int cooldown = 200;

    /** Прячем ванильные сердечки, ножки, пузырьки и броню — вместо них свой HUD. */
    @SubscribeEvent
    public static void hideVanilla(RenderGuiLayerEvent.Pre e) {
        var n = e.getName();
        if (n.equals(VanillaGuiLayers.PLAYER_HEALTH) || n.equals(VanillaGuiLayers.FOOD_LEVEL)
                || n.equals(VanillaGuiLayers.AIR_LEVEL) || n.equals(VanillaGuiLayers.ARMOR_LEVEL)) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && !mc.player.isCreative()) e.setCanceled(true);
        }
    }

    /** Мрачный туман в верхнем мире. */
    @SubscribeEvent
    public static void fog(ViewportEvent.RenderFog e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.level.dimension() != Level.OVERWORLD) return;
        if (e.getCamera().getFluidInCamera() != FogType.NONE) return;
        e.setNearPlaneDistance(0f);
        e.setFarPlaneDistance(Math.min(e.getFarPlaneDistance(), 70f));
        e.setCanceled(true);
    }

    @SubscribeEvent
    public static void fogColor(ViewportEvent.ComputeFogColor e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.level.dimension() != Level.OVERWORLD) return;
        if (e.getCamera().getFluidInCamera() != FogType.NONE) return;
        e.setRed(0.13f);
        e.setGreen(0.15f);
        e.setBlue(0.12f);
    }

    /** Свой эмбиент вместо ванильной музыки: под землёй мрачнее, на поверхности — со слабой надеждой. */
    @SubscribeEvent
    public static void keys(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null) return;
        while (ClientKeys.RELOAD.consumeClick())
            net.neoforged.neoforge.network.PacketDistributor.sendToServer(new dev.undermetro.Net.ActionPayload(dev.undermetro.Actions.RELOAD));
        while (ClientKeys.BATTERY.consumeClick())
            net.neoforged.neoforge.network.PacketDistributor.sendToServer(new dev.undermetro.Net.ActionPayload(dev.undermetro.Actions.BATTERY));
        while (ClientKeys.FILTER.consumeClick())
            net.neoforged.neoforge.network.PacketDistributor.sendToServer(new dev.undermetro.Net.ActionPayload(dev.undermetro.Actions.FILTER));
    }

    @SubscribeEvent
    public static void tick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.level.dimension() != Level.OVERWORLD) return;
        mc.getMusicManager().stopPlaying();
        boolean surface = mc.level.canSeeSky(mc.player.blockPosition());
        if (current != null && currentSurface != surface) {
            mc.getSoundManager().stop(current);
            current = null;
            cooldown = 40;
        }
        if (current == null || !mc.getSoundManager().isActive(current)) {
            current = null;
            if (cooldown-- <= 0) {
                currentSurface = surface;
                current = SimpleSoundInstance.forMusic(ModRegistry.SOUND_MAP.get(surface ? "amb_surface" : "amb_metro").get());
                mc.getSoundManager().play(current);
                cooldown = 400 + mc.level.random.nextInt(800);
            }
        }
    }

    private ClientEvents() {}
}
