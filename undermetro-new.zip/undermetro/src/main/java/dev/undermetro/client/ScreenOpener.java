package dev.undermetro.client;

import net.minecraft.client.Minecraft;

/** Единственная точка входа общего кода в клиентские экраны. */
public final class ScreenOpener {
    public static void openGuide() { Minecraft.getInstance().setScreen(new GuideScreen()); }
    public static void openSkills() { Minecraft.getInstance().setScreen(new SkillScreen()); }
    private ScreenOpener() {}
}
