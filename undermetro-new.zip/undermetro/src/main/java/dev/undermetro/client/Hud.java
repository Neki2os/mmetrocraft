package dev.undermetro.client;

import dev.undermetro.Net.ClientStats;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;

/** Мрачные полоски 0..100 в левом нижнем углу; полоска фильтра противогаза — в правом нижнем. */
public final class Hud {
    private static final int W = 90, H = 7, GAP = 4;

    private record Bar(String key, int value, int color) {}

    public static void render(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (p == null || mc.options.hideGui || p.isSpectator() || p.isCreative()) return;

        java.util.List<Bar> bars = new java.util.ArrayList<>();
        bars.add(new Bar("hp", Math.round(p.getHealth() / p.getMaxHealth() * 100f), 0xFF9B1C1C));
        bars.add(new Bar("food", p.getFoodData().getFoodLevel() * 5, 0xFF9A6B2F));
        bars.add(new Bar("thirst", ClientStats.thirst, 0xFF2F6F9A));
        bars.add(new Bar("stamina", ClientStats.stamina, 0xFF6B8E3A));
        if (p.getAirSupply() < p.getMaxAirSupply())
            bars.add(new Bar("air", Math.max(0, p.getAirSupply() * 100 / p.getMaxAirSupply()), 0xFF5AAFC8));
        if (ClientStats.rad > 0) bars.add(new Bar("rad", ClientStats.rad, 0xFF7DBE2A));

        int h = g.guiHeight();
        int y = h - 12;
        for (Bar b : bars) {
            drawBar(g, mc, 8, y, b.value, b.color, Component.translatable("hud.undermetro." + b.key).getString());
            y -= H + GAP;
        }

        // Патроны: магазин / запас в инвентаре
        var held = p.getMainHandItem();
        if (held.getItem() instanceof dev.undermetro.ModItems.GunItem gun) {
            int mag = held.getOrDefault(dev.undermetro.ModRegistry.AMMO.get(), 0);
            String txt = mag + " / " + gun.capacity() + "  [" + gun.reserve(p) + "]";
            int tw = mc.font.width(txt);
            int ax = g.guiWidth() - tw - 12;
            int ay = h - 36;
            g.fill(ax - 4, ay - 3, ax + tw + 4, ay + 11, 0xAA0B0B0B);
            g.drawString(mc.font, txt, ax, ay, mag == 0 ? 0xFFB03030 : 0xFFD0C080, true);
        }

        // Фильтр противогаза: показывается, пока воздух отравлен.
        if (ClientStats.mask && ClientStats.filter >= 0) {
            drawBar(g, mc, g.guiWidth() - W - 28, h - 12, ClientStats.filter, 0xFFC8B33A,
                    Component.translatable("hud.undermetro.filter").getString());
        }

        // Виньетка противогаза.
        if (ClientStats.mask && mc.options.getCameraType().isFirstPerson()) {
            int w = g.guiWidth();
            int e = Math.max(14, w / 14);
            g.fill(0, 0, w, e, 0x99000000);
            g.fill(0, h - e, w, h, 0x99000000);
            g.fill(0, e, e, h - e, 0x99000000);
            g.fill(w - e, e, w, h - e, 0x99000000);
        }
    }

    private static void drawBar(GuiGraphics g, Minecraft mc, int x, int y, int value, int color, String label) {
        int v = Math.max(0, Math.min(100, value));
        g.fill(x - 1, y - 1, x + W + 1, y + H + 1, 0xCC0B0B0B);
        g.fill(x, y, x + W, y + H, 0xFF1C1C1C);
        g.fill(x, y, x + W * v / 100, y + H, color);
        g.fill(x, y + H - 2, x + W * v / 100, y + H, 0x55000000);
        g.drawString(mc.font, String.valueOf(v), x + W + 4, y, 0xFFB0B0B0, true);
        g.drawString(mc.font, label, x + 2, y - 9, 0xFF808080, false);
    }

    private Hud() {}
}
