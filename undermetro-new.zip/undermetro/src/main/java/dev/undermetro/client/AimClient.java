package dev.undermetro.client;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.undermetro.Actions;
import dev.undermetro.ModItems;
import dev.undermetro.Net;
import dev.undermetro.UnderMetro;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ComputeFovModifierEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.network.PacketDistributor;

/** Прицеливание (ПКМ), стрельба (ЛКМ), оптический оверлей, виджет счётчика Гейгера. */
@EventBusSubscriber(modid = UnderMetro.MODID, value = Dist.CLIENT)
public final class AimClient {
    private static float aim = 0f, aimPrev = 0f;
    private static boolean attackWasDown = false;
    private static float needle = 0f;
    private static int tickN = 0;
    private static boolean binocActive = false;

    public static ModItems.GunItem heldGun(Player p) {
        if (p.getMainHandItem().getItem() instanceof ModItems.GunItem g) return g;
        if (p.getOffhandItem().getItem() instanceof ModItems.GunItem g) return g;
        return null;
    }

    public static float aimProgress(float pt) {
        return aimPrev + (aim - aimPrev) * pt;
    }

    @SubscribeEvent
    public static void tick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        tickN++;
        Player p = mc.player;
        aimPrev = aim;
        if (p == null) { aim = 0; return; }
        ModItems.GunItem gun = heldGun(p);
        boolean binoc = isItem(p.getMainHandItem(), "binoculars") || isItem(p.getOffhandItem(), "binoculars");
        binocActive = binoc && mc.screen == null && mc.options.keyUse.isDown();
        boolean want = (gun != null || binoc) && mc.screen == null && mc.options.keyUse.isDown() && !p.isSprinting();
        aim = want ? Math.min(1f, aim + 0.25f) : Math.max(0f, aim - 0.25f);

        // стрельба
        if (gun != null && mc.screen == null) {
            boolean down = mc.options.keyAttack.isDown();
            boolean fire = gun.isAuto() ? down : (down && !attackWasDown);
            if (fire) PacketDistributor.sendToServer(new Net.ActionPayload(Actions.SHOOT, aim > 0.6f ? 1 : 0));
            attackWasDown = down;
        } else {
            attackWasDown = false;
        }

        // стрелка счётчика Гейгера — плавно + дрожание
        float target = Math.min(1f, Net.ClientStats.dose / 600f);
        float jitter = (float) (Math.sin(tickN * 1.7) * 0.03 + (Math.random() - 0.5) * 0.06 * (0.3 + target));
        needle += (target + jitter - needle) * 0.2f;
    }

    /** ЛКМ с оружием в руках не бьёт и не ломает блоки — это выстрел. */
    @SubscribeEvent
    public static void interaction(InputEvent.InteractionKeyMappingTriggered e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null && heldGun(mc.player) != null && (e.isAttack() || e.isUseItem())) {
            e.setSwingHand(false);
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void fov(ComputeFovModifierEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        ModItems.GunItem gun = heldGun(mc.player);
        if ((gun == null && !binocActive) || aim <= 0f) return;
        float t = aimProgress(1f);
        float z = gun != null ? gun.zoom(mc.player) : 0.2f;
        e.setNewFovModifier(e.getNewFovModifier() * (1f + (z - 1f) * t));
    }

    @SubscribeEvent
    public static void crosshair(RenderGuiLayerEvent.Pre e) {
        if (!e.getName().equals(VanillaGuiLayers.CROSSHAIR)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        ModItems.GunItem gun = heldGun(mc.player);
        if (gun != null && aim > 0.5f && gun.scoped(mc.player)) e.setCanceled(true);
    }

    /** Чёрный оверлей оптического прицела. */
    public static void scope(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (p == null || mc.options.hideGui || !mc.options.getCameraType().isFirstPerson()) return;
        ModItems.GunItem gun = heldGun(p);
        float t = aimProgress(dt.getGameTimeDeltaPartialTick(false));
        if (gun == null || t < 0.7f || !gun.scoped(p)) return;
        int w = g.guiWidth(), h = g.guiHeight();
        int r = (int) (h * 0.46f);
        int cx = w / 2, cy = h / 2;
        // чёрные поля вокруг круга: строки без экономии, круг считается по горизонтали
        for (int y = 0; y < h; y++) {
            int dy = y - cy;
            if (Math.abs(dy) >= r) { g.fill(0, y, w, y + 1, 0xFF000000); continue; }
            int half = (int) Math.sqrt((double) r * r - (double) dy * dy);
            g.fill(0, y, cx - half, y + 1, 0xFF000000);
            g.fill(cx + half, y, w, y + 1, 0xFF000000);
        }
        // перекрестие
        g.fill(cx - r, cy, cx + r, cy + 1, 0xCC000000);
        g.fill(cx, cy - r, cx + 1, cy + r, 0xCC000000);
        g.fill(cx - 3, cy - 3, cx + 4, cy + 4, 0x00000000);
        for (int i = 1; i <= 4; i++) g.fill(cx - 3, cy + i * 12, cx + 4, cy + i * 12 + 1, 0xCC000000);
    }

    /** Виджет счётчика Гейгера: циферблат с дрожащей стрелкой, лента развёртки, мигающая лампа. */
    public static void geiger(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (p == null || mc.options.hideGui) return;
        boolean has = isGeiger(p.getMainHandItem()) || isGeiger(p.getOffhandItem());
        if (!has) return;
        int dose = Net.ClientStats.dose;
        int x = g.guiWidth() - 118, y = g.guiHeight() - 100, w = 106, hh = 54;
        g.fill(x - 2, y - 2, x + w + 2, y + hh + 2, 0xDD0B0B0B);
        g.fill(x, y, x + w, y + hh, 0xFF0E2214);
        // шкала
        for (int i = 0; i <= 10; i++) {
            double a = Math.toRadians(200 - i * 22);
            int ox = x + w / 2, oy = y + hh - 4;
            int len = i % 5 == 0 ? 8 : 5;
            for (int k = 0; k < len; k++) {
                int px = (int) (ox + Math.cos(a) * (40 - k)), py = (int) (oy - Math.sin(a) * (40 - k));
                g.fill(px, py, px + 1, py + 1, i >= 7 ? 0xFFD04030 : 0xFF3FBF6A);
            }
        }
        // стрелка
        double a = Math.toRadians(200 - Math.max(0f, Math.min(1f, needle)) * 220);
        int ox = x + w / 2, oy = y + hh - 4;
        for (int k = 0; k < 36; k++) {
            int px = (int) (ox + Math.cos(a) * k), py = (int) (oy - Math.sin(a) * k);
            g.fill(px, py, px + 1, py + 1, 0xFFE8E070);
        }
        // развёртка (скан среды)
        int sx = x + (tickN * 2) % w;
        g.fill(sx, y, sx + 1, y + hh, 0x5535E07A);
        g.fill(Math.max(x, sx - 3), y, sx, y + hh, 0x2235E07A);
        // лампа тревоги
        boolean blink = dose > 120 && (tickN / 4) % 2 == 0;
        g.fill(x + w - 9, y + 3, x + w - 3, y + 9, blink ? 0xFFFF3A2A : 0xFF3A0F0C);
        String txt = dose + " µSv";
        g.drawString(mc.font, txt, x + 4, y + 3, 0xFF6BE08A, false);
        String st = dose < 60 ? "норма" : dose < 200 ? "повышен" : dose < 400 ? "ОПАСНО" : "СМЕРТЕЛЬНО";
        g.drawString(mc.font, Component.literal(st), x + 4, y + hh - 11, dose < 60 ? 0xFF6BE08A : 0xFFE08A3A, false);
    }

    private static boolean isItem(ItemStack s, String id) {
        return !s.isEmpty() && BuiltInRegistries.ITEM.getKey(s.getItem()).getPath().equals(id);
    }

    private static boolean isGeiger(ItemStack s) {
        return !s.isEmpty() && BuiltInRegistries.ITEM.getKey(s.getItem()).getPath().equals("geiger_counter");
    }

    private AimClient() {}
}
