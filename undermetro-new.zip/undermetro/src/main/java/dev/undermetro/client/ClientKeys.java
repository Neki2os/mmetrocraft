package dev.undermetro.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.undermetro.UnderMetro;
import net.minecraft.client.KeyMapping;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;

/** Привязки клавиш (раздел «Under Metro» в настройках управления). */
@EventBusSubscriber(modid = UnderMetro.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientKeys {
    public static final String CATEGORY = "key.categories.undermetro";
    public static final KeyMapping RELOAD = new KeyMapping("key.undermetro.reload", InputConstants.KEY_R, CATEGORY);
    public static final KeyMapping BATTERY = new KeyMapping("key.undermetro.battery", InputConstants.KEY_B, CATEGORY);
    public static final KeyMapping FILTER = new KeyMapping("key.undermetro.filter", InputConstants.KEY_V, CATEGORY);

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent e) {
        e.register(RELOAD);
        e.register(BATTERY);
        e.register(FILTER);
    }

    private ClientKeys() {}
}
