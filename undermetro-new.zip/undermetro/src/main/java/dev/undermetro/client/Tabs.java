package dev.undermetro.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;

import java.util.function.Consumer;

/** Вкладки «Инвентарь / Навыки / Справочник» над окном инвентаря. */
public final class Tabs {
    public static void add(Consumer<Button> adder, int x, int y, int active) {
        String[] keys = {"tab.undermetro.inventory", "tab.undermetro.skills", "tab.undermetro.guide"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            Button b = Button.builder(Component.translatable(keys[i]), btn -> {
                Minecraft mc = Minecraft.getInstance();
                if (mc.player == null) return;
                switch (idx) {
                    case 0 -> mc.setScreen(new InventoryScreen(mc.player));
                    case 1 -> mc.setScreen(new SkillScreen());
                    default -> mc.setScreen(new GuideScreen());
                }
            }).bounds(x + i * 74, y, 72, 18).build();
            b.active = idx != active;
            adder.accept(b);
        }
    }

    private Tabs() {}
}
