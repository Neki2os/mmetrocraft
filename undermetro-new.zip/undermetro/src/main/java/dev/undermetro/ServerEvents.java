package dev.undermetro;

import dev.undermetro.worldgen.MetroFeature;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.FinalizeSpawnEvent;
import net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/** Серверная логика выживания: жажда, выносливость, воздух, радиация, ограничения ломания, подмена спавна. */
@EventBusSubscriber(modid = UnderMetro.MODID)
public final class ServerEvents {
    public static final ResourceKey<DamageType> RADIATION =
            ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.fromNamespaceAndPath(UnderMetro.MODID, "radiation"));

    private static DamageSource radiation(ServerLevel level) {
        Holder<DamageType> h = level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(RADIATION);
        return new DamageSource(h);
    }

    // ------------------------------------------------------------------ мир

    @SubscribeEvent
    public static void serverStarted(ServerStartedEvent e) {
        ServerLevel ow = e.getServer().overworld();
        ow.getGameRules().getRule(GameRules.RULE_SPAWN_RADIUS).set(0, e.getServer());
        ow.setDefaultSpawnPos(MetroFeature.SPAWN_POS, 0f);
    }

    /** Ванильных монстров в мире нет (кроме яиц/команд). */
    @SubscribeEvent
    public static void finalizeSpawn(FinalizeSpawnEvent e) {
        var type = e.getEntity().getType();
        if (type.getCategory() != MobCategory.MONSTER) return;
        if (!BuiltInRegistries.ENTITY_TYPE.getKey(type).getNamespace().equals("minecraft")) return;
        MobSpawnType t = e.getSpawnType();
        if (t == MobSpawnType.COMMAND || t == MobSpawnType.SPAWN_EGG || t == MobSpawnType.DISPENSER) return;
        e.setSpawnCancelled(true);
    }

    /** Каменные и прочие «кирочные» блоки голыми руками не ломаются. */
    @SubscribeEvent
    public static void breakSpeed(PlayerEvent.BreakSpeed e) {
        var p = e.getEntity();
        if (p.isCreative()) return;
        if (e.getState().is(BlockTags.MINEABLE_WITH_PICKAXE) && !p.getMainHandItem().is(ModRegistry.DIGGING_TOOLS)) {
            e.setNewSpeed(0f);
        }
    }

    // ------------------------------------------------------------------ игрок

    @SubscribeEvent
    public static void login(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        PlayerStats st = PlayerStats.get(p);
        if (st.spawned) return;
        st.spawned = true;
        ServerLevel ow = p.getServer().overworld();
        BlockPos s = MetroFeature.SPAWN_POS;
        ow.getChunk(s.getX() >> 4, s.getZ() >> 4); // принудительно сгенерировать стартовую комнату
        p.teleportTo(s.getX() + 0.5, s.getY(), s.getZ() + 0.5);
        p.setRespawnPosition(Level.OVERWORLD, s, 0f, true, false);
    }

    @SubscribeEvent
    public static void respawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.isEndConquered() || !(e.getEntity() instanceof ServerPlayer p)) return;
        PlayerStats st = PlayerStats.get(p);
        st.thirst = 100f;
        st.stamina = 100f;
        st.rad = 0f;
        st.purity = 100f;
    }

    @SubscribeEvent
    public static void incomingDamage(LivingIncomingDamageEvent e) {
        if (e.getSource().getEntity() instanceof ServerPlayer p && e.getSource().getDirectEntity() == p) {
            PlayerStats st = PlayerStats.get(p);
            e.setAmount(e.getAmount() * (1f + 0.05f * st.level[PlayerStats.STRENGTH]));
            st.addXp(p, PlayerStats.STRENGTH, 3f);
        }
    }

    @SubscribeEvent
    public static void useFinish(LivingEntityUseItemEvent.Finish e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        ResourceLocation key = BuiltInRegistries.ITEM.getKey(e.getItem().getItem());
        if (!key.getNamespace().equals(UnderMetro.MODID)) return;
        Content.Consumable c = Content.CONSUMABLE_BY_ID.get(key.getPath());
        if (c == null) return;
        PlayerStats st = PlayerStats.get(p);
        st.thirst = Math.max(0f, Math.min(100f, st.thirst + c.thirst()));
        st.rad = Math.max(0f, st.rad - c.antirad());
        if (c.health() > 0) p.heal(c.health());
        for (Content.Fx fx : c.fx()) {
            Holder<MobEffect> eff = effect(fx.effect());
            if (eff != null) p.addEffect(new MobEffectInstance(eff, fx.duration(), fx.amplifier()));
        }
    }

    private static Holder<MobEffect> effect(String name) {
        return switch (name) {
            case "nausea" -> MobEffects.CONFUSION;
            case "poison" -> MobEffects.POISON;
            case "slowness" -> MobEffects.MOVEMENT_SLOWDOWN;
            case "regen" -> MobEffects.REGENERATION;
            case "speed" -> MobEffects.MOVEMENT_SPEED;
            case "hunger" -> MobEffects.HUNGER;
            case "strength" -> MobEffects.DAMAGE_BOOST;
            case "weakness" -> MobEffects.WEAKNESS;
            case "blindness" -> MobEffects.BLINDNESS;
            case "resistance" -> MobEffects.DAMAGE_RESISTANCE;
            default -> null;
        };
    }

    // ------------------------------------------------------------------ тик

    @SubscribeEvent
    public static void playerTick(PlayerTickEvent.Post e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || p.isSpectator()) return;
        PlayerStats st = PlayerStats.get(p);

        // Выносливость (каждый тик).
        if (!p.isCreative()) {
            if (p.isSprinting()) {
                st.stamina = Math.max(0f, st.stamina - 0.33f * (1f - 0.04f * st.level[PlayerStats.STAMINA]));
                if (p.tickCount % 20 == 0) st.addXp(p, PlayerStats.STAMINA, 2f);
                if (st.stamina <= 0f) p.setSprinting(false);
            } else {
                st.stamina = Math.min(100f, st.stamina + 0.22f + 0.02f * st.level[PlayerStats.STAMINA]);
            }
        }

        // щелчки счётчика Гейгера: чаще при высокой дозе
        if (st.dose > 0 && p.tickCount % 2 == 0 && (isItem(p.getMainHandItem(), "geiger_counter") || isItem(p.getOffhandItem(), "geiger_counter"))
                && p.getRandom().nextInt(700) < st.dose)
            p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.UI_BUTTON_CLICK.value(), SoundSource.PLAYERS, 0.35f,
                    1.7f + p.getRandom().nextFloat() * 0.5f);
        if (p.tickCount % 20 == 0) secondly(p, st);
        if (p.tickCount % 10 == 0) sync(p, st);
    }

    private static boolean isItem(ItemStack s, String id) {
        return !s.isEmpty() && s.is(ModRegistry.item(id));
    }

    private static void secondly(ServerPlayer p, PlayerStats st) {
        ServerLevel level = p.serverLevel();
        boolean survival = !p.isCreative();

        // --- фонарик: ночное зрение пока держишь заряженный фонарик
        for (ItemStack hand : new ItemStack[]{p.getMainHandItem(), p.getOffhandItem()}) {
            if (isItem(hand, "flashlight") && hand.getDamageValue() < hand.getMaxDamage() - 1) {
                p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 240, 0, true, false, false));
                if (survival && p.tickCount % 40 == 0) hand.setDamageValue(hand.getDamageValue() + 1);
                break;
            }
        }

        // --- жажда и голод
        if (survival) {
            float drain = 0.085f * (p.isSprinting() ? 2f : 1f) * (1f - 0.05f * st.level[PlayerStats.THIRST]);
            st.thirst = Math.max(0f, st.thirst - drain);
            if (st.thirst <= 0f && p.tickCount % 40 == 0) p.hurt(level.damageSources().starve(), 1f);
            if (st.thirst <= 40f) st.addXp(p, PlayerStats.THIRST, 1f);
            if (p.getFoodData().getFoodLevel() <= 8) st.addXp(p, PlayerStats.HUNGER, 1f);
            int hl = st.level[PlayerStats.HUNGER];
            if (hl > 0 && p.getFoodData().getFoodLevel() < 20 && p.getRandom().nextFloat() < 0.03f * hl)
                p.getFoodData().eat(1, 0f);
        }

        // --- счётчик Гейгера в руке
        for (ItemStack hand : new ItemStack[]{p.getMainHandItem(), p.getOffhandItem()}) {
            if (isItem(hand, "geiger_counter")) {
                st.dose = Math.round((100f - st.purity) * 4f + st.rad * 2f) + (p.serverLevel().isRainingAt(p.blockPosition()) ? 150 : 0);
                break;
            }
        }

        // --- воздух
        boolean maskOn = p.getItemBySlot(EquipmentSlot.HEAD).is(ModRegistry.MASKS);
        int filterPct = -1;
        boolean exposed = false;
        if (survival) {
            int code = AirLogic.scan(level, BlockPos.containing(p.getEyePosition()));
            if (code == AirLogic.SEALED_FILTERED) st.purity = Math.min(100f, st.purity + 25f);
            else if (code == AirLogic.OPEN) st.purity = Math.max(0f, st.purity - 12f);
            // SEALED без фильтра: воздух не меняется

            // Фильтр, установленный в противогаз (клавиша «сменить фильтр»), показывается на HUD всегда
            ItemStack head = p.getItemBySlot(EquipmentSlot.HEAD);
            String kind = maskOn ? head.get(ModRegistry.FILTER_KIND.get()) : null;
            boolean hasFilter = kind != null && !kind.isEmpty();
            int fMax = 1, fUsed = 0;
            if (hasFilter) {
                fMax = Math.max(1, new ItemStack(BuiltInRegistries.ITEM.get(
                        ResourceLocation.fromNamespaceAndPath(UnderMetro.MODID, kind))).getMaxDamage());
                fUsed = head.getOrDefault(ModRegistry.FILTER_USED.get(), 0);
                filterPct = Math.max(0, (fMax - fUsed) * 100 / fMax);
            }
            if (st.purity < 35f) {
                if (hasFilter) {
                    fUsed++;
                    if (fUsed >= fMax) {
                        head.remove(ModRegistry.FILTER_KIND.get());
                        head.remove(ModRegistry.FILTER_USED.get());
                        filterPct = 0;
                        p.displayClientMessage(Component.translatable("msg.undermetro.filter_spent"), true);
                    } else {
                        head.set(ModRegistry.FILTER_USED.get(), fUsed);
                        filterPct = Math.max(0, (fMax - fUsed) * 100 / fMax);
                    }
                } else {
                    exposed = true;
                    p.hurt(radiation(level), 1.5f);
                    st.rad = Math.min(100f, st.rad + 3f);
                    p.displayClientMessage(Component.translatable(maskOn ? "msg.undermetro.no_filter" : "msg.undermetro.toxic_air"), true);
                }
            }

            // --- дождь
            if (level.isRainingAt(p.blockPosition()) && !p.getItemBySlot(EquipmentSlot.CHEST).is(ModRegistry.HAZMAT)) {
                exposed = true;
                st.rad = Math.min(100f, st.rad + 4f);
                p.displayClientMessage(Component.translatable("msg.undermetro.rain"), true);
            }

            // --- заражение
            if (!exposed) st.rad = Math.max(0f, st.rad - 0.3f);
            if (st.rad >= 50f) p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 0, true, false, true));
            if (st.rad >= 75f) p.hurt(radiation(level), 1f);
        } else {
            st.purity = 100f;
        }
        st.filterPct = filterPct;
    }

    private static int[] xpPct(PlayerStats st) {
        int[] r = new int[5];
        for (int i = 0; i < 5; i++)
            r[i] = st.level[i] >= PlayerStats.MAX_LEVEL ? 100 : Math.round(100f * st.xp[i] / PlayerStats.xpNeeded(st.level[i]));
        return r;
    }

    private static void sync(ServerPlayer p, PlayerStats st) {
        boolean maskOn = p.getItemBySlot(EquipmentSlot.HEAD).is(ModRegistry.MASKS);
        PacketDistributor.sendToPlayer(p, new Net.StatsPayload(Math.round(st.thirst), Math.round(st.stamina),
                Math.round(st.rad), Math.round(st.purity), st.filterPct, maskOn, st.level.clone(), xpPct(st), st.dose));
    }

    private ServerEvents() {}
}
