package dev.undermetro;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.EnergyStorage;
import net.neoforged.neoforge.energy.IEnergyStorage;

import java.util.Comparator;
import java.util.List;

public class MachineBE extends BlockEntity {

    /** Накопитель энергии с внутренним доступом (минуя лимиты приёма/отдачи). */
    public static class Store extends EnergyStorage {
        public Store(int capacity, int maxIn, int maxOut) {
            super(capacity, maxIn, maxOut);
        }

        public int addInternal(int n) {
            int add = Math.min(capacity - energy, n);
            energy += add;
            return add;
        }

        /** Списать ровно n; если энергии не хватает — ничего не списывается и возвращается false. */
        public boolean drain(int n) {
            if (energy < n) return false;
            energy -= n;
            return true;
        }
    }

    public final MachineBlock.Kind kind;
    public final int tier;
    public final Store energy;
    public int burn = 0;
    // --- гидропонная грядка
    public String crop = "";
    public int progress = 0;
    public int water = 0;
    public static final int GROW_TIME = 4800;
    private int tickCounter = 0;

    public MachineBE(BlockPos pos, BlockState state) {
        super(ModRegistry.MACHINE_BE.get(), pos, state);
        MachineBlock mb = (MachineBlock) state.getBlock();
        this.kind = mb.kind;
        this.tier = mb.tier;
        int rate = Grade.cableRate(tier);
        switch (kind) {
            case GENERATOR -> energy = new Store(Grade.generatorOutput(tier) * 40, 0, Grade.generatorOutput(tier) * 2);
            case BATTERY -> energy = new Store(Grade.batteryCapacity(tier), Grade.batteryRate(tier), Grade.batteryRate(tier));
            case CABLE -> energy = new Store(rate * 2, rate, rate);
            default -> energy = new Store(2000 * tier, Math.max(100, 40 * tier), 0);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put("energy", energy.serializeNBT(registries));
        tag.putInt("burn", burn);
        tag.putString("crop", crop);
        tag.putInt("progress", progress);
        tag.putInt("water", water);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        if (tag.contains("energy")) energy.deserializeNBT(registries, tag.get("energy"));
        burn = tag.getInt("burn");
        crop = tag.getString("crop");
        progress = tag.getInt("progress");
        water = tag.getInt("water");
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, MachineBE be) {
        be.tickCounter++;
        switch (be.kind) {
            case GENERATOR -> {
                boolean lit = be.burn > 0;
                if (lit) {
                    be.burn--;
                    be.energy.addInternal(Grade.generatorOutput(be.tier));
                }
                be.setLit(level, pos, state, lit);
                be.push(level, pos);
            }
            case BATTERY, CABLE -> be.push(level, pos);
            case LAMP -> be.setLit(level, pos, state, be.energy.drain(Grade.lampCost(be.tier)));
            case AIR_FILTER -> be.setLit(level, pos, state, be.energy.drain(Grade.airFilterCost(be.tier)));
            case SENSOR -> {
                if (be.tickCounter % 20 == 0) {
                    boolean powered = be.energy.drain(Grade.sensorCost(be.tier) * 20);
                    boolean sealed = false;
                    if (powered) {
                        for (Direction d : Direction.values()) {
                            BlockPos n = pos.relative(d);
                            if (level.getBlockState(n).getCollisionShape(level, n).isEmpty()) {
                                sealed = AirLogic.scan(level, n) != AirLogic.OPEN;
                                break;
                            }
                        }
                    }
                    if (state.getValue(MachineBlock.POWERED) != sealed) {
                        level.setBlock(pos, state.setValue(MachineBlock.POWERED, sealed), 3);
                        level.updateNeighborsAt(pos, state.getBlock());
                    }
                }
            }
            case GROW_TRAY -> {
                boolean growing = !be.crop.isEmpty() && be.water > 0 && be.progress < GROW_TIME;
                if (growing && be.energy.drain(Grade.lampCost(be.tier) * 2)) {
                    be.progress += be.tier;
                    if (be.progress >= GROW_TIME) be.setChanged();
                } else {
                    growing = false;
                }
                be.setLit(level, pos, state, growing);
            }
            case TURRET -> {
                if (be.tickCounter % 10 == 0) be.turretTick((ServerLevel) level, pos);
            }
            case ALARM -> {
                if (be.tickCounter % 40 == 0) {
                    boolean alarm = false;
                    if (be.energy.getEnergyStored() >= Grade.alarmCost(be.tier) * 40) {
                        int r = Grade.alarmRange(be.tier);
                        alarm = !level.getEntitiesOfClass(LivingEntity.class, new AABB(pos).inflate(r),
                                e -> e instanceof Enemy && e.isAlive()).isEmpty();
                    }
                    if (alarm) {
                        be.energy.drain(Grade.alarmCost(be.tier) * 40);
                        level.playSound(null, pos, SoundEvents.BELL_BLOCK, SoundSource.BLOCKS, 4f, 0.5f);
                    }
                    be.setLit(level, pos, state, alarm);
                }
            }
            default -> {}
        }
    }

    private void setLit(Level level, BlockPos pos, BlockState state, boolean lit) {
        if (state.getValue(MachineBlock.LIT) != lit) level.setBlock(pos, state.setValue(MachineBlock.LIT, lit), 3);
    }

    /** Раздача энергии соседям. Накопители отдают только «вниз по градиенту», чтобы не гонять туда-сюда. */
    private void push(Level level, BlockPos pos) {
        int myStored = energy.getEnergyStored();
        if (myStored <= 0) return;
        float myFrac = myStored / (float) energy.getMaxEnergyStored();
        for (Direction d : Direction.values()) {
            IEnergyStorage nb = level.getCapability(Capabilities.EnergyStorage.BLOCK, pos.relative(d), d.getOpposite());
            if (nb == null || !nb.canReceive()) continue;
            if (nb.canExtract()) {
                float nbFrac = nb.getEnergyStored() / (float) Math.max(1, nb.getMaxEnergyStored());
                if (nbFrac >= myFrac) continue;
            }
            int send = energy.extractEnergy(energy.getEnergyStored(), true);
            int accepted = nb.receiveEnergy(send, false);
            energy.extractEnergy(accepted, false);
            if (energy.getEnergyStored() <= 0) break;
        }
        setChanged();
    }

    private void turretTick(ServerLevel level, BlockPos pos) {
        int cost = Grade.turretCost(tier);
        if (energy.getEnergyStored() < cost) return;
        double range = Grade.turretRange(tier);
        Vec3 from = Vec3.atCenterOf(pos).add(0, 0.6, 0);
        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, new AABB(pos).inflate(range),
                e -> e instanceof Enemy && e.isAlive());
        targets.sort(Comparator.comparingDouble(e -> e.distanceToSqr(from)));
        for (LivingEntity t : targets) {
            Vec3 to = t.getEyePosition();
            var hit = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE,
                    net.minecraft.world.phys.shapes.CollisionContext.empty()));
            if (hit.getType() != HitResult.Type.MISS && hit.getLocation().distanceToSqr(to) > 1.0) continue;
            energy.drain(cost);
            t.invulnerableTime = 0;
            t.hurt(level.damageSources().generic(), Grade.turretDamage(tier));
            Vec3 d = to.subtract(from);
            for (double s = 0.5; s < d.length(); s += 1.5) {
                Vec3 p = from.add(d.normalize().scale(s));
                level.sendParticles(ParticleTypes.CRIT, p.x, p.y, p.z, 1, 0, 0, 0, 0);
            }
            level.playSound(null, pos, SoundEvents.CROSSBOW_SHOOT, SoundSource.BLOCKS, 1.2f, 1.7f);
            return;
        }
    }

    // ------------------------------------------------------------------ гидропонная грядка

    private static String cropOfSeed(String itemPath) {
        return switch (itemPath) {
            case "seed_potato" -> "potato";
            case "seed_cabbage" -> "cabbage";
            case "seed_mushroom" -> "mushroom";
            default -> "";
        };
    }

    /** Предмет в руке: семена (посадить), чистая вода (долить), удобрение (ускорить). Возвращает true, если что-то произошло. */
    public boolean trayUseItem(net.minecraft.world.entity.player.Player player, net.minecraft.world.item.ItemStack stack) {
        String path = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(stack.getItem()).getPath();
        String seedCrop = cropOfSeed(path);
        if (!seedCrop.isEmpty()) {
            if (!crop.isEmpty()) {
                player.displayClientMessage(net.minecraft.network.chat.Component.translatable("msg.undermetro.tray_busy"), true);
                return false;
            }
            crop = seedCrop;
            progress = 0;
            if (!player.isCreative()) stack.shrink(1);
            setChanged();
            return true;
        }
        if (path.equals("clean_water") || path.equals("mineral_water") || path.equals("sparkling_water")) {
            if (water >= 12) {
                player.displayClientMessage(net.minecraft.network.chat.Component.translatable("msg.undermetro.tray_water_full"), true);
                return false;
            }
            water = Math.min(12, water + 4);
            if (!player.isCreative()) {
                stack.shrink(1);
                net.minecraft.world.item.ItemStack bottle = new net.minecraft.world.item.ItemStack(ModRegistry.item("flask_glass"));
                if (!player.getInventory().add(bottle)) player.drop(bottle, false);
            }
            setChanged();
            return true;
        }
        if (path.equals("fertilizer")) {
            if (crop.isEmpty() || progress >= GROW_TIME) return false;
            progress = Math.min(GROW_TIME, progress + 1500);
            if (!player.isCreative()) stack.shrink(1);
            setChanged();
            return true;
        }
        trayStatus(player);
        return false;
    }

    /** Пустая рука: собрать урожай (если созрел) или показать состояние. */
    public void trayInteract(net.minecraft.world.entity.player.Player player) {
        if (!crop.isEmpty() && progress >= GROW_TIME) {
            String itemId = switch (crop) {
                case "potato" -> "potato";
                case "cabbage" -> "cabbage";
                default -> "mushroom_champignon";
            };
            int count = 2 + tier + level.random.nextInt(2);
            net.minecraft.world.item.ItemStack out = new net.minecraft.world.item.ItemStack(ModRegistry.item(itemId), count);
            if (!player.getInventory().add(out)) player.drop(out, false);
            // автоматически «пересаживаем» ту же культуру, расходуя воду
            progress = 0;
            water = Math.max(0, water - 1);
            if (water == 0) crop = "";
            setChanged();
            player.displayClientMessage(net.minecraft.network.chat.Component.translatable("msg.undermetro.harvested", count), true);
            return;
        }
        trayStatus(player);
    }

    private void trayStatus(net.minecraft.world.entity.player.Player player) {
        if (crop.isEmpty()) {
            player.displayClientMessage(net.minecraft.network.chat.Component.translatable("msg.undermetro.tray_empty", water), true);
        } else {
            player.displayClientMessage(net.minecraft.network.chat.Component.translatable("msg.undermetro.tray_status",
                    net.minecraft.network.chat.Component.translatable("crop.undermetro." + crop), progress * 100 / GROW_TIME, water), true);
        }
    }
}
