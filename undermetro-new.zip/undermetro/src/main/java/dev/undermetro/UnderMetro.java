package dev.undermetro;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;

@Mod(UnderMetro.MODID)
public class UnderMetro {
    public static final String MODID = "undermetro";

    public UnderMetro(IEventBus modBus, ModContainer container) {
        ModRegistry.register(modBus);
    }
}
