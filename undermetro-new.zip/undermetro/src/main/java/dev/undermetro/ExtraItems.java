package dev.undermetro;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.FishingRodItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.List;

/** Предметы и блоки с поведением: часы, радио, ремонт, спальники, сигнальные шашки, лор, ловушки, лутовые ящики. */
public final class ExtraItems {

    /** Фабрика предмета по id; null — обычный предмет. */
    public static Item create(String id, Item.Properties p) {
        return switch (id) {
            case "ammo_guide" -> new GuideItem(p);
            case "note_old", "vodka_crate_note", "journal_old", "book_survival", "book_medical", "book_engineering",
                 "map_metro", "map_city", "tape_cassette", "toy_old", "playing_cards", "walkman" -> new LoreItem(p, id);
            case "watch_wrist", "watch_gold" -> new ClockItem(p);
            case "radio", "radio_handheld" -> new RadioItem(p);
            case "repair_kit" -> new RepairItem(p, 0.35f, false, true);
            case "toolbox" -> new RepairItem(p, 0.5f, false, false);
            case "cleaning_kit" -> new RepairItem(p, 0.3f, true, true);
            case "gun_oil" -> new RepairItem(p, 0.15f, true, true);
            case "sleeping_bag" -> new SleepItem(p, false);
            case "tent_pack" -> new SleepItem(p, true);
            case "signal_flare" -> new FlareItem(p);
            case "compass" -> new CompassItem(p);
            case "fishing_rod" -> new FishingRodItem(new Item.Properties().durability(90));
            case "trap_bear" -> new net.minecraft.world.item.BlockItem(ModRegistry.TRAP_BEAR.get(), p);
            case "trap_snare" -> new net.minecraft.world.item.BlockItem(ModRegistry.TRAP_SNARE.get(), p);
            case "mine_tripwire" -> new net.minecraft.world.item.BlockItem(ModRegistry.MINE_TRIPWIRE.get(), p);
            case "candle" -> new net.minecraft.world.item.BlockItem(ModRegistry.CANDLE.get(), p);
            case "lantern_oil" -> new net.minecraft.world.item.BlockItem(ModRegistry.LANTERN.get(), p);
            default -> null;
        };
    }

    public static final class GuideItem extends Item {
        public GuideItem(Properties p) { super(p); }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            if (level.isClientSide) dev.undermetro.client.ScreenOpener.openGuide();
            return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
        }
    }

    public static final class LoreItem extends Item {
        private final String id;
        public LoreItem(Properties p, String id) { super(p); this.id = id; }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            if (!level.isClientSide) {
                String raw = Component.translatable("lore.undermetro." + id).getString();
                player.displayClientMessage(Component.translatable("item.undermetro." + id).withStyle(s -> s.withBold(true).withColor(0xC8B890)), false);
                for (String line : raw.split("\\|")) player.displayClientMessage(Component.literal(line.trim()).withStyle(s -> s.withItalic(true).withColor(0xA89F88)), false);
            }
            return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
        }
    }

    public static final class ClockItem extends Item {
        public ClockItem(Properties p) { super(p); }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            if (!level.isClientSide) {
                long t = level.getDayTime();
                int h = (int) ((t % 24000) / 1000 + 6) % 24;
                int m = (int) ((t % 1000) * 60 / 1000);
                player.displayClientMessage(Component.translatable("msg.undermetro.clock", String.format("%02d:%02d", h, m), t / 24000 + 1), true);
            }
            return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
        }
    }

    public static final class RadioItem extends Item {
        public RadioItem(Properties p) { super(p); }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            if (!level.isClientSide) {
                if (player.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.fail(player.getItemInHand(hand));
                player.getCooldowns().addCooldown(this, 80);
                int n = 1 + level.random.nextInt(10);
                level.playSound(null, player.blockPosition(), SoundEvents.NOTE_BLOCK_BIT.value(), SoundSource.PLAYERS, 0.5f, 0.5f + level.random.nextFloat());
                player.displayClientMessage(Component.translatable("msg.undermetro.radio_static").withStyle(s -> s.withColor(0x777777)), false);
                player.displayClientMessage(Component.translatable("radio.undermetro." + n).withStyle(s -> s.withColor(0x9FD0A0).withItalic(true)), false);
            }
            return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
        }
    }

    /** Ремонт предмета в другой руке (или первого подходящего в инвентаре). */
    public static final class RepairItem extends Item {
        private final float frac;
        private final boolean gunsOnly, consumed;
        public RepairItem(Properties p, float frac, boolean gunsOnly, boolean consumed) {
            super(p); this.frac = frac; this.gunsOnly = gunsOnly; this.consumed = consumed;
        }

        private boolean ok(ItemStack s) {
            if (s.isEmpty() || !s.isDamaged() || s.getItem() instanceof RepairItem) return false;
            return !gunsOnly || s.getItem() instanceof ModItems.GunItem;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack self = player.getItemInHand(hand);
            if (level.isClientSide) return InteractionResultHolder.sidedSuccess(self, true);
            if (player.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.fail(self);
            ItemStack target = player.getItemInHand(hand == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
            if (!ok(target)) {
                target = ItemStack.EMPTY;
                for (ItemStack s : player.getInventory().items) if (ok(s)) { target = s; break; }
                if (target.isEmpty()) for (ItemStack s : player.getInventory().armor) if (ok(s)) { target = s; break; }
            }
            if (target.isEmpty()) {
                player.displayClientMessage(Component.translatable("msg.undermetro.nothing_to_repair"), true);
                return InteractionResultHolder.fail(self);
            }
            int heal = Math.max(1, (int) (target.getMaxDamage() * frac));
            target.setDamageValue(Math.max(0, target.getDamageValue() - heal));
            level.playSound(null, player.blockPosition(), SoundEvents.ANVIL_USE, SoundSource.PLAYERS, 0.4f, 1.6f);
            if (consumed && !player.isCreative()) self.shrink(1);
            else player.getCooldowns().addCooldown(this, 1200);
            player.displayClientMessage(Component.translatable("msg.undermetro.repaired", target.getHoverName()), true);
            return InteractionResultHolder.consume(self);
        }
    }

    /** Спальник/палатка: ПКМ по блоку — точка возрождения и отдых. */
    public static final class SleepItem extends Item {
        private final boolean tent;
        public SleepItem(Properties p, boolean tent) { super(p.stacksTo(1)); this.tent = tent; }

        @Override
        public InteractionResult useOn(UseOnContext ctx) {
            Level level = ctx.getLevel();
            if (level.isClientSide) return InteractionResult.SUCCESS;
            if (!(ctx.getPlayer() instanceof ServerPlayer sp)) return InteractionResult.PASS;
            if (sp.getCooldowns().isOnCooldown(this)) return InteractionResult.FAIL;
            BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
            sp.setRespawnPosition(level.dimension(), pos, sp.getYRot(), true, false);
            PlayerStats st = PlayerStats.get(sp);
            st.stamina = 100f;
            if (tent) {
                sp.heal(6f);
                st.rad = Math.max(0f, st.rad - 15f);
            }
            sp.getCooldowns().addCooldown(this, 2400);
            level.playSound(null, pos, SoundEvents.WOOL_PLACE, SoundSource.PLAYERS, 1f, 0.8f);
            sp.displayClientMessage(Component.translatable("msg.undermetro.camp_set"), true);
            return InteractionResult.CONSUME;
        }
    }

    public static final class FlareItem extends Item {
        public FlareItem(Properties p) { super(p); }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack s = player.getItemInHand(hand);
            if (level.isClientSide) return InteractionResultHolder.sidedSuccess(s, true);
            ServerLevel sl = (ServerLevel) level;
            Vec3 at = player.getEyePosition().add(player.getViewVector(1f).scale(3));
            sl.sendParticles(ParticleTypes.FLAME, at.x, at.y + 1, at.z, 60, 0.4, 1.5, 0.4, 0.05);
            sl.sendParticles(ParticleTypes.LAVA, at.x, at.y + 1, at.z, 10, 0.3, 0.5, 0.3, 0);
            sl.playSound(null, player.blockPosition(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 1f, 0.6f);
            List<LivingEntity> near = sl.getEntitiesOfClass(LivingEntity.class, new AABB(player.blockPosition()).inflate(26), e -> e != player);
            for (LivingEntity e : near) e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 300, 0));
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 300, 0, true, false));
            if (!player.isCreative()) s.shrink(1);
            return InteractionResultHolder.consume(s);
        }
    }

    public static final class CompassItem extends Item {
        public CompassItem(Properties p) { super(p); }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            if (!level.isClientSide) {
                Direction d = player.getDirection();
                String key = switch (d) { case NORTH -> "n"; case SOUTH -> "s"; case EAST -> "e"; default -> "w"; };
                BlockPos b = player.blockPosition();
                player.displayClientMessage(Component.translatable("msg.undermetro.compass", Component.translatable("dir.undermetro." + key), b.getX(), b.getY(), b.getZ()), true);
            }
            return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
        }
    }

    // ================================================================= БЛОКИ
    public static final BooleanProperty SNAPPED = BooleanProperty.create("snapped");

    /** Ловушки: капкан, петля, растяжка. */
    public static class TrapBlock extends Block {
        public enum Type { BEAR, SNARE, MINE }
        private static final VoxelShape SHAPE = Block.box(1, 0, 1, 15, 3, 15);
        private final Type type;
        private final String itemId;

        public TrapBlock(Properties p, Type type, String itemId) {
            super(p);
            this.type = type;
            this.itemId = itemId;
            registerDefaultState(stateDefinition.any().setValue(SNAPPED, false));
        }

        @Override
        protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) { b.add(SNAPPED); }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) { return SHAPE; }

        @Override
        protected boolean canSurvive(BlockState s, LevelReader l, BlockPos p) {
            return Block.canSupportCenter(l, p.below(), Direction.UP);
        }

        @Override
        protected BlockState updateShape(BlockState s, Direction d, BlockState n, net.minecraft.world.level.LevelAccessor l, BlockPos p, BlockPos np) {
            return !s.canSurvive(l, p) ? net.minecraft.world.level.block.Blocks.AIR.defaultBlockState() : s;
        }

        @Override
        protected void entityInside(BlockState state, Level level, BlockPos pos, Entity e) {
            if (level.isClientSide || !(e instanceof LivingEntity le) || e.isSteppingCarefully()) return;
            switch (type) {
                case BEAR -> {
                    if (state.getValue(SNAPPED)) return;
                    le.hurt(level.damageSources().generic(), 9f);
                    le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 140, 4));
                    level.setBlock(pos, state.setValue(SNAPPED, true), 3);
                    level.playSound(null, pos, SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.BLOCKS, 1f, 0.5f);
                }
                case SNARE -> {
                    le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 3));
                    le.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 1));
                }
                case MINE -> {
                    level.removeBlock(pos, false);
                    level.explode(null, pos.getX() + 0.5, pos.getY() + 0.3, pos.getZ() + 0.5, 2.6f, Level.ExplosionInteraction.BLOCK);
                }
            }
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) return InteractionResult.SUCCESS;
            if (type == Type.BEAR && state.getValue(SNAPPED)) {
                level.setBlock(pos, state.setValue(SNAPPED, false), 3);
                level.playSound(null, pos, SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.BLOCKS, 1f, 0.8f);
                return InteractionResult.CONSUME;
            }
            if (player.isShiftKeyDown()) {
                level.removeBlock(pos, false);
                ItemStack st = new ItemStack(ModRegistry.item(itemId));
                if (!player.getInventory().add(st)) player.drop(st, false);
                return InteractionResult.CONSUME;
            }
            return InteractionResult.PASS;
        }
    }

    /** Свеча / керосиновая лампа: ставятся на твёрдую поверхность и светят. */
    public static class SmallLightBlock extends Block {
        private final VoxelShape shape;
        public SmallLightBlock(Properties p, VoxelShape shape) { super(p); this.shape = shape; }

        @Override
        protected VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) { return shape; }

        @Override
        protected boolean canSurvive(BlockState s, LevelReader l, BlockPos p) {
            return Block.canSupportCenter(l, p.below(), Direction.UP);
        }

        @Override
        protected BlockState updateShape(BlockState s, Direction d, BlockState n, net.minecraft.world.level.LevelAccessor l, BlockPos p, BlockPos np) {
            return !s.canSurvive(l, p) ? net.minecraft.world.level.block.Blocks.AIR.defaultBlockState() : s;
        }
    }

    /** Ящик/бочка/шкафчик: ПКМ — вскрыть, получить добычу, контейнер ломается. */
    public static class LootBlock extends Block {
        private final String table;
        public LootBlock(Properties p, String table) { super(p); this.table = table; }

        public static String tableFor(String id) {
            if (id.startsWith("locker_")) return "locker";
            if (id.startsWith("barrel_")) return switch (id) {
                case "barrel_fuel" -> "barrel_fuel";
                case "barrel_water" -> "barrel_water";
                case "barrel_toxic" -> "barrel_toxic";
                default -> "barrel_misc";
            };
            return id;
        }

        @Override
        protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
            if (level.isClientSide) return InteractionResult.SUCCESS;
            ServerLevel sl = (ServerLevel) level;
            ResourceKey<LootTable> key = ResourceKey.create(Registries.LOOT_TABLE, ModRegistry.rl("containers/" + table));
            LootTable lt = sl.getServer().reloadableRegistries().getLootTable(key);
            LootParams params = new LootParams.Builder(sl).withParameter(LootContextParams.ORIGIN, Vec3.atCenterOf(pos))
                    .withParameter(LootContextParams.THIS_ENTITY, player).create(LootContextParamSets.CHEST);
            for (ItemStack s : lt.getRandomItems(params)) Block.popResource(level, pos, s);
            level.playSound(null, pos, SoundEvents.WOOD_BREAK, SoundSource.BLOCKS, 1f, 0.7f);
            level.destroyBlock(pos, false);
            return InteractionResult.CONSUME;
        }
    }

    private ExtraItems() {}
}
