package dev.undermetro;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Equipable;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Классы предметов с особым поведением. Простые предметы создаются прямо в ModRegistry. */
public final class ModItems {

    /** Напитки: анимация питья. Эффекты (жажда и т.п.) обрабатываются в ServerEvents по таблице Content. */
    public static class DrinkItem extends Item {
        public DrinkItem(Properties p) {
            super(p);
        }

        @Override
        public UseAnim getUseAnimation(ItemStack stack) {
            return UseAnim.DRINK;
        }
    }

    /** Надеваемый предмет (противогаз — голова, защитный костюм — грудь). ПКМ — надеть. */
    public static class WearableItem extends Item implements Equipable {
        private final EquipmentSlot slot;

        public WearableItem(Properties p, EquipmentSlot slot) {
            super(p);
            this.slot = slot;
        }

        @Override
        public EquipmentSlot getEquipmentSlot() {
            return slot;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            return swapWithEquipmentSlot(this, level, player, hand);
        }
    }

    /** Пустая фляга: ПКМ по воде — набирает заражённую воду. */
    public static class FlaskItem extends Item {
        public FlaskItem(Properties p) {
            super(p);
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            BlockHitResult hit = getPlayerPOVHitResult(level, player, ClipContext.Fluid.SOURCE_ONLY);
            if (hit.getType() == HitResult.Type.BLOCK
                    && level.getFluidState(hit.getBlockPos()).is(net.minecraft.tags.FluidTags.WATER)) {
                level.playSound(player, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.BOTTLE_FILL, SoundSource.NEUTRAL, 1f, 1f);
                return InteractionResultHolder.sidedSuccess(
                        ItemUtils.createFilledResult(stack, player, new ItemStack(ModRegistry.item("dirty_water"))),
                        level.isClientSide());
            }
            return InteractionResultHolder.pass(stack);
        }
    }

    /** Огнестрел: ПКМ — выстрел (хитскан) из магазина, клавиша перезарядки (по умолчанию R) пополняет магазин из инвентаря. */
    public static class GunItem extends Item {
        private final Content.Gun gun;

        public GunItem(Properties p, Content.Gun gun) {
            super(p);
            this.gun = gun;
        }

        public Content.Gun gun() {
            return gun;
        }

        public int capacity() {
            return Math.max(1, gun.mag());
        }

        /** Подходит ли предмет как патрон к этому оружию: сам тип или его вариант (ammo_9mm -> ammo_9mm_ap и т.п.). */
        private boolean accepts(ItemStack s) {
            if (s.isEmpty()) return false;
            var key = BuiltInRegistries.ITEM.getKey(s.getItem());
            if (!key.getNamespace().equals(UnderMetro.MODID)) return false;
            String path = key.getPath();
            return path.equals(gun.ammo()) || path.startsWith(gun.ammo() + "_");
        }

        public int reserve(Player p) {
            int n = 0;
            for (ItemStack s : p.getInventory().items) if (accepts(s)) n += s.getCount();
            return n;
        }

        /** Перезарядка: забирает патроны из инвентаря, ставит кулдаун оружия. */
        public void reload(ServerPlayer player, ItemStack stack) {
            if (player.getCooldowns().isOnCooldown(this)) return;
            int cur = stack.getOrDefault(ModRegistry.AMMO.get(), 0);
            int need = capacity() - cur;
            if (need <= 0) {
                player.displayClientMessage(Component.translatable("msg.undermetro.mag_full"), true);
                return;
            }
            int taken = 0;
            for (ItemStack s : player.getInventory().items) {
                if (taken >= need) break;
                if (accepts(s)) {
                    int t = Math.min(need - taken, s.getCount());
                    s.shrink(t);
                    taken += t;
                }
            }
            if (player.isCreative() && taken == 0) taken = need;
            if (taken <= 0) {
                player.displayClientMessage(Component.translatable("msg.undermetro.no_ammo"), true);
                return;
            }
            stack.set(ModRegistry.AMMO.get(), cur + taken);
            player.getCooldowns().addCooldown(this, Math.max(10, gun.reload()));
            player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.CROSSBOW_LOADING_END.value(),
                    SoundSource.PLAYERS, 1f, 0.8f);
            player.displayClientMessage(Component.translatable("msg.undermetro.reloaded", cur + taken, capacity()), true);
        }

        /** ПКМ — только прицеливание (обрабатывает клиент); выстрел идёт по ЛКМ через пакет SHOOT. */
        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            return InteractionResultHolder.consume(player.getItemInHand(hand));
        }

        /** Кратность прицеливания (FOV-множитель). */
        public float zoom(Player p) {
            String off = BuiltInRegistries.ITEM.getKey(p.getOffhandItem().getItem()).getPath();
            String id = gun.id();
            if (id.contains("barrett")) return 0.2f;
            if (id.contains("sniper") || id.equals("rifle_bolt")) return 0.3f;
            if (off.equals("scope_sniper")) return 0.3f;
            if (id.equals("rifle_vss") || id.equals("rifle_val") || id.equals("rifle_g36") || off.equals("scope_basic")) return 0.55f;
            return 0.85f;
        }

        public boolean scoped(Player p) {
            return zoom(p) <= 0.55f;
        }

        /** Автоматическое оружие стреляет, пока зажата ЛКМ; остальное — по одному клику. */
        public boolean isAuto() {
            String id = gun.id();
            if (id.startsWith("smg_") || id.equals("rifle_lmg")) return true;
            return id.startsWith("rifle_") && !id.contains("mosin") && !id.equals("rifle_bolt") && !id.equals("rifle_sks");
        }

        public boolean isSniper() {
            return gun.id().contains("sniper") || gun.id().equals("rifle_bolt") || gun.id().contains("barrett");
        }

        public void tryShoot(ServerPlayer player, InteractionHand hand, boolean aiming) {
            ItemStack stack = player.getItemInHand(hand);
            if (player.getCooldowns().isOnCooldown(this)) return;
            ServerLevel level = player.serverLevel();
            int mag = stack.getOrDefault(ModRegistry.AMMO.get(), 0);
            if (mag <= 0 && !player.isCreative()) {
                level.playSound(null, player.blockPosition(), SoundEvents.DISPENSER_FAIL, SoundSource.PLAYERS, 0.8f, 1.6f);
                player.displayClientMessage(Component.translatable("msg.undermetro.empty_mag"), true);
                player.getCooldowns().addCooldown(this, 8);
                return;
            }
            if (!player.isCreative()) stack.set(ModRegistry.AMMO.get(), mag - 1);
            fire(level, player, aiming);
            player.getCooldowns().addCooldown(this, gun.delay());
            stack.hurtAndBreak(1, player, hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
        }

        private void fire(ServerLevel level, ServerPlayer player, boolean aiming) {
            PlayerStats st = PlayerStats.get(player);
            float spread = gun.spread() * (1f - 0.06f * st.level[PlayerStats.ACCURACY]);
            // от бедра — шире, особенно у снайперок; в прицеле — точнее
            if (aiming) spread *= 0.45f; else spread = Math.max(spread, 0.5f) * (isSniper() ? 6f : 2.2f);
            double range = gun.range();
            float volume = 2.5f;
            // Обвес из второй руки: прицелы и глушитель.
            String off = BuiltInRegistries.ITEM.getKey(player.getOffhandItem().getItem()).getPath();
            switch (off) {
                case "scope_basic" -> { spread *= 0.5f; range *= 1.25; }
                case "scope_sniper" -> { spread *= 0.25f; range *= 1.5; }
                case "suppressor" -> volume = 0.7f;
                case "grip_tactical" -> spread *= 0.75f;
                default -> {}
            }
            RandomSource rnd = player.getRandom();
            Vec3 eye = player.getEyePosition();
            Vec3 look = player.getViewVector(1f);
            boolean hitAny = false;
            for (int i = 0; i < gun.pellets(); i++) {
                Vec3 dir = jitter(look, spread, rnd);
                Vec3 end = eye.add(dir.scale(range));
                BlockHitResult bh = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER,
                        ClipContext.Fluid.NONE, player));
                Vec3 stop = bh.getType() == HitResult.Type.MISS ? end : bh.getLocation();
                EntityHitResult eh = ProjectileUtil.getEntityHitResult(player, eye, stop,
                        new AABB(eye, stop).inflate(1.0),
                        (Entity e) -> !e.isSpectator() && e.isPickable() && e != player,
                        range * range);
                if (eh != null) {
                    eh.getEntity().invulnerableTime = 0;
                    eh.getEntity().hurt(level.damageSources().playerAttack(player), gun.damage());
                    stop = eh.getLocation();
                    hitAny = true;
                }
                double len = eye.distanceTo(stop);
                for (double d = 1.5; d < len; d += 3.0) {
                    Vec3 pt = eye.add(dir.scale(d));
                    level.sendParticles(ParticleTypes.CRIT, pt.x, pt.y, pt.z, 1, 0, 0, 0, 0);
                }
                level.sendParticles(ParticleTypes.SMOKE, stop.x, stop.y, stop.z, 2, 0.05, 0.05, 0.05, 0.01);
            }
            if (hitAny) st.addXp(player, PlayerStats.ACCURACY, 2f);
            SoundEvent snd = ModRegistry.gunSound(gun.sound());
            level.playSound(null, player.getX(), player.getY(), player.getZ(), snd, SoundSource.PLAYERS, volume,
                    0.95f + rnd.nextFloat() * 0.1f);
        }

        private static Vec3 jitter(Vec3 look, float spreadDeg, RandomSource rnd) {
            if (spreadDeg <= 0) return look;
            double s = Math.tan(Math.toRadians(spreadDeg));
            return look.add((rnd.nextGaussian()) * s, (rnd.nextGaussian()) * s, (rnd.nextGaussian()) * s).normalize();
        }
    }

    /** Граната / коктейль Молотова. */
    public static class BombItem extends Item {
        private final boolean molotov;

        public BombItem(Properties p, boolean molotov) {
            super(p);
            this.molotov = molotov;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.SNOWBALL_THROW,
                    SoundSource.PLAYERS, 0.5f, 0.6f);
            if (!level.isClientSide) {
                EntityType<? extends ModEntities.ThrownBomb> type =
                        molotov ? ModRegistry.MOLOTOV.get() : ModRegistry.GRENADE.get();
                ModEntities.ThrownBomb b = type.create(level);
                if (b != null) {
                    b.setOwner(player);
                    b.setPos(player.getX(), player.getEyeY() - 0.1, player.getZ());
                    b.setItem(stack.copyWithCount(1));
                    b.shootFromRotation(player, player.getXRot(), player.getYRot(), 0f, 1.1f, 1f);
                    level.addFreshEntity(b);
                }
            }
            if (!player.isCreative()) stack.shrink(1);
            player.getCooldowns().addCooldown(this, 12);
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }
    }

    /** Набор для сборки транспорта — ПКМ по земле ставит багги. */
    public static class VehicleKitItem extends Item {
        public VehicleKitItem(Properties p) {
            super(p);
        }

        @Override
        public InteractionResult useOn(UseOnContext ctx) {
            Level level = ctx.getLevel();
            if (!level.isClientSide) {
                ModEntities.RustBuggy b = ModRegistry.BUGGY.get().create(level);
                if (b != null) {
                    Vec3 at = Vec3.atBottomCenterOf(ctx.getClickedPos().relative(ctx.getClickedFace()));
                    b.moveTo(at.x, at.y, at.z, ctx.getRotation(), 0f);
                    level.addFreshEntity(b);
                    if (ctx.getPlayer() == null || !ctx.getPlayer().isCreative()) ctx.getItemInHand().shrink(1);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
    }

    /** Чертёж: при крафте не расходуется (возвращается в сетку), т.е. «изучается» один раз и работает постоянно. */
    public static class BlueprintItem extends Item {
        public BlueprintItem(Properties p) {
            super(p);
        }

        // Без @Override намеренно: сигнатура входит в IItemExtension NeoForge.
        public ItemStack getCraftingRemainingItem(ItemStack stack) {
            return stack.copyWithCount(1);
        }

        public boolean hasCraftingRemainingItem(ItemStack stack) {
            return true;
        }
    }

    private ModItems() {}
}
