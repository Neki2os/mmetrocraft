package dev.undermetro;

/** 7 уровней крутости техники. Все значения считаются от номера уровня (1..7). */
public final class Grade {
    public static final int MAX = 7;

    /** Ёмкость аккумулятора, FE. */
    public static int batteryCapacity(int t) { return 20_000 * (int) Math.pow(3, t - 1); }

    /** Скорость заряда/разряда аккумулятора, FE/тик. */
    public static int batteryRate(int t) { return 100 * (int) Math.pow(2, t - 1); }

    /** Выход генератора, FE/тик. */
    public static int generatorOutput(int t) { return 20 * (int) Math.pow(2, t - 1); }

    /** Пропускная способность провода, FE/тик. */
    public static int cableRate(int t) { return 200 * (int) Math.pow(3, t - 1); }

    public static int lampLight(int t) { return Math.min(15, 8 + t); }

    /** Лампы с высоким уровнем жрут меньше на единицу света. */
    public static int lampCost(int t) { return Math.max(1, 6 - t); }

    public static int airFilterCost(int t) { return 10 + 4 * t; }

    public static int waterFilterCost(int t) { return Math.max(40, 400 - 50 * t); }

    public static int sensorCost(int t) { return 1; }

    public static int turretCost(int t) { return 60 + 20 * t; }

    public static float turretDamage(int t) { return 3f + 2.5f * t; }

    public static int turretRange(int t) { return 10 + 3 * t; }

    public static int alarmRange(int t) { return 16 + 6 * t; }

    public static int alarmCost(int t) { return 4; }

    public static int doorCost(int t) { return Math.max(20, 250 - 30 * t); }

    /** Сколько FE нужно на один «пункт заряда» в предмете-батарейке. */
    public static final int FE_PER_CHARGE_POINT = 50;

    private Grade() {}
}
