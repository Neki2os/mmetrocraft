package dev.undermetro.worldgen;

import com.mojang.serialization.Codec;
import net.minecraft.core.Direction;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Заброшенный город: каждый чанк внутри «района» (8x8 чанков) получает одно здание 12x12 с улицей по краям.
 * Всё чанк-локально: высота берётся по центру чанка, фундамент подводится к земле.
 */
public class CityFeature extends Feature<NoneFeatureConfiguration> {
    private enum Kind { TOWER, HOSPITAL, POLICE, FIRE, MILITARY, LAB, RUBBLE, PARK }

    public CityFeature(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        Gen g = new Gen(level, ctx.origin(), ctx.random());
        long seed = level.getSeed();
        int cx = g.minX >> 4, cz = g.minZ >> 4;

        // Район города?
        if (Gen.hash(seed ^ 0x51ED, cx >> 3, cz >> 3) > 0.55f) return false;

        int cxw = g.minX + 8, czw = g.minZ + 8;
        int ground = level.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, cxw, czw);
        int surface = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, cxw, czw);
        if (surface > ground + 1) return false; // вода — не строим
        int base = ground; // первый воздушный блок над землёй

        // Улицы по краю чанка
        BlockState asphalt = Blocks.BLACK_CONCRETE.defaultBlockState();
        BlockState asphalt2 = Blocks.GRAY_CONCRETE.defaultBlockState();
        for (int x = g.minX; x < g.minX + 16; x++) {
            for (int z = g.minZ; z < g.minZ + 16; z++) {
                int lx = x - g.minX, lz = z - g.minZ;
                boolean street = lx < 2 || lx > 13 || lz < 2 || lz > 13;
                if (!street) continue;
                int top = level.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, x, z) - 1;
                float h = Gen.hash(seed, x, z);
                g.set(x, top, z, h < 0.12f ? Blocks.COARSE_DIRT.defaultBlockState() : (h < 0.5f ? asphalt2 : asphalt));
                // очистка растительности над улицей
                for (int y = top + 1; y <= top + 3; y++) g.set(x, y, z, Blocks.AIR);
                if (h > 0.985f) g.set(x, top + 1, z, Blocks.COBWEB);
                else if (h > 0.97f) g.set(x, top + 1, z, Blocks.IRON_BARS);
            }
        }
        // Разметка по центру улицы
        if (cx % 2 == 0) for (int z = g.minZ; z < g.minZ + 16; z += 2) g.set(g.minX, ground - 1, z, Blocks.YELLOW_CONCRETE);

        float r = Gen.hash(seed ^ 0xC17F, cx, cz);
        Kind kind;
        if (r < 0.06f) kind = Kind.HOSPITAL;
        else if (r < 0.10f) kind = Kind.POLICE;
        else if (r < 0.14f) kind = Kind.FIRE;
        else if (r < 0.17f) kind = Kind.MILITARY;
        else if (r < 0.20f) kind = Kind.LAB;
        else if (r < 0.32f) kind = Kind.RUBBLE;
        else if (r < 0.40f) kind = Kind.PARK;
        else kind = Kind.TOWER;

        int x1 = g.minX + 2, z1 = g.minZ + 2, x2 = g.minX + 13, z2 = g.minZ + 13;
        switch (kind) {
            case TOWER -> tower(g, x1, z1, x2, z2, base, 5 + (int) (Gen.hash(seed, cx, cz) * 14), seed);
            case HOSPITAL -> civic(g, x1, z1, x2, z2, base, 4, Blocks.WHITE_CONCRETE.defaultBlockState(), Blocks.RED_CONCRETE.defaultBlockState(), "city_hospital", "city_medical");
            case POLICE -> civic(g, x1, z1, x2, z2, base, 3, Blocks.BLUE_CONCRETE.defaultBlockState(), Blocks.LIGHT_GRAY_CONCRETE.defaultBlockState(), "city_police", "city_weapons");
            case FIRE -> civic(g, x1, z1, x2, z2, base, 3, Blocks.RED_CONCRETE.defaultBlockState(), Blocks.BRICKS.defaultBlockState(), "city_fire", "city_tools");
            case MILITARY -> civic(g, x1, z1, x2, z2, base, 2, Blocks.GREEN_CONCRETE.defaultBlockState(), Blocks.MOSSY_STONE_BRICKS.defaultBlockState(), "city_military", "city_weapons");
            case LAB -> civic(g, x1, z1, x2, z2, base, 3, Blocks.LIGHT_BLUE_CONCRETE.defaultBlockState(), Blocks.QUARTZ_BLOCK.defaultBlockState(), "city_lab", "city_blueprints");
            case RUBBLE -> rubble(g, x1, z1, x2, z2, base);
            case PARK -> park(g, x1, z1, x2, z2, base);
        }
        return true;
    }

    private static BlockState wallMaterial(Gen g, float k) {
        return k < 0.22f ? Blocks.CRACKED_STONE_BRICKS.defaultBlockState()
                : k < 0.38f ? Blocks.COBBLESTONE.defaultBlockState()
                : k < 0.50f ? Blocks.MOSSY_STONE_BRICKS.defaultBlockState()
                : Blocks.STONE_BRICKS.defaultBlockState();
    }

    /** Фундамент до земли: заполняем вниз пока воздух/растительность. */
    private static void foundation(Gen g, int x1, int z1, int x2, int z2, int base, BlockState st) {
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) {
                for (int y = base - 1; y > base - 12; y--) {
                    if (!g.inside(x, z)) break;
                    BlockState cur = g.get(x, y, z);
                    if (cur.isAir() || cur.canBeReplaced() || !cur.getFluidState().isEmpty()) g.set(x, y, z, st);
                    else break;
                }
                // срезаем возвышения до уровня пола
                for (int y = base; y < base + 3; y++) g.set(x, y, z, Blocks.AIR);
            }
    }

    private void tower(Gen g, int x1, int z1, int x2, int z2, int base, int floors, long seed) {
        foundation(g, x1, z1, x2, z2, base, Blocks.STONE_BRICKS.defaultBlockState());
        int fh = 4;
        // «разрушенность» — верхние этажи могут отсутствовать/быть обрушены
        int built = Math.max(2, floors - g.rnd.nextInt(Math.max(1, floors / 2)));
        for (int f = 0; f < built; f++) {
            int y0 = base + f * fh;
            for (int x = x1; x <= x2; x++)
                for (int z = z1; z <= z2; z++) {
                    boolean edge = x == x1 || x == x2 || z == z1 || z == z2;
                    float k = Gen.hash(seed + f, x, z);
                    // пол/потолок
                    g.set(x, y0, z, k < 0.08f && f > 0 ? Blocks.AIR.defaultBlockState() : Blocks.GRAY_CONCRETE.defaultBlockState());
                    for (int y = y0 + 1; y < y0 + fh; y++) {
                        if (edge) {
                            boolean window = y == y0 + 2 && ((x + z) % 3 != 0);
                            boolean broken = k > 0.86f;
                            if (broken) g.set(x, y, z, Blocks.AIR);
                            else g.set(x, y, z, window ? Blocks.GLASS_PANE.defaultBlockState() : wallMaterial(g, k));
                        } else if ((x - x1) % 4 == 0 && (z - z1) % 4 == 0) {
                            g.set(x, y, z, Blocks.STONE_BRICKS); // колонны
                        } else {
                            g.set(x, y, z, k > 0.975f ? Blocks.COBWEB.defaultBlockState() : Blocks.AIR.defaultBlockState());
                        }
                    }
                }
            // Лестничная клетка
            int sx = x2 - 1, sz = z1 + 1;
            for (int y = y0 + 1; y < y0 + fh + 1; y++)
                g.set(sx, y, sz, Blocks.LADDER.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH));
            g.set(sx, y0 + fh, sz, Blocks.AIR);
            // Мебель / лут на этаже
            if (f % 2 == 0 && g.rnd.nextFloat() < 0.55f)
                g.chest(x1 + 2 + g.rnd.nextInt(5), y0 + 1, z1 + 2 + g.rnd.nextInt(7), Direction.NORTH, "city_apartment");
            if (g.rnd.nextFloat() < 0.35f)
                g.set(x1 + 2 + g.rnd.nextInt(6), y0 + 1, z2 - 1, Blocks.RED_BED.defaultBlockState());
        }
        // Дверной проём на первом этаже
        int dx = x1 + 5;
        g.fill(dx, base + 1, z2, dx + 1, base + 2, z2, Blocks.AIR);
        g.fill(dx, base + 1, z1, dx + 1, base + 2, z1, Blocks.AIR);
        // Крыша
        int roof = base + built * fh;
        g.fill(x1, roof, z1, x2, roof, z2, Blocks.GRAY_CONCRETE.defaultBlockState());
    }

    /** Муниципальное здание: низкое, укреплённое, с несколькими комнатами и лутом. */
    private void civic(Gen g, int x1, int z1, int x2, int z2, int base, int floors,
                       BlockState wall, BlockState trim, String loot, String lootSecondary) {
        foundation(g, x1, z1, x2, z2, base, Blocks.STONE_BRICKS.defaultBlockState());
        int fh = 5;
        for (int f = 0; f < floors; f++) {
            int y0 = base + f * fh;
            g.fill(x1, y0, z1, x2, y0, z2, Blocks.SMOOTH_STONE.defaultBlockState());
            g.fill(x1, y0 + 1, z1, x2, y0 + fh - 1, z2, Blocks.AIR);
            // внешние стены
            for (int y = y0 + 1; y < y0 + fh; y++) {
                for (int x = x1; x <= x2; x++) {
                    g.set(x, y, z1, wall);
                    g.set(x, y, z2, wall);
                }
                for (int z = z1; z <= z2; z++) {
                    g.set(x1, y, z, wall);
                    g.set(x2, y, z, wall);
                }
            }
            // окна
            for (int x = x1 + 2; x < x2; x += 3) {
                g.set(x, y0 + 3, z1, Blocks.IRON_BARS);
                g.set(x, y0 + 3, z2, Blocks.IRON_BARS);
            }
            // внутренние перегородки с дверными проёмами
            for (int z = z1 + 4; z < z2; z += 4)
                for (int x = x1 + 1; x < x2; x++)
                    for (int y = y0 + 1; y < y0 + fh - 1; y++)
                        g.set(x, y, z, (x - x1) % 5 == 2 && y < y0 + 3 ? Blocks.AIR.defaultBlockState() : trim);
            // лут
            g.chest(x1 + 1, y0 + 1, z1 + 2, Direction.EAST, loot);
            g.chest(x2 - 1, y0 + 1, z1 + 6, Direction.WEST, g.rnd.nextBoolean() ? loot : lootSecondary);
            g.set(x1 + 1, y0 + 1, z2 - 1, Blocks.CRAFTING_TABLE);
            g.set(x2 - 1, y0 + 1, z2 - 1, Blocks.IRON_BLOCK);
            // лестница
            for (int y = y0 + 1; y <= y0 + fh; y++)
                g.set(x2 - 1, y, z2 - 2, Blocks.LADDER.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.WEST));
        }
        // Крыша, входы (двойные проёмы), следы боя
        int roof = base + floors * fh;
        g.fill(x1, roof, z1, x2, roof, z2, trim);
        g.fill(x1 + 5, base + 1, z2, x1 + 6, base + 3, z2, Blocks.AIR);
        g.fill(x1 + 5, base + 1, z1, x1 + 6, base + 3, z1, Blocks.AIR);
        // Дополнительный «секретный» сундук с чертежами в подвале лабораторий — отдельные таблицы лута
        g.chest(x1 + 3, base + 1, z2 - 2, Direction.SOUTH, "city_blueprints");
    }

    private void rubble(Gen g, int x1, int z1, int x2, int z2, int base) {
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) {
                float k = Gen.hash(0xBEEF, x, z);
                int h = (int) (k * 4);
                for (int y = 0; y < h; y++) {
                    int ground = base;
                    g.set(x, ground + y, z, k < 0.3f ? Blocks.COBBLESTONE : Blocks.GRAY_CONCRETE_POWDER);
                }
            }
        g.chest(x1 + 4, base, z1 + 4, Direction.NORTH, "city_apartment");
    }

    private void park(Gen g, int x1, int z1, int x2, int z2, int base) {
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) {
                float k = Gen.hash(0xDEAD, x, z);
                if (k > 0.93f) {
                    for (int y = 0; y < 4; y++) g.set(x, base + y, z, Blocks.DARK_OAK_LOG);
                    g.fill(x - 1, base + 3, z - 1, x + 1, base + 4, z + 1, Blocks.AIR.defaultBlockState());
                } else if (k > 0.8f) {
                    g.set(x, base, z, Blocks.DEAD_BUSH);
                }
            }
        // Брошенная машина
        g.fill(x1 + 3, base, z1 + 4, x1 + 6, base, z1 + 5, Blocks.IRON_BLOCK.defaultBlockState());
        g.fill(x1 + 3, base + 1, z1 + 4, x1 + 5, base + 1, z1 + 5, Blocks.GLASS.defaultBlockState());
    }
}
