package dev.undermetro.worldgen;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.RandomizableContainer;

/**
 * Вспомогательный «чанк-локальный» рисовальщик: любые записи вне текущего чанка отбрасываются,
 * поэтому структуры, пересекающие границы, рисуются каждым чанком независимо и стыкуются без обращения к соседям.
 */
final class Gen {
    final WorldGenLevel level;
    final int minX, minZ;
    final RandomSource rnd;

    Gen(WorldGenLevel level, BlockPos origin, RandomSource rnd) {
        this.level = level;
        this.minX = origin.getX() & ~15;
        this.minZ = origin.getZ() & ~15;
        this.rnd = rnd;
    }

    boolean inside(int x, int z) {
        return x >= minX && x < minX + 16 && z >= minZ && z < minZ + 16;
    }

    boolean set(int x, int y, int z, BlockState st) {
        if (!inside(x, z) || y < level.getMinBuildHeight() || y >= level.getMaxBuildHeight()) return false;
        level.setBlock(new BlockPos(x, y, z), st, 2);
        return true;
    }

    void set(int x, int y, int z, Block b) {
        set(x, y, z, b.defaultBlockState());
    }

    BlockState get(int x, int y, int z) {
        return level.getBlockState(new BlockPos(x, y, z));
    }

    /** Заполнить параллелепипед (включительно). */
    void fill(int x1, int y1, int z1, int x2, int y2, int z2, BlockState st) {
        int ax = Math.max(Math.min(x1, x2), minX), bx = Math.min(Math.max(x1, x2), minX + 15);
        int az = Math.max(Math.min(z1, z2), minZ), bz = Math.min(Math.max(z1, z2), minZ + 15);
        for (int x = ax; x <= bx; x++)
            for (int z = az; z <= bz; z++)
                for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++) set(x, y, z, st);
    }

    void fill(int x1, int y1, int z1, int x2, int y2, int z2, Block b) {
        fill(x1, y1, z1, x2, y2, z2, b.defaultBlockState());
    }

    /** Рамка (стены + пол + потолок) с воздухом внутри. */
    void room(int x1, int y1, int z1, int x2, int y2, int z2, BlockState wall) {
        fill(x1, y1, z1, x2, y2, z2, wall);
        fill(x1 + 1, y1 + 1, z1 + 1, x2 - 1, y2 - 1, z2 - 1, Blocks.AIR);
    }

    void chest(int x, int y, int z, Direction facing, String lootPath) {
        if (!inside(x, z)) return;
        BlockPos p = new BlockPos(x, y, z);
        level.setBlock(p, Blocks.CHEST.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, facing), 2);
        BlockEntity be = level.getBlockEntity(p);
        if (be instanceof RandomizableContainer rc) {
            rc.setLootTable(ResourceKey.create(Registries.LOOT_TABLE,
                    ResourceLocation.fromNamespaceAndPath("undermetro", "chests/" + lootPath)), rnd.nextLong());
        }
    }

    /** Детерминированный хэш по координатам -> [0,1). */
    static float hash(long seedish, int a, int b) {
        long h = seedish * 341873128712L + a * 132897987541L + b * 42317861L;
        h ^= h >>> 33;
        h *= 0xff51afd7ed558ccdL;
        h ^= h >>> 33;
        h *= 0xc4ceb9fe1a85ec53L;
        h ^= h >>> 33;
        return ((h >>> 11) & 0xFFFFFL) / (float) 0x100000;
    }
}
