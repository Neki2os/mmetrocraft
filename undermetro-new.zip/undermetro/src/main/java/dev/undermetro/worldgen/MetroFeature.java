package dev.undermetro.worldgen;

import com.mojang.serialization.Codec;
import dev.undermetro.ModRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Заброшенная ветка метро. Сетка из тоннелей с шагом 64 блока вдоль X и Z, на пересечениях — станции.
 * Рядом с началом координат — герметичная стартовая комната с выходом в тоннель.
 */
public class MetroFeature extends Feature<NoneFeatureConfiguration> {
    public static final int PERIOD = 64;
    public static final int CENTER = 32;       // осевая линия тоннеля внутри периода
    public static final int FLOOR = -44;       // уровень пола
    public static final int HALF = 3;          // полуширина тоннеля (внутри)
    public static final int CEIL = FLOOR + 6;  // потолок тоннеля
    public static final int HALL = 8;          // полуразмер станции
    public static final int HALL_CEIL = FLOOR + 9;

    // Стартовая комната: интерьер x 12..16, z 21..25, y FLOOR+1 .. FLOOR+3. Вход: люк на z=27.
    public static final int ROOM_X1 = 12, ROOM_X2 = 16, ROOM_Z1 = 21, ROOM_Z2 = 25;
    public static final BlockPos SPAWN_POS = new BlockPos(14, FLOOR + 1, 23);

    public MetroFeature(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    private static int dist(int w) {
        return Math.floorMod(w, PERIOD) - CENTER;
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        Gen g = new Gen(level, ctx.origin(), ctx.random());
        long seed = level.getSeed();

        BlockState shell = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
        BlockState shellAlt = Blocks.POLISHED_DEEPSLATE.defaultBlockState();
        BlockState cracked = Blocks.CRACKED_DEEPSLATE_BRICKS.defaultBlockState();
        BlockState concrete = Blocks.GRAY_CONCRETE.defaultBlockState();

        boolean any = false;
        for (int x = g.minX; x < g.minX + 16; x++) {
            for (int z = g.minZ; z < g.minZ + 16; z++) {
                int dx = dist(x), dz = dist(z);
                int adx = Math.abs(dx), adz = Math.abs(dz);
                boolean laneX = adz <= HALF + 2;  // тоннель вдоль X (центр по z)
                boolean laneZ = adx <= HALF + 2;  // тоннель вдоль Z (центр по x)
                boolean hall = adx <= HALL + 1 && adz <= HALL + 1;
                if (!laneX && !laneZ && !hall) continue;
                any = true;

                boolean inHall = adx <= HALL && adz <= HALL;
                boolean inLaneX = adz <= HALF;
                boolean inLaneZ = adx <= HALF;
                boolean interior = inHall || inLaneX || inLaneZ;
                int ceil = (adx <= HALL + 1 && adz <= HALL + 1) ? HALL_CEIL : CEIL;
                if (!inHall && (inLaneX || inLaneZ)) {
                    // арочный потолок: по краям ниже
                    int edge = inLaneX ? adz : adx;
                    ceil = CEIL - (edge >= HALF ? 1 : 0);
                }
                float h = Gen.hash(seed, x, z);

                // Оболочка и внутренний объём
                for (int y = FLOOR - 1; y <= (hall ? HALL_CEIL + 1 : CEIL + 1); y++) {
                    if (y < level.getMinBuildHeight()) continue;
                    boolean isInterior = interior && y > FLOOR && y < ceil + (inHall ? 1 : 0);
                    if (isInterior) {
                        g.set(x, y, z, Blocks.AIR);
                    } else {
                        float k = Gen.hash(seed + y, x, z);
                        g.set(x, y, z, k < 0.18f ? cracked : (k < 0.4f ? shellAlt : (k < 0.5f ? concrete : shell)));
                    }
                }
                if (!interior) continue;

                // Пол: бетон, в тоннелях — щебень вокруг путей
                BlockState floorState = h < 0.2f ? Blocks.COBBLESTONE.defaultBlockState()
                        : h < 0.35f ? Blocks.GRAVEL.defaultBlockState() : Blocks.STONE_BRICKS.defaultBlockState();
                g.set(x, FLOOR, z, floorState);

                // Пути в тоннелях (две колеи по бокам оси)
                boolean tunnelOnly = !inHall;
                if (tunnelOnly) {
                    if (inLaneX && !inLaneZ && (adz == 1 || adz == 2) && h > 0.1f) {
                        g.set(x, FLOOR + 1, z, rail(h, RailShape.EAST_WEST));
                    } else if (inLaneZ && !inLaneX && (adx == 1 || adx == 2) && h > 0.1f) {
                        g.set(x, FLOOR + 1, z, rail(h, RailShape.NORTH_SOUTH));
                    }
                }

                // Разруха: паутина, лужи, мусор, обвалы
                if (h > 0.97f) g.set(x, FLOOR + 1, z, Blocks.COBWEB);
                else if (h > 0.94f) g.set(x, FLOOR + 1, z, Blocks.COBBLED_DEEPSLATE);
                else if (h > 0.915f) g.set(x, FLOOR + 1, z, Blocks.IRON_BARS);
                else if (h < 0.03f) g.set(x, FLOOR, z, Blocks.WATER);
                // Фонари/осветители: редкие мёртвые (без света) — только декор
                if (inLaneX && adz == HALF && Math.floorMod(x, 8) == 0)
                    g.set(x, CEIL - 2, z, Blocks.IRON_BARS);
                if (inLaneZ && adx == HALF && Math.floorMod(z, 8) == 0)
                    g.set(x, CEIL - 2, z, Blocks.IRON_BARS);

                // Колонны на станции
                if (inHall && (adx == 5 || adx == 8) && (adz == 5 || adz == 8))
                    g.fill(x, FLOOR + 1, z, x, HALL_CEIL, z, Blocks.STONE_BRICKS);
                // Платформы вдоль станции
                if (inHall && adx >= 5 && adx <= 8 && adz > HALF && h > 0.15f)
                    g.set(x, FLOOR + 1, z, Blocks.STONE_BRICK_SLAB);
            }
        }

        if (any) {
            stationDetails(g, seed);
            surfaceShaft(g, seed, level);
        }
        startRoom(g);
        return any;
    }

    private static BlockState rail(float h, RailShape shape) {
        BlockState r = Blocks.RAIL.defaultBlockState().setValue(RailBlock.SHAPE, shape);
        return r;
    }

    /** Сундуки на станциях, спальные места, ящики. */
    private void stationDetails(Gen g, long seed) {
        int cx = Math.floorDiv(g.minX, PERIOD), cz = Math.floorDiv(g.minZ, PERIOD);
        int baseX = cx * PERIOD + CENTER, baseZ = cz * PERIOD + CENTER;
        for (int i = 0; i < 4; i++) {
            float a = Gen.hash(seed + 7 * i, baseX, baseZ + i);
            float b = Gen.hash(seed + 13 * i, baseX + i, baseZ);
            int x = baseX + (int) (a * 15) - 7, z = baseZ + (int) (b * 15) - 7;
            if (!(Math.abs(x - baseX) < 5 && Math.abs(z - baseZ) < 5)) {
                if (g.inside(x, z) && g.get(x, FLOOR + 1, z).isAir()) {
                    g.chest(x, FLOOR + 1, z, Direction.Plane.HORIZONTAL.getRandomDirection(g.rnd),
                            i == 0 ? "metro_rare" : "metro_common");
                }
            }
        }
        // Стоянка брошенного вагона (каркас) вдоль платформы
        if (Gen.hash(seed, baseX, baseZ) > 0.35f) {
            for (int x = baseX - 7; x <= baseX + 7; x++) {
                for (int z = baseZ - 2; z <= baseZ + 2; z++) {
                    if (!g.inside(x, z)) continue;
                    boolean edge = Math.abs(z - baseZ) == 2 || Math.abs(x - baseX) == 7;
                    if (edge && g.get(x, FLOOR + 1, z).isAir()) {
                        g.fill(x, FLOOR + 1, z, x, FLOOR + 3, z, Blocks.IRON_BLOCK.defaultBlockState());
                        if (g.rnd.nextFloat() < 0.4f) g.fill(x, FLOOR + 2, z, x, FLOOR + 2, z, Blocks.GLASS_PANE.defaultBlockState());
                    }
                }
            }
        }
    }

    /** Шахта-лестница с края станции на поверхность. */
    private void surfaceShaft(Gen g, long seed, WorldGenLevel level) {
        int cx = Math.floorDiv(g.minX, PERIOD), cz = Math.floorDiv(g.minZ, PERIOD);
        int sx = cx * PERIOD + CENTER + 6, sz = cz * PERIOD + CENTER;
        if (!g.inside(sx, sz)) return;
        int top = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, sx, sz);
        BlockState wall = Blocks.STONE_BRICKS.defaultBlockState();
        for (int y = FLOOR + 1; y <= top + 1; y++) {
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++)
                    if (y >= HALL_CEIL) g.set(sx + dx, y, sz + dz, wall);
            g.set(sx, y, sz, y <= top
                    ? Blocks.LADDER.defaultBlockState().setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.NORTH)
                    : Blocks.AIR.defaultBlockState());
            if (y >= FLOOR + 1) g.set(sx, y, sz + 1, wall); // стена, к которой крепится лестница
        }
        g.set(sx, top + 2, sz, Blocks.IRON_BARS);
    }

    /** Герметичная стартовая комната. */
    private void startRoom(Gen g) {
        int cx = Math.floorDiv(ROOM_X1, PERIOD), cz = Math.floorDiv(ROOM_Z1, PERIOD);
        if (cx != 0 || cz != 0) return; // комната существует только возле (0,0)
        BlockState wall = Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState();
        BlockState steel = Blocks.IRON_BLOCK.defaultBlockState();
        int y0 = FLOOR, y1 = FLOOR + 4;
        // Сначала вырезаем коридор-проход к тоннелю (z=26 воздух, 27 — люк, 28 — воздух)
        g.room(ROOM_X1 - 1, y0, ROOM_Z1 - 1, ROOM_X2 + 1, y1, ROOM_Z2 + 1, wall);
        g.fill(ROOM_X1 - 1, y0, ROOM_Z1 - 1, ROOM_X2 + 1, y0, ROOM_Z2 + 1, Blocks.SMOOTH_STONE);
        for (int x = ROOM_X1 - 1; x <= ROOM_X2 + 1; x++) g.set(x, y1, ROOM_Z1 - 1, steel);

        // Коридор к тоннелю: стенка комнаты на z=26 заменяется на проход
        int dx = 14;
        g.fill(dx - 1, y0, ROOM_Z2 + 1, dx + 1, y1, ROOM_Z2 + 3, wall);
        g.fill(dx, y0 + 1, ROOM_Z2 + 1, dx, y0 + 2, ROOM_Z2 + 3, Blocks.AIR);
        // Герметичный люк (два блока в высоту) на z=27
        BlockState hatch = ModRegistry.MACHINE_BLOCKS.stream()
                .filter(b -> b.get().kind == dev.undermetro.MachineBlock.Kind.HATCH).findFirst().get().get().defaultBlockState();
        g.set(dx, y0 + 1, ROOM_Z2 + 2, hatch);
        g.set(dx, y0 + 2, ROOM_Z2 + 2, hatch);

        // Интерьер: аварийный фильтр, кровать, сундуки, свет
        g.set(ROOM_X1, y0 + 1, ROOM_Z1, ModRegistry.EMERGENCY_FILTER.get());
        g.set(ROOM_X1, y0 + 2, ROOM_Z1, Blocks.SHROOMLIGHT);
        g.set(ROOM_X2, y0 + 3, ROOM_Z2, Blocks.SHROOMLIGHT);
        g.set(ROOM_X1, y0 + 3, ROOM_Z2, Blocks.SHROOMLIGHT);
        g.set(ROOM_X2, y0 + 1, ROOM_Z1, Blocks.RED_BED.defaultBlockState()
                .setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH));
        g.set(ROOM_X2, y0 + 1, ROOM_Z1 + 1, Blocks.RED_BED.defaultBlockState()
                .setValue(BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH)
                .setValue(BlockStateProperties.BED_PART, net.minecraft.world.level.block.state.properties.BedPart.HEAD));
        g.chest(ROOM_X1 + 1, y0 + 1, ROOM_Z2, Direction.NORTH, "start_supplies");
        g.chest(ROOM_X1 + 2, y0 + 1, ROOM_Z2, Direction.NORTH, "start_gear");
        g.set(ROOM_X2, y0 + 1, ROOM_Z2, Blocks.CRAFTING_TABLE);
    }
}
