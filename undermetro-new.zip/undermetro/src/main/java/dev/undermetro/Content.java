package dev.undermetro;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Единый источник правды по «простому» контенту (еда, питьё, оружие, инструменты, разное).
 * Данные лежат в resources/undermetro_content.json (генерируется tools/build_assets.py,
 * но можно править руками). Чтобы добавить предмет — допишите запись в JSON и положите текстуру.
 */
public final class Content {
    public record Fx(String effect, int duration, int amplifier) {}

    public record Consumable(String id, String kind, int hunger, float sat, int thirst, float health,
                             int antirad, List<Fx> fx) {}

    public record Melee(String id, double damage, double speed, int durability) {}

    public record Tool(String id, String type, double damage, double speed, int durability, float mineSpeed) {}

    public record Gun(String id, float damage, int delay, int pellets, float spread, int range,
                      String ammo, int durability, String sound, int mag, int reload) {}

    /** type: plain | filter | flashlight | battery | head | chest | lighter | flask | kit | grenade | molotov */
    public record Misc(String id, String type, int stack, int durability, int armor) {}

    /** Простой декоративный блок: strength — прочность, light — яркость 0..15. */
    public record Decor(String id, float strength, int light) {}

    public record TabDef(String key, String icon) {}

    public static final List<Consumable> CONSUMABLES = new ArrayList<>();
    public static final List<Melee> MELEE = new ArrayList<>();
    public static final List<Tool> TOOLS = new ArrayList<>();
    public static final List<Gun> GUNS = new ArrayList<>();
    public static final List<Misc> MISC = new ArrayList<>();
    public static final List<Decor> DECOR = new ArrayList<>();
    public static final List<TabDef> TAB_DEFS = new ArrayList<>();
    public static final Map<String, String> TAB_OF = new LinkedHashMap<>();
    public static final Map<String, Consumable> CONSUMABLE_BY_ID = new LinkedHashMap<>();
    public static final Map<String, Gun> GUN_BY_ID = new LinkedHashMap<>();

    static {
        try (Reader r = new InputStreamReader(
                Content.class.getResourceAsStream("/undermetro_content.json"), StandardCharsets.UTF_8)) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
            for (JsonElement e : arr(root, "consumables")) {
                JsonObject o = e.getAsJsonObject();
                List<Fx> fx = new ArrayList<>();
                if (o.has("fx")) {
                    for (JsonElement f : o.getAsJsonArray("fx")) {
                        JsonObject fo = f.getAsJsonObject();
                        fx.add(new Fx(fo.get("effect").getAsString(), fo.get("duration").getAsInt(),
                                fo.get("amplifier").getAsInt()));
                    }
                }
                Consumable c = new Consumable(str(o, "id"), str(o, "kind"), i(o, "hunger"), f(o, "sat"),
                        i(o, "thirst"), f(o, "health"), i(o, "antirad"), fx);
                CONSUMABLES.add(c);
                CONSUMABLE_BY_ID.put(c.id(), c);
            }
            for (JsonElement e : arr(root, "melee")) {
                JsonObject o = e.getAsJsonObject();
                MELEE.add(new Melee(str(o, "id"), o.get("damage").getAsDouble(), o.get("speed").getAsDouble(),
                        i(o, "durability")));
            }
            for (JsonElement e : arr(root, "tools")) {
                JsonObject o = e.getAsJsonObject();
                TOOLS.add(new Tool(str(o, "id"), str(o, "type"), o.get("damage").getAsDouble(),
                        o.get("speed").getAsDouble(), i(o, "durability"), f(o, "mine_speed")));
            }
            for (JsonElement e : arr(root, "guns")) {
                JsonObject o = e.getAsJsonObject();
                Gun g = new Gun(str(o, "id"), f(o, "damage"), i(o, "delay"), i(o, "pellets"), f(o, "spread"),
                        i(o, "range"), str(o, "ammo"), i(o, "durability"), str(o, "sound"), i(o, "mag"), i(o, "reload"));
                GUNS.add(g);
                GUN_BY_ID.put(g.id(), g);
            }
            for (JsonElement e : arr(root, "misc")) {
                JsonObject o = e.getAsJsonObject();
                MISC.add(new Misc(str(o, "id"), str(o, "type"), i(o, "stack"), i(o, "durability"), i(o, "armor")));
            }
            for (JsonElement e : arr(root, "tab_defs")) {
                JsonObject o = e.getAsJsonObject();
                TAB_DEFS.add(new TabDef(str(o, "key"), str(o, "icon")));
            }
            if (root.has("tabs")) {
                for (Map.Entry<String, JsonElement> en : root.getAsJsonObject("tabs").entrySet())
                    TAB_OF.put(en.getKey(), en.getValue().getAsString());
            }
            for (JsonElement e : arr(root, "decor")) {
                JsonObject o = e.getAsJsonObject();
                DECOR.add(new Decor(str(o, "id"), f(o, "strength"), i(o, "light")));
            }
        } catch (Exception ex) {
            throw new RuntimeException("Не удалось прочитать undermetro_content.json", ex);
        }
    }

    private static JsonArray arr(JsonObject o, String k) {
        return o.has(k) ? o.getAsJsonArray(k) : new JsonArray();
    }

    private static String str(JsonObject o, String k) {
        return o.get(k).getAsString();
    }

    private static int i(JsonObject o, String k) {
        return o.has(k) ? o.get(k).getAsInt() : 0;
    }

    private static float f(JsonObject o, String k) {
        return o.has(k) ? o.get(k).getAsFloat() : 0f;
    }

    private Content() {}
}
