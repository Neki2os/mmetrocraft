package dev.undermetro;

import dev.undermetro.worldgen.CityFeature;
import dev.undermetro.worldgen.MetroFeature;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.network.codec.ByteBufCodecs;
import com.mojang.serialization.Codec;
import java.util.EnumMap;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.FlintAndSteelItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.common.SimpleTier;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public final class ModRegistry {
    public static final String ID = UnderMetro.MODID;

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ID);
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, ID);
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(Registries.FEATURE, ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ID);
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(Registries.SOUND_EVENT, ID);
    public static final DeferredRegister<ArmorMaterial> ARMOR_MATERIALS = DeferredRegister.create(Registries.ARMOR_MATERIAL, ID);
    public static final DeferredRegister<DataComponentType<?>> COMPONENTS = DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, ID);

    /** Патронов в магазине. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> AMMO = COMPONENTS.register("ammo",
            () -> DataComponentType.<Integer>builder().persistent(Codec.INT).networkSynchronized(ByteBufCodecs.VAR_INT).build());
    /** Установленный в противогаз фильтр: id предмета и сколько ресурса уже израсходовано. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<String>> FILTER_KIND = COMPONENTS.register("filter_kind",
            () -> DataComponentType.<String>builder().persistent(Codec.STRING).networkSynchronized(ByteBufCodecs.STRING_UTF8).build());
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> FILTER_USED = COMPONENTS.register("filter_used",
            () -> DataComponentType.<Integer>builder().persistent(Codec.INT).networkSynchronized(ByteBufCodecs.VAR_INT).build());

    public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS = DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, ID);

    public static final TagKey<net.minecraft.world.item.Item> RECHARGEABLE = itemTag("rechargeable");
    public static final TagKey<net.minecraft.world.item.Item> FILTERS = itemTag("filters");
    public static final TagKey<net.minecraft.world.item.Item> DIGGING_TOOLS = itemTag("digging_tools");
    public static final TagKey<net.minecraft.world.item.Item> MASKS = itemTag("masks");
    public static final TagKey<net.minecraft.world.item.Item> BATTERIES = itemTag("batteries");
    public static final TagKey<net.minecraft.world.item.Item> HAZMAT = itemTag("hazmat");

    /** Все предметы мода по id (порядок = порядок в творческой вкладке). */
    public static final Map<String, Supplier<? extends Item>> ITEM_MAP = new LinkedHashMap<>();
    public static final List<DeferredBlock<MachineBlock>> MACHINE_BLOCKS = new ArrayList<>();

    public static final DeferredBlock<Block> EMERGENCY_FILTER;
    public static final DeferredBlock<Block> TRAP_BEAR = BLOCKS.registerBlock("trap_bear",
            p -> new ExtraItems.TrapBlock(p, ExtraItems.TrapBlock.Type.BEAR, "trap_bear"),
            BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(1f).sound(SoundType.CHAIN).noOcclusion().noCollission());
    public static final DeferredBlock<Block> TRAP_SNARE = BLOCKS.registerBlock("trap_snare",
            p -> new ExtraItems.TrapBlock(p, ExtraItems.TrapBlock.Type.SNARE, "trap_snare"),
            BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(0.5f).sound(SoundType.GRASS).noOcclusion().noCollission());
    public static final DeferredBlock<Block> MINE_TRIPWIRE = BLOCKS.registerBlock("mine_tripwire",
            p -> new ExtraItems.TrapBlock(p, ExtraItems.TrapBlock.Type.MINE, "mine_tripwire"),
            BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(0.5f).sound(SoundType.METAL).noOcclusion().noCollission());
    public static final DeferredBlock<Block> CANDLE = BLOCKS.registerBlock("candle",
            p -> new ExtraItems.SmallLightBlock(p, Block.box(6, 0, 6, 10, 6, 10)),
            BlockBehaviour.Properties.of().mapColor(MapColor.SAND).strength(0.1f).sound(SoundType.WOOL).noOcclusion().lightLevel(s -> 10));
    public static final DeferredBlock<Block> LANTERN = BLOCKS.registerBlock("lantern_oil",
            p -> new ExtraItems.SmallLightBlock(p, Block.box(4, 0, 4, 12, 9, 12)),
            BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(0.4f).sound(SoundType.LANTERN).noOcclusion().lightLevel(s -> 14));

    public static final DeferredHolder<AttachmentType<?>, AttachmentType<PlayerStats>> STATS =
            ATTACHMENTS.register("stats", () -> AttachmentType.serializable(PlayerStats::new).copyOnDeath().build());

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MachineBE>> MACHINE_BE =
            BLOCK_ENTITIES.register("machine", () -> BlockEntityType.Builder.of(MachineBE::new,
                    MACHINE_BLOCKS.stream().filter(b -> b.get().kind != MachineBlock.Kind.HATCH)
                            .map(Supplier::get).toArray(Block[]::new)).build(null));

    // --- сущности
    public static final DeferredHolder<EntityType<?>, EntityType<ModEntities.Shade>> SHADE = ENTITIES.register("shade",
            () -> EntityType.Builder.of(ModEntities.Shade::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(8).build("shade"));
    public static final DeferredHolder<EntityType<?>, EntityType<ModEntities.Crawler>> CRAWLER = ENTITIES.register("crawler",
            () -> EntityType.Builder.of(ModEntities.Crawler::new, MobCategory.MONSTER).sized(1.4f, 0.9f).clientTrackingRange(8).build("crawler"));
    public static final DeferredHolder<EntityType<?>, EntityType<ModEntities.Mutant>> MUTANT = ENTITIES.register("mutant",
            () -> EntityType.Builder.of(ModEntities.Mutant::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(8).build("mutant"));
    public static final DeferredHolder<EntityType<?>, EntityType<ModEntities.Screecher>> SCREECHER = ENTITIES.register("screecher",
            () -> EntityType.Builder.of(ModEntities.Screecher::new, MobCategory.MONSTER).sized(0.9f, 0.5f).clientTrackingRange(10).build("screecher"));
    public static final DeferredHolder<EntityType<?>, EntityType<ModEntities.Leech>> LEECH = ENTITIES.register("leech",
            () -> EntityType.Builder.of(ModEntities.Leech::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(8).build("leech"));
    public static final DeferredHolder<EntityType<?>, EntityType<ModEntities.Marauder>> MARAUDER = ENTITIES.register("marauder",
            () -> EntityType.Builder.of(ModEntities.Marauder::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(8).build("marauder"));
    public static final DeferredHolder<EntityType<?>, EntityType<ModEntities.Survivor>> SURVIVOR = ENTITIES.register("survivor",
            () -> EntityType.Builder.of(ModEntities.Survivor::new, MobCategory.CREATURE).sized(0.6f, 1.95f).clientTrackingRange(8).build("survivor"));
    public static final DeferredHolder<EntityType<?>, EntityType<ModEntities.ThrownBomb>> GRENADE = ENTITIES.register("grenade",
            () -> EntityType.Builder.of(ModEntities.ThrownBomb::new, MobCategory.MISC).sized(0.25f, 0.25f).clientTrackingRange(4).updateInterval(10).build("grenade"));
    public static final DeferredHolder<EntityType<?>, EntityType<ModEntities.ThrownBomb>> MOLOTOV = ENTITIES.register("molotov",
            () -> EntityType.Builder.of(ModEntities.ThrownBomb::new, MobCategory.MISC).sized(0.25f, 0.25f).clientTrackingRange(4).updateInterval(10).build("molotov"));
    public static final DeferredHolder<EntityType<?>, EntityType<ModEntities.RustBuggy>> BUGGY = ENTITIES.register("buggy",
            () -> EntityType.Builder.of(ModEntities.RustBuggy::new, MobCategory.MISC).sized(1.8f, 1.0f).clientTrackingRange(10).updateInterval(1).build("buggy"));

    // --- генерация мира
    public static final DeferredHolder<Feature<?>, MetroFeature> METRO_FEATURE =
            FEATURES.register("metro", () -> new MetroFeature(NoneFeatureConfiguration.CODEC));
    public static final DeferredHolder<Feature<?>, CityFeature> CITY_FEATURE =
            FEATURES.register("city", () -> new CityFeature(NoneFeatureConfiguration.CODEC));

    // --- звуки
    public static final Map<String, DeferredHolder<SoundEvent, SoundEvent>> SOUND_MAP = new LinkedHashMap<>();

    static {
        for (String s : new String[]{"shot_pistol", "shot_rifle", "shot_shotgun", "amb_metro", "amb_surface"}) {
            SOUND_MAP.put(s, SOUNDS.register(s, () -> SoundEvent.createVariableRangeEvent(rl(s))));
        }

        // Еда / напитки / лекарства
        for (Content.Consumable c : Content.CONSUMABLES) {
            item(c.id(), () -> {
                Item.Properties p = new Item.Properties().stacksTo(c.kind().equals("food") ? 16 : 8)
                        .food(new FoodProperties.Builder().nutrition(c.hunger()).saturationModifier(c.sat())
                                .alwaysEdible().build());
                return c.kind().equals("drink") ? new ModItems.DrinkItem(p) : new Item(p);
            });
        }

        // Холодное оружие
        for (Content.Melee m : Content.MELEE) {
            item(m.id(), () -> {
                Tier tier = new SimpleTier(BlockTags.INCORRECT_FOR_IRON_TOOL, m.durability(), 1.5f, 0f, 5, () -> Ingredient.EMPTY);
                return new SwordItem(tier, new Item.Properties().attributes(attrs(m.damage(), m.speed())));
            });
        }

        // Найденные инструменты (не крафтятся)
        for (Content.Tool t : Content.TOOLS) {
            item(t.id(), () -> {
                Tier tier = new SimpleTier(BlockTags.INCORRECT_FOR_IRON_TOOL, t.durability(), t.mineSpeed(), 0f, 5, () -> Ingredient.EMPTY);
                Item.Properties p = new Item.Properties().attributes(attrs(t.damage(), t.speed()));
                return switch (t.type()) {
                    case "pickaxe" -> new PickaxeItem(tier, p);
                    case "shovel" -> new ShovelItem(tier, p);
                    case "axe" -> new AxeItem(tier, p);
                    default -> new HoeItem(tier, p);
                };
            });
        }

        // Огнестрел
        for (Content.Gun g : Content.GUNS) {
            item(g.id(), () -> new ModItems.GunItem(new Item.Properties().durability(g.durability()).component(AMMO.get(), 0), g));
        }

        // Разное
        for (Content.Misc m : Content.MISC) {
            ArmorItem.Type armorType = switch (m.type()) {
                case "head" -> ArmorItem.Type.HELMET;
                case "chest" -> ArmorItem.Type.CHESTPLATE;
                case "legs" -> ArmorItem.Type.LEGGINGS;
                case "feet" -> ArmorItem.Type.BOOTS;
                default -> null;
            };
            // Материал брони регистрируем сразу (до фазы регистрации предметов), текстура: textures/models/armor/<id>_layer_1|2.png
            final Holder<ArmorMaterial> mat = armorType == null ? null : ARMOR_MATERIALS.register(m.id(), () -> {
                EnumMap<ArmorItem.Type, Integer> def = new EnumMap<>(ArmorItem.Type.class);
                for (ArmorItem.Type t : ArmorItem.Type.values()) def.put(t, t == armorType ? m.armor() : 0);
                return new ArmorMaterial(def, 0, SoundEvents.ARMOR_EQUIP_LEATHER, () -> Ingredient.EMPTY,
                        List.of(new ArmorMaterial.Layer(rl(m.id()))), 0f, 0f);
            });
            item(m.id(), () -> {
                Item.Properties p = new Item.Properties().stacksTo(m.stack());
                if (m.durability() > 0) p = new Item.Properties().durability(m.durability());
                if (mat != null) return new ArmorItem(mat, armorType, new Item.Properties().durability(m.durability() > 0 ? m.durability() : 300));
                Item extra = ExtraItems.create(m.id(), p);
                if (extra != null) return extra;
                return switch (m.type()) {
                    case "lighter" -> new FlintAndSteelItem(p);
                    case "flask" -> new ModItems.FlaskItem(p);
                    case "kit" -> new ModItems.VehicleKitItem(new Item.Properties().stacksTo(1));
                    case "grenade" -> new ModItems.BombItem(p, false);
                    case "molotov" -> new ModItems.BombItem(p, true);
                    default -> new Item(p);
                };
            });
        }

        // Аварийный фильтр (в стартовой комнате): работает без электричества.
        EMERGENCY_FILTER = BLOCKS.registerBlock("emergency_filter", Block::new,
                BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(5f, 9f).sound(SoundType.METAL).requiresCorrectToolForDrops());
        blockItem("emergency_filter", EMERGENCY_FILTER);

        // Электроника: 10 видов × 7 уровней. Уровни 2..7 крафтятся только по чертежу + 2 предмета прошлого уровня.
        for (MachineBlock.Kind kind : MachineBlock.Kind.values()) {
            int maxTier = kind.tiered() ? Grade.MAX : 1;
            for (int t = 1; t <= maxTier; t++) {
                final int tier = t;
                final MachineBlock.Kind k = kind;
                String name = machineName(kind, t);
                DeferredBlock<MachineBlock> b = BLOCKS.registerBlock(name, p -> new MachineBlock(p, k, tier), machineProps(kind, t));
                MACHINE_BLOCKS.add(b);
                blockItem(name, b);
                if (kind.tiered() && t > 1) item("blueprint_" + name, () -> new ModItems.BlueprintItem(new Item.Properties().stacksTo(1)));
            }
        }

        // Декоративные блоки (данные из undermetro_content.json -> "decor")
        for (Content.Decor d : Content.DECOR) {
            boolean lootable = d.id().startsWith("crate_") || d.id().startsWith("barrel_") || d.id().startsWith("locker_");
            DeferredBlock<Block> b = BLOCKS.registerBlock(d.id(), lootable ? (java.util.function.Function<BlockBehaviour.Properties, Block>)
                            (pp -> new ExtraItems.LootBlock(pp, ExtraItems.LootBlock.tableFor(d.id()))) : Block::new,
                    BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(d.strength(), d.strength() * 2f)
                            .sound(SoundType.STONE).requiresCorrectToolForDrops().lightLevel(s -> d.light()));
            blockItem(d.id(), b);
        }

        // Вкладки креатива: ключи и иконки заданы в undermetro_content.json -> "tab_defs", принадлежность предмета -> "tabs"
        for (Content.TabDef t : Content.TAB_DEFS) {
            TABS.register(t.key(), () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + ID + "." + t.key()))
                    .icon(() -> new ItemStack(item(t.icon())))
                    .displayItems((params, out) -> ITEM_MAP.forEach((id, sup) -> {
                        if (t.key().equals(Content.TAB_OF.getOrDefault(id, "components"))) out.accept(sup.get());
                    }))
                    .build());
        }
    }

    public static String machineName(MachineBlock.Kind kind, int tier) {
        return kind == MachineBlock.Kind.HATCH ? "hatch" : kind.id() + "_t" + tier;
    }

    private static BlockBehaviour.Properties machineProps(MachineBlock.Kind kind, int tier) {
        BlockBehaviour.Properties p = BlockBehaviour.Properties.of().mapColor(MapColor.METAL)
                .strength(3.5f + tier * 0.5f, 8f).sound(SoundType.METAL).requiresCorrectToolForDrops();
        return switch (kind) {
            case LAMP -> p.lightLevel(s -> s.getValue(MachineBlock.LIT) ? Grade.lampLight(tier) : 0);
            case GENERATOR -> p.lightLevel(s -> s.getValue(MachineBlock.LIT) ? 6 : 0);
            case AIR_FILTER -> p.lightLevel(s -> s.getValue(MachineBlock.LIT) ? 3 : 0);
            case ALARM -> p.lightLevel(s -> s.getValue(MachineBlock.LIT) ? 5 : 0);
            case GROW_TRAY -> p.lightLevel(s -> s.getValue(MachineBlock.LIT) ? 7 : 0);
            case DOOR, HATCH -> p.noOcclusion();
            default -> p;
        };
    }

    private static ItemAttributeModifiers attrs(double damage, double speed) {
        return ItemAttributeModifiers.builder()
                .add(Attributes.ATTACK_DAMAGE, new AttributeModifier(ResourceLocation.withDefaultNamespace("base_attack_damage"),
                        damage, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                .add(Attributes.ATTACK_SPEED, new AttributeModifier(ResourceLocation.withDefaultNamespace("base_attack_speed"),
                        speed, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                .build();
    }

    private static void item(String id, Supplier<? extends Item> factory) {
        ITEM_MAP.put(id, ITEMS.register(id, factory));
    }

    private static void blockItem(String id, Supplier<? extends Block> block) {
        item(id, () -> new BlockItem(block.get(), new Item.Properties()));
    }

    public static Item item(String id) {
        Supplier<? extends Item> s = ITEM_MAP.get(id);
        if (s == null) throw new IllegalArgumentException("Нет предмета undermetro:" + id);
        return s.get();
    }

    public static SoundEvent gunSound(String kind) {
        return switch (kind) {
            case "shotgun" -> SOUND_MAP.get("shot_shotgun").get();
            case "rifle" -> SOUND_MAP.get("shot_rifle").get();
            default -> SOUND_MAP.get("shot_pistol").get();
        };
    }

    public static ResourceLocation rl(String path) {
        return ResourceLocation.fromNamespaceAndPath(ID, path);
    }

    private static TagKey<net.minecraft.world.item.Item> itemTag(String name) {
        return TagKey.create(Registries.ITEM, rl(name));
    }

    public static void register(IEventBus bus) {
        ITEMS.register(bus);
        BLOCKS.register(bus);
        BLOCK_ENTITIES.register(bus);
        ENTITIES.register(bus);
        FEATURES.register(bus);
        TABS.register(bus);
        SOUNDS.register(bus);
        ATTACHMENTS.register(bus);
        ARMOR_MATERIALS.register(bus);
        COMPONENTS.register(bus);
    }

    private ModRegistry() {}
}
