package dev.undermetro;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

import java.util.ArrayDeque;
import java.util.HashSet;

/** Определение герметичности: заливка воздухом от точки; если «утекло» к небу или объём слишком большой — комната открыта. */
public final class AirLogic {
    public static final int OPEN = 0;
    public static final int SEALED = 1;
    public static final int SEALED_FILTERED = 2;

    public static final int MAX_VOLUME = 3500;

    public static int scan(Level level, BlockPos start) {
        if (!level.isLoaded(start)) return OPEN;
        if (!passable(level, start)) return OPEN;
        HashSet<Long> seen = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        queue.add(start);
        seen.add(start.asLong());
        boolean filtered = false;
        int count = 0;
        while (!queue.isEmpty()) {
            BlockPos p = queue.poll();
            if (++count > MAX_VOLUME) return OPEN;
            if (level.canSeeSky(p)) return OPEN;
            for (Direction d : Direction.values()) {
                BlockPos n = p.relative(d);
                if (!level.isLoaded(n)) return OPEN;
                if (seen.contains(n.asLong())) continue;
                BlockState st = level.getBlockState(n);
                if (st.getCollisionShape(level, n).isEmpty()) {
                    seen.add(n.asLong());
                    queue.add(n);
                } else if (isWorkingFilter(st)) {
                    filtered = true;
                }
            }
        }
        return filtered ? SEALED_FILTERED : SEALED;
    }

    private static boolean passable(Level level, BlockPos p) {
        return level.getBlockState(p).getCollisionShape(level, p).isEmpty();
    }

    public static boolean isWorkingFilter(BlockState st) {
        if (st.is(ModRegistry.EMERGENCY_FILTER.get())) return true;
        return st.getBlock() instanceof MachineBlock mb
                && mb.kind == MachineBlock.Kind.AIR_FILTER
                && st.getValue(BlockStateProperties.LIT);
    }

    private AirLogic() {}
}
