package dev.undermetro;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Серверная обработка клавиш: перезарядка, смена батарейки фонарика, смена фильтра противогаза. */
public final class Actions {
    public static final int RELOAD = 0, BATTERY = 1, FILTER = 2, SHOOT = 3, CLOCK = 4;

    public static void handle(ServerPlayer p, int action, int arg) {
        if (p.isSpectator()) return;
        switch (action) {
            case RELOAD -> reload(p);
            case BATTERY -> battery(p);
            case FILTER -> filter(p);
            case SHOOT -> shoot(p, arg != 0);
            default -> {}
        }
    }

    private static void shoot(ServerPlayer p, boolean aiming) {
        for (net.minecraft.world.InteractionHand h : net.minecraft.world.InteractionHand.values()) {
            ItemStack s = p.getItemInHand(h);
            if (s.getItem() instanceof ModItems.GunItem g) {
                g.tryShoot(p, h, aiming);
                return;
            }
        }
    }

    private static void reload(ServerPlayer p) {
        for (ItemStack s : new ItemStack[]{p.getMainHandItem(), p.getOffhandItem()}) {
            if (s.getItem() instanceof ModItems.GunItem g) {
                g.reload(p, s);
                return;
            }
        }
        p.displayClientMessage(Component.translatable("msg.undermetro.no_gun"), true);
    }

    private static int remaining(ItemStack s) {
        return s.getMaxDamage() - s.getDamageValue();
    }

    /** Переливает заряд из лучшей батарейки в фонарик (фонарик берётся из рук, иначе из инвентаря). */
    private static void battery(ServerPlayer p) {
        ItemStack flash = ItemStack.EMPTY;
        for (ItemStack s : new ItemStack[]{p.getMainHandItem(), p.getOffhandItem()})
            if (isFlashlight(s)) { flash = s; break; }
        if (flash.isEmpty())
            for (ItemStack s : p.getInventory().items)
                if (isFlashlight(s) && s.isDamaged()) { flash = s; break; }
        if (flash.isEmpty()) {
            p.displayClientMessage(Component.translatable("msg.undermetro.no_flashlight"), true);
            return;
        }
        if (!flash.isDamaged()) {
            p.displayClientMessage(Component.translatable("msg.undermetro.flashlight_full"), true);
            return;
        }
        ItemStack best = ItemStack.EMPTY;
        for (ItemStack s : p.getInventory().items)
            if (s.is(ModRegistry.BATTERIES) && remaining(s) > 0 && (best.isEmpty() || remaining(s) > remaining(best))) best = s;
        if (best.isEmpty()) {
            p.displayClientMessage(Component.translatable("msg.undermetro.no_battery"), true);
            return;
        }
        int amount = Math.min(flash.getDamageValue(), remaining(best));
        flash.setDamageValue(flash.getDamageValue() - amount);
        best.setDamageValue(best.getDamageValue() + amount);
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.ARMOR_EQUIP_CHAIN.value(), SoundSource.PLAYERS, 0.8f, 1.6f);
        p.displayClientMessage(Component.translatable("msg.undermetro.battery_swapped",
                (flash.getMaxDamage() - flash.getDamageValue()) * 100 / Math.max(1, flash.getMaxDamage())), true);
    }

    private static boolean isFlashlight(ItemStack s) {
        return !s.isEmpty() && BuiltInRegistries.ITEM.getKey(s.getItem()).getPath().startsWith("flashlight");
    }

    private static String idOf(ItemStack s) {
        return BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
    }

    /** Фильтр: ставит лучший из инвентаря; если стоит — меняет на лучший, а если лучшего нет — снимает. */
    private static void filter(ServerPlayer p) {
        ItemStack mask = p.getItemBySlot(EquipmentSlot.HEAD);
        if (mask.isEmpty() || !mask.is(ModRegistry.MASKS)) {
            p.displayClientMessage(Component.translatable("msg.undermetro.need_mask"), true);
            return;
        }
        String curKind = mask.get(ModRegistry.FILTER_KIND.get());
        int curUsed = mask.getOrDefault(ModRegistry.FILTER_USED.get(), 0);
        boolean hasCur = curKind != null && !curKind.isEmpty();
        int curLeft = 0;
        if (hasCur) {
            Item ci = BuiltInRegistries.ITEM.get(ResourceLocation.fromNamespaceAndPath(UnderMetro.MODID, curKind));
            curLeft = new ItemStack(ci).getMaxDamage() - curUsed;
        }
        ItemStack best = ItemStack.EMPTY;
        for (ItemStack s : p.getInventory().items)
            if (s.is(ModRegistry.FILTERS) && remaining(s) > 0 && (best.isEmpty() || remaining(s) > remaining(best))) best = s;

        if (hasCur && (best.isEmpty() || remaining(best) <= curLeft)) {
            // снять
            giveBack(p, curKind, curUsed);
            mask.remove(ModRegistry.FILTER_KIND.get());
            mask.remove(ModRegistry.FILTER_USED.get());
            p.displayClientMessage(Component.translatable("msg.undermetro.filter_removed"), true);
            return;
        }
        if (best.isEmpty()) {
            p.displayClientMessage(Component.translatable("msg.undermetro.no_filter_item"), true);
            return;
        }
        if (hasCur) giveBack(p, curKind, curUsed);
        String kind = idOf(best);
        int used = best.getDamageValue();
        best.shrink(1);
        mask.set(ModRegistry.FILTER_KIND.get(), kind);
        mask.set(ModRegistry.FILTER_USED.get(), used);
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.ARMOR_EQUIP_IRON.value(), SoundSource.PLAYERS, 0.8f, 1.2f);
        p.displayClientMessage(Component.translatable("msg.undermetro.filter_installed"), true);
    }

    private static void giveBack(ServerPlayer p, String kind, int used) {
        Item it = BuiltInRegistries.ITEM.get(ResourceLocation.fromNamespaceAndPath(UnderMetro.MODID, kind));
        ItemStack st = new ItemStack(it);
        if (used >= st.getMaxDamage()) return; // отработан
        st.setDamageValue(used);
        if (!p.getInventory().add(st)) p.drop(st, false);
    }

    private Actions() {}
}
