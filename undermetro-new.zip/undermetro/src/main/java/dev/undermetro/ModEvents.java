package dev.undermetro;

import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.tags.FluidTags;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;

/** События mod-шины: атрибуты существ, правила спавна, capability энергии. */
@EventBusSubscriber(modid = UnderMetro.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class ModEvents {

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent e) {
        e.put(ModRegistry.SHADE.get(), ModEntities.Shade.createAttributes().build());
        e.put(ModRegistry.CRAWLER.get(), ModEntities.Crawler.createAttributes().build());
        e.put(ModRegistry.MUTANT.get(), ModEntities.Mutant.createAttributes().build());
        e.put(ModRegistry.SCREECHER.get(), ModEntities.Screecher.createAttributes().build());
        e.put(ModRegistry.LEECH.get(), ModEntities.Leech.createAttributes().build());
        e.put(ModRegistry.MARAUDER.get(), ModEntities.Marauder.createAttributes().build());
        e.put(ModRegistry.SURVIVOR.get(), ModEntities.Survivor.createAttributes().build());
    }

    @SubscribeEvent
    public static void spawns(RegisterSpawnPlacementsEvent e) {
        var op = RegisterSpawnPlacementsEvent.Operation.REPLACE;
        // Тень и паук — только в темноте (стандартное правило монстров).
        e.register(ModRegistry.SHADE.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkMonsterSpawnRules, op);
        e.register(ModRegistry.CRAWLER.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Monster::checkMonsterSpawnRules, op);
        // Мутанты, мародёры и летуны спавнятся при любом освещении.
        e.register(ModRegistry.MUTANT.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (t, l, r, p, rnd) -> l.getDifficulty() != Difficulty.PEACEFUL && Mob.checkMobSpawnRules(t, l, r, p, rnd), op);
        e.register(ModRegistry.MARAUDER.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (t, l, r, p, rnd) -> l.getDifficulty() != Difficulty.PEACEFUL && Mob.checkMobSpawnRules(t, l, r, p, rnd), op);
        e.register(ModRegistry.SCREECHER.get(), SpawnPlacementTypes.NO_RESTRICTIONS, Heightmap.Types.MOTION_BLOCKING,
                (t, l, r, p, rnd) -> l.getDifficulty() != Difficulty.PEACEFUL && l.canSeeSky(p), op);
        e.register(ModRegistry.LEECH.get(), SpawnPlacementTypes.IN_WATER, Heightmap.Types.OCEAN_FLOOR,
                (t, l, r, p, rnd) -> l.getDifficulty() != Difficulty.PEACEFUL && l.getFluidState(p).is(FluidTags.WATER), op);
        e.register(ModRegistry.SURVIVOR.get(), SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Mob::checkMobSpawnRules, op);
    }

    @SubscribeEvent
    public static void capabilities(RegisterCapabilitiesEvent e) {
        e.registerBlockEntity(Capabilities.EnergyStorage.BLOCK, ModRegistry.MACHINE_BE.get(), (be, side) -> be.energy);
    }

    private ModEvents() {}
}
