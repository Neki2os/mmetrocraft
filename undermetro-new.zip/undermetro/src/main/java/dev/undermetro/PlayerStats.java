package dev.undermetro;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.common.util.INBTSerializable;

/** Дополнительные параметры игрока (хранятся как Data Attachment). Здоровье и голод — ванильные. */
public class PlayerStats implements INBTSerializable<CompoundTag> {
    public static final int HUNGER = 0, THIRST = 1, STRENGTH = 2, ACCURACY = 3, STAMINA = 4;
    public static final String[] SKILL_NAMES = {"hunger", "thirst", "strength", "accuracy", "stamina"};
    public static final int MAX_LEVEL = 10;

    public float thirst = 100f;
    public float stamina = 100f;
    /** Заражение 0..100. */
    public float rad = 0f;
    /** Чистота воздуха вокруг игрока 0..100 (в герметичной комнате с фильтром растёт). */
    public float purity = 100f;
    public boolean spawned = false;
    /** Остаток активного фильтра (не сохраняется, только для HUD): -1 — не используется. */
    public transient int filterPct = -1;
    /** Текущая «доза» для счётчика Гейгера (не сохраняется). */
    public transient int dose = 0;
    public final int[] level = new int[5];
    public final float[] xp = new float[5];

    public static PlayerStats get(net.minecraft.world.entity.player.Player p) {
        return p.getData(ModRegistry.STATS);
    }

    public static float xpNeeded(int lvl) {
        return 120f * (lvl + 1);
    }

    public void addXp(ServerPlayer player, int skill, float amount) {
        if (level[skill] >= MAX_LEVEL) return;
        xp[skill] += amount;
        while (level[skill] < MAX_LEVEL && xp[skill] >= xpNeeded(level[skill])) {
            xp[skill] -= xpNeeded(level[skill]);
            level[skill]++;
            player.displayClientMessage(Component.translatable("msg.undermetro.skill_up",
                    Component.translatable("skill.undermetro." + SKILL_NAMES[skill]), level[skill]), false);
        }
    }

    @Override
    public CompoundTag serializeNBT(HolderLookup.Provider provider) {
        CompoundTag t = new CompoundTag();
        t.putFloat("thirst", thirst);
        t.putFloat("stamina", stamina);
        t.putFloat("rad", rad);
        t.putFloat("purity", purity);
        t.putBoolean("spawned", spawned);
        t.putIntArray("level", level);
        for (int i = 0; i < xp.length; i++) t.putFloat("xp" + i, xp[i]);
        return t;
    }

    @Override
    public void deserializeNBT(HolderLookup.Provider provider, CompoundTag t) {
        thirst = t.contains("thirst") ? t.getFloat("thirst") : 100f;
        stamina = t.contains("stamina") ? t.getFloat("stamina") : 100f;
        rad = t.getFloat("rad");
        purity = t.contains("purity") ? t.getFloat("purity") : 100f;
        spawned = t.getBoolean("spawned");
        int[] l = t.getIntArray("level");
        for (int i = 0; i < Math.min(l.length, level.length); i++) level[i] = l[i];
        for (int i = 0; i < xp.length; i++) xp[i] = t.getFloat("xp" + i);
    }

    public void copyFrom(PlayerStats o) {
        // При смерти навыки сохраняются, а состояние сбрасывается.
        System.arraycopy(o.level, 0, level, 0, level.length);
        System.arraycopy(o.xp, 0, xp, 0, xp.length);
        spawned = o.spawned;
    }
}
