package dev.undermetro;

import com.mojang.brigadier.Command;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/** /skills — показать уровни навыков (голод, жажда, сила, меткость, стамина). */
@EventBusSubscriber(modid = UnderMetro.MODID)
public final class SkillsCommand {
    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("skills").executes(ctx -> {
            ServerPlayer p = ctx.getSource().getPlayerOrException();
            PlayerStats st = PlayerStats.get(p);
            for (int i = 0; i < 5; i++) {
                int pct = st.level[i] >= PlayerStats.MAX_LEVEL ? 100
                        : Math.round(st.xp[i] / PlayerStats.xpNeeded(st.level[i]) * 100f);
                p.sendSystemMessage(Component.translatable("skill.undermetro." + PlayerStats.SKILL_NAMES[i])
                        .append(Component.literal(": " + st.level[i] + "/" + PlayerStats.MAX_LEVEL + " (" + pct + "%)")));
            }
            return Command.SINGLE_SUCCESS;
        }));
    }

    private SkillsCommand() {}
}
