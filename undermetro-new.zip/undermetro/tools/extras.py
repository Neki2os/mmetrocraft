"""Доп. ресурсы v0.5: блоки-ловушки/свет, лут контейнеров, переводы интерфейса и книг."""
import json
import os
import zlib

import models as MD

RADIO_EN = [
    "…this is Polis Station. All sectors: surface radiation rising. Keep your filters…",
    "…bandits at the Red Line junction. Avoid the east tunnel. Repeat: avoid…",
    "…trading caravan arrives at dawn. Casings accepted. No credit. No credit…",
    "…if you can hear this, we are still here. Third tunnel, under the lamp…",
    "…shshsh… the rain is bad today. Do not go up without a suit. Do not…",
    "…lost a patrol near the hospital. Something is nesting there. Stay away…",
    "…clean water for casings, Teatralnaya platform. Bring your own flask…",
    "…[static]… … …seven… four… nine… [static]",
    "…radiation front moving west. Seal your doors. Check your seals twice…",
    "…music? Someone left a tape player running in the tunnels. It's… calming…",
]
RADIO_RU = [
    "…говорит станция Полис. Всем секторам: фон на поверхности растёт. Берегите фильтры…",
    "…бандиты на развилке Красной ветки. Восточный тоннель не использовать. Повторяю…",
    "…караван торговцев прибудет к рассвету. Гильзы принимаем. В долг не даём. В долг не…",
    "…если слышите, мы ещё здесь. Третий тоннель, под лампой…",
    "…шшш… сегодня плохой дождь. Не выходите наверх без костюма. Не выходи…",
    "…потеряли дозор у больницы. Там что-то поселилось. Держитесь подальше…",
    "…чистая вода за гильзы, платформа Театральная. Флягу приносите свою…",
    "…[помехи]… … …семь… четыре… девять… [помехи]",
    "…фронт радиации идёт на запад. Закройте гермодвери. Проверьте уплотнители дважды…",
    "…музыка? Кто-то оставил в тоннелях включённый плеер. Это… успокаивает…",
]

LORE_EN = {
    "note_old": "Day 41. Filters are almost gone. Mikhail went up for the pharmacy and didn't come back.|If you find this: the green locker in the third tunnel still has two cartridges.",
    "vodka_crate_note": "Delivery: 12 crates of 'Northern Lights'. Payment: 3 gold casings per crate.|Note: the driver won't go past the bridge anymore. Says something is sitting on the rails.",
    "journal_old": "…the lamps flicker when they are near. Not the cheap ones — the good ones, tier 3 and up.|Shades hate light. Spiders hate fire. Everything else just hates us.|Never drink water from the surface. Boil it or filter it. Even then — don't.",
    "book_survival": "SURVIVAL HANDBOOK|1. A sealed room + a working air filter = clean air. Dig carefully: opening the seal poisons the air.|2. Surface water is dirty. Boil it, use tablets, or a water filter.|3. Stone does not yield to bare hands: find a pickaxe.|4. Press R to reload, B to swap a flashlight battery, V to swap a mask filter.",
    "book_medical": "FIELD MEDICINE|Bandage stops bleeding. Antirad pills remove infection. Stimulants cost you later.|Infection above 50% weakens you; above 75% it kills. A clean sealed room lets the body recover.",
    "book_engineering": "ENGINEERING NOTES|Only Mk.1 devices can be built from scrap. Higher tiers need a blueprint plus two devices of the previous tier.|Blueprints are found in laboratories and rare caches. The blueprint is never consumed.|Batteries recharge on an accumulator: right-click it with the item.",
    "map_metro": "Hand-drawn map of the metro. The lines run in a grid. Every sixty-four blocks a tunnel. Stations hold the best loot — and the worst company.",
    "map_city": "City sketch. Districts of eight blocks by eight. Hospitals, police, firehouses, military posts and laboratories are marked with a cross.",
    "tape_cassette": "The label reads: 'Songs for the end of the world, vol. 2'. You need a player.",
    "toy_old": "A small plastic bear. Someone loved it very much.",
    "playing_cards": "A worn deck. The ace of spades is missing.",
    "walkman": "A cassette player. The batteries are long dead. The tape still has someone's voice on it.",
}
LORE_RU = {
    "note_old": "День 41. Фильтры почти кончились. Михаил ушёл наверх за аптекой и не вернулся.|Если нашли это: в зелёном шкафчике в третьем тоннеле остались два патрона.",
    "vodka_crate_note": "Поставка: 12 ящиков «Северного сияния». Оплата: 3 золотые гильзы за ящик.|Примечание: водитель дальше моста не едет. Говорит, на рельсах что-то сидит.",
    "journal_old": "…лампы мигают, когда они рядом. Не дешёвые — хорошие, третьего уровня и выше.|Тени ненавидят свет. Пауки ненавидят огонь. Остальные просто ненавидят нас.|Никогда не пей воду сверху. Кипяти или фильтруй. Да и тогда — не пей.",
    "book_survival": "СПРАВОЧНИК ВЫЖИВАЛЬЩИКА|1. Герметичная комната + рабочий воздушный фильтр = чистый воздух. Копайте осторожно: вскрытая герметичность отравляет воздух.|2. Вода сверху грязная. Кипятите, используйте таблетки или фильтр воды.|3. Камень не поддаётся голым рукам: найдите кирку.|4. R — перезарядка, B — сменить батарейку фонарика, V — сменить фильтр противогаза.",
    "book_medical": "ПОЛЕВАЯ МЕДИЦИНА|Бинт останавливает кровь. Антирадин снимает заражение. Стимуляторы потом аукнутся.|Заражение выше 50% ослабляет, выше 75% убивает. В чистой герметичной комнате организм восстанавливается.",
    "book_engineering": "ИНЖЕНЕРНЫЕ ЗАМЕТКИ|Из хлама собираются только устройства Мк.1. Старшие уровни — чертёж плюс два устройства предыдущего уровня.|Чертежи лежат в лабораториях и редких тайниках. Чертёж не расходуется.|Батарейки заряжаются на аккумуляторе: ПКМ предметом по нему.",
    "map_metro": "Нарисованная от руки схема метро. Ветки идут сеткой. Каждые шестьдесят четыре блока — тоннель. На станциях лучшая добыча — и худшая компания.",
    "map_city": "Набросок города. Районы восемь на восемь. Больницы, полиция, пожарные, военные посты и лаборатории отмечены крестиками.",
    "tape_cassette": "На этикетке: «Песни на конец света, том 2». Нужен плеер.",
    "toy_old": "Маленький пластиковый медвежонок. Кто-то очень его любил.",
    "playing_cards": "Потёртая колода. Пикового туза нет.",
    "walkman": "Кассетный плеер. Батарейки давно сели. На плёнке до сих пор чей-то голос.",
}


def lang(A, en, ru):
    for code, extra in (("en_us", en), ("ru_ru", ru)):
        p = f"{A}/lang/{code}.json"
        d = json.load(open(p, encoding="utf-8"))
        d.update(extra)
        json.dump(d, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=2)


def block_models(A, MOD):
    def save(name, m, seed):
        img, ks = m.texture(seed)
        os.makedirs(f"{A}/textures/block", exist_ok=True)
        img.save(f"{A}/textures/block/{name}.png")
        els = m.json(ks, None)
        data = {"parent": "minecraft:block/block", "textures": {"p": f"{MOD}:block/{name}", "particle": f"{MOD}:block/{name}"}, "elements": els}
        os.makedirs(f"{A}/models/block", exist_ok=True)
        json.dump(data, open(f"{A}/models/block/{name}.json", "w"), separators=(",", ":"))

    # капкан раскрытый / закрытый
    m = MD.Model()
    m.S(2, 14, 0, 0.8, 5, "d")
    m.S(6.5, 9.5, 0.8, 1.6, 1.5, "M")  # тарелка
    for sgn in (-1, 1):
        for i in range(6):
            z = 8 + sgn * (1.2 + i * 0.9)
            m.box(2 + i * 0.4, 0.8, z - 0.3, 2.8 + i * 0.4, 2.4 + (i % 2) * 0.8, z + 0.3, "s")
            m.box(13.2 - i * 0.4, 0.8, z - 0.3, 14 - i * 0.4, 2.4 + (i % 2) * 0.8, z + 0.3, "s")
    m.S(1, 15, 0.8, 1.4, 0.3, "R", zc=3.4)
    m.S(1, 15, 0.8, 1.4, 0.3, "R", zc=12.6)
    save("trap_bear", m, 1)
    m = MD.Model()
    m.S(2, 14, 0, 0.8, 5, "d")
    m.S(2, 14, 0.8, 3.2, 1.2, "s", zc=8)
    for i in range(6):
        m.box(2 + i * 2, 3.2, 7.6, 2.8 + i * 2, 4.4, 8.4, "s")
    m.S(6.5, 9.5, 0.8, 1.6, 1.5, "M")
    save("trap_bear_snapped", m, 2)
    # петля
    m = MD.Model({"L": "#8a7a5a"})
    for x1, x2, z1, z2 in ((4, 12, 4, 5), (4, 12, 11, 12), (4, 5, 4, 12), (11, 12, 4, 12)):
        m.box(x1, 0, z1, x2, 0.8, z2, "L")
    m.box(1, 0, 7.5, 4, 0.8, 8.5, "L")
    m.box(1, 0, 6.5, 2, 3, 7.5, "w")
    m.box(1, 0, 8.5, 2, 3, 9.5, "w")
    save("trap_snare", m, 3)
    # растяжка
    m = MD.Model()
    m.S(6, 10, 0, 3, 1.5, "G", zc=8)
    m.S(7, 9, 3, 3.6, 1, "k")
    m.box(7.8, 3.6, 7.8, 8.2, 4.8, 8.2, "M")
    m.box(0, 0.6, 7.9, 6, 0.9, 8.1, "d")
    m.box(10, 0.6, 7.9, 16, 0.9, 8.1, "d")
    save("mine_tripwire", m, 4)
    # свеча
    m = MD.Model({"t": "#eee3c2"})
    m.S(5, 11, 0, 0.6, 3, "d")
    m.S(7, 9, 0.6, 5, 1, "t")
    m.S(7.8, 8.2, 5, 5.8, 0.2, "k")
    m.S(7.6, 8.4, 5.8, 7, 0.4, "o")
    m.S(7.8, 8.2, 6.2, 6.6, 0.45, "y")
    save("candle", m, 5)
    # керосиновая лампа
    m = MD.Model({"G": "#c8a82a"})
    m.S(4.5, 11.5, 0, 1.5, 3.5, "d", zc=8)
    m.S(5, 11, 1.5, 7.5, 3, "l")
    m.S(7.2, 8.8, 1.6, 4.5, 0.8, "y")
    m.S(7.6, 8.4, 4.5, 6.5, 0.5, "o")
    m.S(4.5, 11.5, 7.5, 9, 3.5, "d")
    m.S(6.5, 9.5, 9, 9.8, 0.4, "M")
    m.S(5.5, 10.5, 9.8, 10.4, 0.3, "M")
    save("lantern_oil", m, 6)
    # блокстейты
    for n in ("trap_bear",):
        json.dump({"variants": {"snapped=false": {"model": f"{MOD}:block/{n}"}, "snapped=true": {"model": f"{MOD}:block/{n}_snapped"}}},
                  open(f"{A}/blockstates/{n}.json", "w"))
    for n in ("trap_snare", "mine_tripwire"):
        json.dump({"variants": {"snapped=false": {"model": f"{MOD}:block/{n}"}, "snapped=true": {"model": f"{MOD}:block/{n}"}}},
                  open(f"{A}/blockstates/{n}.json", "w"))
    for n in ("candle", "lantern_oil"):
        json.dump({"variants": {"": {"model": f"{MOD}:block/{n}"}}}, open(f"{A}/blockstates/{n}.json", "w"))
    for n in ("trap_bear", "trap_snare", "mine_tripwire", "candle", "lantern_oil"):
        # предмет показывает 3D-модель блока
        json.dump({"parent": f"{MOD}:block/{n}"}, open(f"{A}/models/item/{n}.json", "w"))


def containers(g):
    D, MOD = g["D"], g["MOD"]
    entry, table, pool, write = g["entry"], g["table"], g["pool"], g["write"]
    CONS, MELEE, TOOLS, GUNS, MISC = g["CONSUMABLES"], g["MELEE"], g["TOOLS"], g["GUNS"], g["MISC"]
    allids = {r[0] for r in CONS + MELEE + TOOLS + GUNS + MISC}
    ex = lambda L: [i for i in L if i in allids]  # noqa
    food = [r[0] for r in CONS if r[3] == "food"]
    drinks = [r[0] for r in CONS if r[3] == "drink"]
    meds = [r[0] for r in CONS if r[3] == "med"]
    ammo = [r[0] for r in MISC if r[0].startswith("ammo_") and r[0] != "ammo_flare"]
    gren = [r[0] for r in MISC if r[3] in ("grenade", "molotov")]
    armor = [r[0] for r in MISC if r[3] in ("head", "chest", "legs", "feet") and not r[0].startswith(("gas_mask", "hazmat", "respirator"))]
    comp = ex(["circuit_board", "capacitor", "transistor", "microchip", "wire_copper", "wire_aluminium", "wire_steel", "relay", "fuse",
               "battery_small", "battery_medium", "processor", "display", "solar_cell", "magnet", "motor_small", "coil_copper"])
    junk = ex(["cloth_scrap", "nails", "rope", "bolts_nuts", "scrap_metal", "glass_shards", "plastic_scrap", "duct_tape", "glue", "leather_scrap",
               "thread_spool", "rubber", "aluminium_scrap", "copper_scrap"])
    filt = [r[0] for r in MISC if r[3] == "filter"]
    W = lambda L, w=4, a=1, b=1: [entry(i, w, a, b) for i in L]  # noqa
    ct = f"{D}/loot_table/containers"
    T = {
        "crate_food": [pool(2, 4, W(food, 5) + W(drinks, 4)), pool(0, 1, W(ex(["canned_stew", "ration_pack"]), 3, 1, 2))],
        "crate_medical": [pool(2, 4, W(meds, 4)), pool(0, 1, W(ex(["bandage", "antirad_pills"]), 4, 1, 3))],
        "crate_ammo": [pool(2, 3, W(ammo, 4, 6, 24)), pool(0, 1, W(gren, 2))],
        "crate_military": [pool(1, 3, W(ammo, 4, 8, 30)), pool(0, 2, W(gren, 3)), pool(0, 1, W([r[0] for r in GUNS][:20], 2)), pool(0, 1, W(armor, 2))],
        "crate_tools": [pool(2, 3, W(junk, 4, 1, 4)), pool(0, 1, W(ex(["repair_kit", "toolbox", "cleaning_kit", "gun_oil"]), 3)),
                        pool(0, 1, W([r[0] for r in TOOLS] + [r[0] for r in MELEE], 1))],
        "crate_electronics": [pool(2, 4, W(comp, 4, 1, 3))],
        "crate_fuel": [pool(1, 3, W(ex(["canister_empty", "canister_fuel", "canister_empty_big", "lubricant", "fuel_additive", "fuel_clean"]), 3))],
        "crate_supply": [pool(2, 4, W(food + drinks + meds, 3)), pool(0, 2, W(filt, 2) + W(ex(["battery_small", "flashlight"]), 3))],
        "crate_wood": [pool(1, 3, W(junk, 4, 1, 3))],
        "crate_toxic": [pool(1, 3, W(ex(["chemicals", "acid", "battery_acid", "sulfur", "saltpeter", "pure_alcohol"]), 3)), pool(0, 1, W(filt, 2))],
        "barrel_fuel": [pool(1, 2, W(ex(["canister_fuel", "canister_empty", "fuel_raw", "oil_raw"]), 3))],
        "barrel_water": [pool(1, 2, W(ex(["dirty_water", "flask_empty"]), 4, 1, 2))],
        "barrel_toxic": [pool(1, 2, W(ex(["chemicals", "acid", "battery_acid", "sulfur"]), 3)), pool(0, 1, W(ex(["lead_ingot"]), 1))],
        "barrel_misc": [pool(1, 2, W(junk, 4, 1, 3))],
        "locker": [pool(1, 2, W(armor, 3)), pool(0, 2, W(ex(["flashlight", "battery_small", "repair_kit", "key_card", "key_rusty", "lighter", "watch_wrist"]), 3)),
                   pool(0, 1, W([r[0] for r in GUNS if r[0].startswith(("pistol", "revolver"))], 1))],
    }
    for k, pools in T.items():
        pools = [p for p in pools if p["entries"]]
        write(f"{ct}/{k}.json", table(pools))


def build_extras(g):
    A, MOD = g["A"], g["MOD"]
    block_models(A, MOD)
    for n in ("trap_bear", "trap_snare", "mine_tripwire", "candle", "lantern_oil"):
        g["write"](f"{g['D']}/loot_table/blocks/{n}.json", {"type": "minecraft:block", "pools": [{"rolls": 1.0, "bonus_rolls": 0.0,
                   "entries": [{"type": "minecraft:item", "name": f"{MOD}:{n}"}], "conditions": [{"condition": "minecraft:survives_explosion"}]}],
                   "random_sequence": f"{MOD}:blocks/{n}"})
    containers(g)
    en, ru = {}, {}
    for k, e, r in (
        ("tab.undermetro.inventory", "Inventory", "Инвентарь"), ("tab.undermetro.skills", "Skills", "Навыки"), ("tab.undermetro.guide", "Ammo Guide", "Патроны"),
        ("ui.undermetro.skills_title", "SKILL TREE", "ДРЕВО НАВЫКОВ"), ("ui.undermetro.guide_title", "AMMO GUIDE — WHAT FITS WHAT", "СПРАВОЧНИК: КАКИЕ ПАТРОНЫ К КАКОМУ ОРУЖИЮ"),
        ("ui.undermetro.skill_node", "Level %s: %s", "Уровень %s: %s"), ("ui.undermetro.skill_progress", "Progress to next level: %s%%", "До следующего уровня: %s%%"),
        ("ui.undermetro.variants", "Also: %s", "Также: %s"), ("ui.undermetro.gun_stats", "mag %s · dmg %s", "магазин %s · урон %s"),
        ("skill.undermetro.hunger.bonus", "+%s%% chance each second to restore hunger", "+%s%% шанс каждую секунду восстановить сытость"),
        ("skill.undermetro.thirst.bonus", "-%s%% thirst loss", "-%s%% к потере жажды"),
        ("skill.undermetro.strength.bonus", "+%s%% melee damage", "+%s%% к урону в ближнем бою"),
        ("skill.undermetro.accuracy.bonus", "-%s%% weapon spread", "-%s%% к разбросу оружия"),
        ("skill.undermetro.stamina.bonus", "-%s%% stamina drain", "-%s%% к расходу выносливости"),
        ("skill.undermetro.hunger.how", "Grows while you are hungry.", "Растёт, пока вы голодны."),
        ("skill.undermetro.thirst.how", "Grows while you are thirsty.", "Растёт, пока вы мучаетесь от жажды."),
        ("skill.undermetro.strength.how", "Grows from melee hits.", "Растёт от ударов в ближнем бою."),
        ("skill.undermetro.accuracy.how", "Grows from hitting targets with firearms.", "Растёт от попаданий из огнестрела."),
        ("skill.undermetro.stamina.how", "Grows from sprinting.", "Растёт от бега."),
        ("msg.undermetro.clock", "Time %s · day %s", "Время %s · день %s"), ("msg.undermetro.radio_static", "*static*", "*шипение*"),
        ("msg.undermetro.nothing_to_repair", "Nothing to repair", "Нечего чинить"), ("msg.undermetro.repaired", "Repaired: %s", "Починено: %s"),
        ("msg.undermetro.camp_set", "Camp set. You will respawn here.", "Лагерь разбит. Вы возродитесь здесь."),
        ("msg.undermetro.compass", "Facing %s · %s %s %s", "Курс: %s · %s %s %s"),
        ("dir.undermetro.n", "North", "Север"), ("dir.undermetro.s", "South", "Юг"), ("dir.undermetro.e", "East", "Восток"), ("dir.undermetro.w", "West", "Запад"),
        ("tip.undermetro.ammo", "Ammo: %s", "Патроны: %s"), ("tip.undermetro.gun_stats", "Mag %s · Damage %s · Range %s", "Магазин %s · Урон %s · Дальность %s"),
        ("tip.undermetro.fits", "Fits: %s", "Подходит к: %s"),
        ("block.undermetro.trap_bear", "Bear Trap", "Капкан"), ("block.undermetro.trap_snare", "Snare Trap", "Петля-ловушка"),
        ("block.undermetro.mine_tripwire", "Tripwire Mine", "Растяжка"), ("block.undermetro.candle", "Candle", "Свеча"),
        ("block.undermetro.lantern_oil", "Oil Lantern", "Керосиновая лампа"),
    ):
        en[k], ru[k] = e, r
    for i in range(10):
        en[f"radio.undermetro.{i + 1}"], ru[f"radio.undermetro.{i + 1}"] = RADIO_EN[i], RADIO_RU[i]
    for k, v in LORE_EN.items():
        en[f"lore.undermetro.{k}"], ru[f"lore.undermetro.{k}"] = v, LORE_RU[k]
    lang(A, en, ru)
