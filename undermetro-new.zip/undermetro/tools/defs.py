# -*- coding: utf-8 -*-
"""Определения контента. Добавляйте предметы сюда и запускайте: python3 tools/build_assets.py"""

# ---------------------------------------------------------------- еда / напитки / лекарства
# (id, en, ru, kind, hunger(0-20), sat, thirst(+/-), heal, antirad, [effects], icon, color)
# effects: (effect, duration_ticks, amplifier)
CONSUMABLES = [
    # консервы и еда
    ("canned_stew", "Canned Stew", "Тушёнка", "food", 8, 0.6, -2, 0, 0, [], "can", "#8a4b2a"),
    ("canned_beans", "Canned Beans", "Консервы: фасоль", "food", 6, 0.5, -2, 0, 0, [], "can", "#a0522d"),
    ("canned_fish", "Canned Sprats", "Шпроты", "food", 6, 0.5, -4, 0, 0, [], "can", "#c9a227"),
    ("canned_corn", "Canned Corn", "Консервированная кукуруза", "food", 5, 0.4, -1, 0, 0, [], "can", "#d4b020"),
    ("canned_peaches", "Canned Peaches", "Консервированные персики", "food", 5, 0.4, 2, 0, 0, [], "can", "#e08a3c"),
    ("canned_pate", "Canned Pâté", "Паштет", "food", 6, 0.5, -2, 0, 0, [], "can", "#7b5a4a"),
    ("condensed_milk", "Condensed Milk", "Сгущёнка", "food", 4, 0.4, 1, 0, 0, [], "can", "#e8e2c8"),
    ("crackers", "Crackers", "Сухари", "food", 4, 0.3, -3, 0, 0, [], "box", "#b98f55"),
    ("instant_noodles", "Instant Noodles", "Лапша быстрого приготовления", "food", 5, 0.4, -3, 0, 0, [], "box", "#d9a441"),
    ("chocolate_bar", "Chocolate Bar", "Шоколадка", "food", 3, 0.5, -1, 0, 0, [], "bar", "#5a3320"),
    ("candy", "Hard Candy", "Леденцы", "food", 2, 0.3, 0, 0, 0, [], "candy", "#c43c5a"),
    ("cookies", "Cookies", "Печенье", "food", 3, 0.3, -2, 0, 0, [], "box", "#c88a4a"),
    ("dried_meat", "Dried Meat", "Вяленое мясо", "food", 7, 0.7, -3, 0, 0, [], "bar", "#6e3a2b"),
    ("sausage", "Sausage", "Колбаса", "food", 6, 0.6, -2, 0, 0, [], "bar", "#a8483c"),
    ("ration_pack", "Ration Pack", "Сухпаёк", "food", 12, 0.8, -4, 0, 0, [], "box", "#6b7a3f"),
    # напитки
    ("clean_water", "Clean Water", "Чистая вода", "drink", 0, 0, 40, 0, 0, [], "bottle", "#6fb5d9"),
    ("dirty_water", "Contaminated Water", "Заражённая вода", "drink", 0, 0, 25, 0, 0,
     [("poison", 200, 0), ("nausea", 300, 0)], "bottle", "#6b6a2a"),
    ("lemonade_lime", "Lime Soda", "Лимонад «Лайм»", "drink", 1, 0.1, 22, 0, 0, [], "bottle", "#8fd14f"),
    ("lemonade_orange", "Orange Soda", "Лимонад «Апельсин»", "drink", 1, 0.1, 22, 0, 0, [], "bottle", "#f09a2a"),
    ("cola", "Cola", "Кола", "drink", 1, 0.1, 20, 0, 0, [("speed", 200, 0)], "bottle", "#3a2218"),
    ("kvass", "Kvass", "Квас", "drink", 2, 0.2, 25, 0, 0, [], "bottle", "#7a4a1c"),
    ("juice_apple", "Apple Juice", "Яблочный сок", "drink", 1, 0.2, 25, 0, 0, [], "bottle", "#d8b845"),
    ("energy_drink", "Energy Drink", "Энергетик", "drink", 0, 0, 15, 0, 0, [("speed", 600, 1), ("hunger", 300, 0)], "can", "#2a9d8f"),
    ("tea_cold", "Cold Tea", "Холодный чай", "drink", 0, 0, 26, 0, 0, [], "bottle", "#a5671f"),
    ("beer", "Beer", "Пиво", "drink", 1, 0.1, 15, 0, 0, [("nausea", 120, 0)], "bottle", "#c18a1a"),
    ("vodka", "Vodka", "Водка", "drink", 0, 0, 3, 0, 8, [("nausea", 300, 0), ("strength", 600, 0)], "bottle", "#cfe3ea"),
    ("wine", "Wine", "Вино", "drink", 1, 0.1, 8, 0, 0, [("nausea", 160, 0)], "bottle", "#6d1a3a"),
    # лекарства
    ("bandage", "Bandage", "Бинт", "med", 0, 0, 0, 4, 0, [], "bandage", "#e6e1d3"),
    ("painkillers", "Painkillers", "Обезболивающее", "med", 0, 0, 0, 0, 0, [("regen", 200, 0), ("resistance", 600, 0)], "pill", "#e0e0e0"),
    ("medkit", "Medkit", "Аптечка", "med", 0, 0, 0, 14, 0, [("regen", 200, 1)], "medkit", "#c0392b"),
    ("antirad_pills", "Anti-Rad Pills", "Антирадин", "med", 0, 0, 0, 0, 40, [], "pill", "#7fd13b"),
    ("antidote", "Antidote", "Антидот", "med", 0, 0, 0, 2, 15, [], "syringe", "#5ac8c8"),
    ("stimulant", "Stimulant", "Стимулятор", "med", 0, 0, 0, 0, 0, [("speed", 1200, 1), ("strength", 1200, 0)], "syringe", "#d1b32a"),
]

# ---------------------------------------------------------------- холодное оружие
# (id, en, ru, damage_bonus, speed_mod, durability, icon, color)
MELEE = [
    ("knife_kitchen", "Kitchen Knife", "Кухонный нож", 2.0, -1.2, 110, "knife", "#9aa3a8"),
    ("knife_combat", "Combat Knife", "Боевой нож", 3.5, -1.4, 260, "knife", "#7d8a90"),
    ("machete", "Machete", "Мачете", 5.0, -2.2, 280, "blade", "#8c969b"),
    ("katana", "Katana", "Катана", 6.5, -1.9, 420, "blade", "#c9d2d6"),
    ("bat_wood", "Wooden Bat", "Бита", 3.5, -2.4, 140, "bat", "#8a6234"),
    ("bat_nailed", "Nailed Bat", "Бита с гвоздями", 5.0, -2.4, 150, "bat", "#6e4d2a"),
    ("crowbar", "Crowbar", "Монтировка", 4.5, -2.5, 320, "bat", "#9b3a2e"),
    ("sledgehammer", "Sledgehammer", "Кувалда", 8.0, -3.2, 300, "hammer", "#555d63"),
]

# ---------------------------------------------------------------- найденные инструменты (не крафтятся)
# (id, en, ru, type, dmg, speed, durability, mine_speed, icon, color)
TOOLS = [
    ("pickaxe_rusty", "Rusty Pickaxe", "Ржавая кирка", "pickaxe", 2.0, -2.8, 120, 3.0, "pick", "#8a5a3c"),
    ("pickaxe_miner", "Miner's Pickaxe", "Шахтёрская кирка", "pickaxe", 3.0, -2.8, 420, 5.0, "pick", "#7b8790"),
    ("shovel_rusty", "Rusty Shovel", "Ржавая лопата", "shovel", 2.0, -3.0, 130, 3.0, "shovel", "#8a5a3c"),
    ("shovel_sapper", "Sapper Shovel", "Сапёрная лопатка", "shovel", 3.0, -2.6, 380, 4.5, "shovel", "#5b6b4a"),
    ("axe_fire", "Fire Axe", "Пожарный топор", "axe", 6.0, -3.0, 400, 5.0, "axe", "#b03a2e"),
    ("axe_hatchet", "Hatchet", "Топорик", "axe", 4.0, -2.8, 200, 3.5, "axe", "#7a6a55"),
    ("hoe_garden", "Garden Hoe", "Садовая тяпка", "hoe", 1.0, -1.0, 150, 2.0, "hoe", "#6f7d52"),
]

# ---------------------------------------------------------------- огнестрел
# (id, en, ru, dmg, delay, pellets, spread_deg, range, ammo, durability, sound, icon, color)
GUNS = [
    ("pistol_pm", "PM Pistol", "Пистолет ПМ", 5.0, 8, 1, 2.5, 40, "ammo_9mm", 300, "pistol", "gun_pistol", "#3b3f44"),
    ("pistol_tt", "TT Pistol", "Пистолет ТТ", 6.5, 9, 1, 2.0, 45, "ammo_762", 320, "pistol", "gun_pistol", "#2f3438"),
    ("revolver_nagant", "Nagant Revolver", "Револьвер Наган", 7.5, 16, 1, 1.5, 45, "ammo_762", 360, "pistol", "gun_pistol", "#41464b"),
    ("smg_pp", "PP Submachine Gun", "Пистолет-пулемёт ПП", 4.0, 3, 1, 4.5, 40, "ammo_9mm", 420, "pistol", "gun_smg", "#363a3f"),
    ("rifle_ak74", "AK-74", "Автомат АК-74", 6.0, 3, 1, 3.0, 70, "ammo_545", 600, "rifle", "gun_rifle", "#4a4f4a"),
    ("rifle_ak47", "AK-47", "Автомат АК-47", 7.0, 4, 1, 3.5, 65, "ammo_762", 600, "rifle", "gun_rifle", "#5a4a38"),
    ("rifle_mosin", "Mosin Rifle", "Винтовка Мосина", 14.0, 30, 1, 0.5, 120, "ammo_762", 500, "rifle", "gun_sniper", "#6a5236"),
    ("sniper_svd", "SVD Sniper Rifle", "Снайперская СВД", 16.0, 14, 1, 0.3, 140, "ammo_308", 500, "rifle", "gun_sniper", "#4c5148"),
    ("shotgun_toz", "TOZ Shotgun", "Двустволка ТОЗ", 3.5, 20, 8, 7.0, 25, "ammo_12g", 300, "shotgun", "gun_shotgun", "#6b4a2a"),
    ("shotgun_pump", "Pump Shotgun", "Помповое ружьё", 3.5, 24, 9, 6.0, 28, "ammo_12g", 400, "shotgun", "gun_shotgun", "#3d4146"),
]

# ---------------------------------------------------------------- разное (id, en, ru, type, stack, durability, icon, color)
MISC = [
    ("gas_mask", "Gas Mask", "Противогаз", "head", 1, 0, "mask", "#4d5a45"),
    ("hazmat_suit", "Hazmat Suit", "Защитный костюм", "chest", 1, 0, "suit", "#b8a62a"),
    ("filter_basic", "Basic Filter", "Фильтр (простой)", "filter", 16, 600, "filter", "#6b7a6b"),
    ("filter_advanced", "Advanced Filter", "Фильтр (улучшенный)", "filter", 16, 1800, "filter", "#5a7aa0"),
    ("filter_military", "Military Filter", "Фильтр (военный)", "filter", 16, 4200, "filter", "#4a6a3a"),
    ("flashlight", "Flashlight", "Фонарик", "flashlight", 1, 400, "flash", "#c9b037"),
    ("battery_small", "Battery", "Батарейка", "battery", 1, 300, "battery", "#3a8a4a"),
    ("radio", "Radio", "Радио", "plain", 1, 0, "radio", "#6a5a3a"),
    ("lighter", "Lighter", "Зажигалка", "lighter", 1, 80, "lighter", "#b0a090"),
    ("flask_empty", "Empty Flask", "Пустая фляга", "flask", 8, 0, "flask", "#7a8a6a"),
    ("canister_empty", "Empty Fuel Canister", "Канистра (пустая)", "plain", 4, 0, "canister", "#6a5a3a"),
    ("canister_fuel", "Fuel Canister", "Канистра с топливом", "plain", 4, 0, "canister", "#a8442a"),
    ("fuel_raw", "Raw Fuel Oil", "Мазут", "plain", 16, 0, "bottle", "#2a2418"),
    ("fuel_clean", "Refined Fuel", "Очищенное топливо", "plain", 16, 0, "bottle", "#c9a227"),
    ("water_tablet", "Water Purification Tablets", "Таблетки для воды", "plain", 32, 0, "pill", "#d9d9c9"),
    ("gold_casing", "Gold Casing", "Золотая гильза", "plain", 64, 0, "casing", "#e5b93a"),
    ("scrap_metal", "Scrap Metal", "Металлолом", "plain", 64, 0, "scrap", "#6a6a6a"),
    ("copper_wire", "Copper Wire", "Медная проволока", "plain", 64, 0, "wire", "#c8762a"),
    ("circuit_board", "Circuit Board", "Плата", "plain", 32, 0, "board", "#2a7a4a"),
    ("electronic_scrap", "Electronic Scrap", "Электроника (хлам)", "plain", 64, 0, "board", "#4a5a4a"),
    ("plastic_scrap", "Plastic Scrap", "Пластик", "plain", 64, 0, "scrap", "#a0a8b0"),
    ("rubber", "Rubber", "Резина", "plain", 64, 0, "scrap", "#2a2a2a"),
    ("duct_tape", "Duct Tape", "Изолента", "plain", 32, 0, "tape", "#3a5a9a"),
    ("cloth_scrap", "Cloth Scrap", "Ткань", "plain", 64, 0, "cloth", "#8a7a6a"),
    ("engine_part", "Engine Part", "Двигатель (деталь)", "plain", 4, 0, "engine", "#5a5a5a"),
    ("wheel_worn", "Worn Wheel", "Потёртое колесо", "plain", 8, 0, "wheel", "#2a2a2a"),
    ("car_frame", "Car Frame", "Каркас автомобиля", "plain", 2, 0, "frame", "#7a4a2a"),
    ("vehicle_kit_buggy", "Scrap Buggy Kit", "Набор: багги из обломков", "kit", 1, 0, "kit", "#8a5a2a"),
    ("grenade", "Grenade", "Граната", "grenade", 16, 0, "grenade", "#4a5a3a"),
    ("molotov", "Molotov Cocktail", "Коктейль Молотова", "molotov", 16, 0, "molotov", "#b0552a"),
    ("ammo_9mm", "9mm Rounds", "Патроны 9 мм", "plain", 64, 0, "ammo", "#c9a24a"),
    ("ammo_545", "5.45 Rounds", "Патроны 5.45", "plain", 64, 0, "ammo", "#9a7a3a"),
    ("ammo_762", "7.62 Rounds", "Патроны 7.62", "plain", 64, 0, "ammo", "#b88a3a"),
    ("ammo_308", "7.62x54 Rounds", "Патроны 7.62x54", "plain", 64, 0, "ammo", "#a8873a"),
    ("ammo_12g", "12ga Shells", "Дробь 12 калибра", "plain", 64, 0, "shell", "#b03a2e"),
    ("note_old", "Old Note", "Старая записка", "plain", 16, 0, "note", "#d8c9a0"),
]

# ---------------------------------------------------------------- электроника: 10 видов × 7 уровней
KINDS = [
    # kind, en, ru
    ("generator", "Generator", "Генератор"),
    ("battery", "Accumulator", "Аккумулятор"),
    ("cable", "Cable", "Провод"),
    ("lamp", "Lamp", "Лампа"),
    ("air_filter", "Air Filter", "Воздушный фильтр"),
    ("water_filter", "Water Filter", "Фильтр воды"),
    ("sensor", "Seal Sensor", "Датчик герметичности"),
    ("turret", "Sentry Turret", "Охранная турель"),
    ("alarm", "Monster Alarm", "Сигнализация"),
    ("door", "Airlock Door", "Гермодверь"),
    ("grow_tray", "Hydroponic Tray", "Гидропонная грядка"),
]
MAX_TIER = 7
TIER_COLORS = ["#8a5a3a", "#8d949a", "#4f9a55", "#3d7fc4", "#8a52c4", "#d9822b", "#e5c13a"]

# рецепты 1-го уровня: (шаблон, ключи)  S=металлолом W=проволока B=плата P=пластик R=резина T=изолента E=электро-хлам G=двигатель F=фильтр
T1_RECIPES = {
    "generator": (["SSS", "SGS", "WSW"], {"S": "scrap_metal", "G": "engine_part", "W": "copper_wire"}),
    "battery": (["SWS", "SBS", "SSS"], {"S": "scrap_metal", "W": "copper_wire", "B": "battery_small"}),
    "cable": (["WWW", "RRR", "WWW"], {"W": "copper_wire", "R": "rubber"}),
    "lamp": (["PPP", "WBW", "SSS"], {"P": "plastic_scrap", "W": "copper_wire", "B": "circuit_board", "S": "scrap_metal"}),
    "air_filter": (["SSS", "SFS", "WBW"], {"S": "scrap_metal", "F": "filter_basic", "W": "copper_wire", "B": "circuit_board"}),
    "water_filter": (["SPS", "PFP", "SBS"], {"S": "scrap_metal", "P": "plastic_scrap", "F": "filter_basic", "B": "circuit_board"}),
    "sensor": (["SBS", "WEW", "SSS"], {"S": "scrap_metal", "B": "circuit_board", "W": "copper_wire", "E": "electronic_scrap"}),
    "turret": (["SSS", "GBG", "SWS"], {"S": "scrap_metal", "G": "engine_part", "B": "circuit_board", "W": "copper_wire"}),
    "alarm": (["SSS", "WBW", "TTT"], {"S": "scrap_metal", "W": "copper_wire", "B": "circuit_board", "T": "duct_tape"}),
    "door": (["SSS", "SBS", "SSS"], {"S": "scrap_metal", "B": "circuit_board"}),
    "grow_tray": (["SLS", "HBH", "SSS"], {"S": "scrap_metal", "L": "grow_lamp_part", "H": "hydroponic_tray", "B": "circuit_board"}),
}

# ---------------------------------------------------------------- существа
ENTITIES = [
    ("shade", "Metro Shade", "Тень метро"),
    ("crawler", "Crawler", "Ползун"),
    ("mutant", "Mutant", "Мутант"),
    ("screecher", "Screecher", "Визгун"),
    ("leech", "Water Mutant", "Водяной мутант"),
    ("marauder", "Marauder", "Мародёр"),
    ("survivor", "Survivor", "Выживший"),
    ("grenade", "Grenade", "Граната"),
    ("molotov", "Molotov Cocktail", "Коктейль Молотова"),
    ("buggy", "Scrap Buggy", "Багги"),
]


def machine_name(kind, tier):
    return "hatch" if kind == "hatch" else f"{kind}_t{tier}"


# =====================================================================================
#                                   РАСШИРЕНИЕ КОНТЕНТА (v0.2)
# =====================================================================================
# ---- еда
CONSUMABLES += [
    ("canned_tomato", "Canned Tomatoes", "Консервированные томаты", "food", 4, 0.4, 2, 0, 0, [], "can", "#b03a2e"),
    ("canned_peas", "Canned Peas", "Зелёный горошек", "food", 4, 0.4, 1, 0, 0, [], "can", "#6a9a3a"),
    ("canned_mushrooms", "Canned Mushrooms", "Маринованные грибы", "food", 4, 0.4, 0, 0, 0, [], "jar", "#8a6a4a"),
    ("canned_cucumbers", "Pickled Cucumbers", "Солёные огурцы", "food", 3, 0.3, 1, 0, 0, [], "jar", "#5a8a3a"),
    ("canned_jam", "Berry Jam", "Варенье", "food", 4, 0.4, 0, 0, 0, [], "jar", "#7a1a3a"),
    ("canned_honey", "Honey Jar", "Мёд", "food", 5, 0.6, 0, 1, 0, [], "jar", "#d9a02a"),
    ("canned_chicken", "Canned Chicken", "Консервированная курица", "food", 8, 0.6, -2, 0, 0, [], "can", "#c9a46a"),
    ("canned_pork", "Canned Pork", "Свинина консервированная", "food", 9, 0.7, -2, 0, 0, [], "can", "#a8644a"),
    ("canned_sardines", "Canned Sardines", "Сардины в масле", "food", 5, 0.5, -3, 0, 0, [], "can", "#8a9aa0"),
    ("canned_tuna", "Canned Tuna", "Тунец консервированный", "food", 6, 0.5, -3, 0, 0, [], "can", "#c06a5a"),
    ("canned_soup", "Canned Soup", "Суп консервированный", "food", 6, 0.5, 4, 0, 0, [], "can", "#c98a3a"),
    ("canned_borscht", "Canned Borscht", "Борщ консервированный", "food", 7, 0.5, 4, 0, 0, [], "can", "#9a2a3a"),
    ("canned_rice", "Rice with Meat", "Рис с мясом", "food", 8, 0.6, -2, 0, 0, [], "can", "#d9c9a0"),
    ("buckwheat", "Buckwheat", "Гречка", "food", 5, 0.5, -2, 0, 0, [], "box", "#8a6a3a"),
    ("pasta", "Pasta", "Макароны", "food", 5, 0.5, -2, 0, 0, [], "box", "#e0c46a"),
    ("flour_bag", "Flour", "Мука (пакет)", "food", 2, 0.2, -3, 0, 0, [], "box", "#e8e0d0"),
    ("sugar_cubes", "Sugar Cubes", "Рафинад", "food", 2, 0.3, 0, 0, 0, [], "box", "#f0f0f0"),
    ("bread_stale", "Stale Bread", "Чёрствый хлеб", "food", 4, 0.3, -3, 0, 0, [], "bar", "#a0783a"),
    ("lard", "Salted Lard", "Сало", "food", 6, 0.7, -3, 0, 0, [], "bar", "#e8d8c0"),
    ("smoked_fish", "Smoked Fish", "Копчёная рыба", "food", 6, 0.6, -3, 0, 0, [], "bar", "#b8782a"),
    ("jerky_mutant", "Mutant Jerky", "Вяленина (мутант)", "food", 5, 0.4, -3, 0, 0, [("nausea", 160, 0)], "bar", "#4a3a2a"),
    ("mushroom_cap", "Cave Mushroom", "Подземный гриб", "food", 3, 0.2, 0, 0, 0, [("nausea", 100, 0)], "candy", "#8a7a5a"),
    ("wafers", "Wafers", "Вафли", "food", 3, 0.3, -2, 0, 0, [], "box", "#d9b45a"),
    ("halva", "Halva", "Халва", "food", 4, 0.4, -2, 0, 0, [], "bar", "#b8924a"),
    ("granola_bar", "Granola Bar", "Батончик-мюсли", "food", 3, 0.4, -1, 0, 0, [], "bar", "#9a7a3a"),
    ("chips_pack", "Potato Chips", "Чипсы", "food", 3, 0.2, -3, 0, 0, [], "box", "#d9a02a"),
    ("dry_soup", "Dry Soup Mix", "Суповой концентрат", "food", 4, 0.3, -2, 0, 0, [], "box", "#c98a3a"),
    ("ration_pack_mil", "Military Ration", "Армейский сухпаёк", "food", 14, 0.9, -4, 0, 0, [("regen", 100, 0)], "box", "#4a5a3a"),
    ("ration_pack_special", "Special Ration", "Паёк «Артель»", "food", 10, 0.8, -3, 0, 0, [], "box", "#7a6a3a"),
]
# ---- напитки
CONSUMABLES += [
    ("lemonade_cherry", "Cherry Soda", "Лимонад «Вишня»", "drink", 1, 0.1, 22, 0, 0, [], "bottle", "#a02a3a"),
    ("lemonade_grape", "Grape Soda", "Лимонад «Виноград»", "drink", 1, 0.1, 22, 0, 0, [], "bottle", "#6a3a8a"),
    ("lemonade_cream", "Cream Soda", "Лимонад «Крем-сода»", "drink", 1, 0.1, 22, 0, 0, [], "bottle", "#e8d890"),
    ("tarhun", "Tarragon Soda", "Тархун", "drink", 1, 0.1, 22, 0, 0, [], "bottle", "#4a8a3a"),
    ("baikal", "Baikal Soda", "Байкал", "drink", 1, 0.1, 24, 0, 0, [], "bottle", "#5a3a1a"),
    ("mineral_water", "Mineral Water", "Минеральная вода", "drink", 0, 0, 35, 0, 0, [], "bottle", "#8ac8d8"),
    ("sparkling_water", "Sparkling Water", "Газировка", "drink", 0, 0, 30, 0, 0, [], "bottle", "#a8dce8"),
    ("juice_orange", "Orange Juice", "Апельсиновый сок", "drink", 1, 0.2, 25, 0, 0, [], "bottle", "#f09a1a"),
    ("juice_tomato", "Tomato Juice", "Томатный сок", "drink", 1, 0.2, 22, 0, 0, [], "bottle", "#b02a1a"),
    ("juice_birch", "Birch Sap", "Берёзовый сок", "drink", 1, 0.2, 28, 0, 0, [], "bottle", "#e8e8c8"),
    ("compote", "Compote", "Компот", "drink", 1, 0.2, 26, 0, 0, [], "jar", "#a8442a"),
    ("milk_powder", "Milk (reconstituted)", "Молоко (из порошка)", "drink", 2, 0.3, 20, 0, 0, [], "bottle", "#f0f0e8"),
    ("coffee_cold", "Cold Coffee", "Холодный кофе", "drink", 0, 0, 14, 0, 0, [("speed", 400, 0)], "can", "#4a2a1a"),
    ("tea_herbal", "Herbal Tea", "Травяной чай", "drink", 0, 0, 24, 1, 0, [], "bottle", "#6a8a3a"),
    ("beer_dark", "Dark Beer", "Тёмное пиво", "drink", 1, 0.1, 14, 0, 0, [("nausea", 140, 0)], "bottle", "#3a2210"),
    ("moonshine", "Moonshine", "Самогон", "drink", 0, 0, 1, 0, 6, [("nausea", 400, 0), ("strength", 800, 0)], "bottle", "#d8e0d0"),
    ("cognac", "Cognac", "Коньяк", "drink", 0, 0, 2, 0, 5, [("nausea", 260, 0), ("resistance", 800, 0)], "bottle", "#a8561a"),
    ("whiskey", "Whiskey", "Виски", "drink", 0, 0, 2, 0, 5, [("nausea", 260, 0), ("strength", 800, 0)], "bottle", "#b87a1a"),
    ("champagne", "Champagne", "Шампанское", "drink", 0, 0, 10, 0, 0, [("nausea", 160, 0)], "bottle", "#e8d890"),
    ("sap_mutant", "Mutant Sap", "Сок мутанта", "drink", 0, 0, 10, 0, 0, [("poison", 120, 0), ("strength", 1200, 1)], "bottle", "#7a9a2a"),
]
# ---- лекарства
CONSUMABLES += [
    ("bandage_sterile", "Sterile Bandage", "Стерильный бинт", "med", 0, 0, 0, 7, 0, [], "bandage", "#f0f0f0"),
    ("tourniquet", "Tourniquet", "Жгут", "med", 0, 0, 0, 3, 0, [("resistance", 400, 0)], "bandage", "#a04a2a"),
    ("antiseptic", "Antiseptic", "Антисептик", "med", 0, 0, 0, 3, 5, [], "bottle", "#8ac8a8"),
    ("iodine", "Iodine", "Йод", "med", 0, 0, 0, 1, 20, [], "bottle", "#9a5a1a"),
    ("potassium_iodide", "Potassium Iodide", "Йодид калия", "med", 0, 0, 0, 0, 60, [], "pill", "#e8e8d0"),
    ("rad_x", "Rad-Away Drip", "Радиопротектор", "med", 0, 0, 0, 0, 80, [("nausea", 100, 0)], "syringe", "#4ac86a"),
    ("morphine", "Morphine", "Морфин", "med", 0, 0, 0, 2, 0, [("resistance", 1800, 1), ("slowness", 600, 0)], "syringe", "#c8d8e8"),
    ("adrenaline", "Adrenaline", "Адреналин", "med", 0, 0, 0, 4, 0, [("speed", 800, 2), ("regen", 120, 1)], "syringe", "#d84a3a"),
    ("antibiotics", "Antibiotics", "Антибиотики", "med", 0, 0, 0, 5, 0, [("regen", 300, 0)], "pill", "#e8c84a"),
    ("charcoal_pills", "Activated Charcoal", "Активированный уголь", "med", 0, 0, 0, 0, 10, [], "pill", "#2a2a2a"),
    ("vitamins", "Vitamins", "Витамины", "med", 0, 0, 0, 1, 0, [("regen", 400, 0)], "pill", "#e8a82a"),
    ("sedative", "Sedative", "Успокоительное", "med", 0, 0, 0, 0, 0, [("resistance", 1200, 0), ("slowness", 400, 0)], "pill", "#8a8ac8"),
    ("medkit_large", "Large Medkit", "Большая аптечка", "med", 0, 0, 0, 20, 0, [("regen", 400, 1)], "medkit", "#a0281a"),
    ("medkit_military", "Military Medkit", "Армейская аптечка", "med", 0, 0, 0, 20, 20, [("regen", 300, 2), ("resistance", 600, 0)], "medkit", "#4a5a2a"),
    ("combat_stim", "Combat Stimulant", "Боевой стимулятор", "med", 0, 0, 0, 6, 0, [("speed", 1600, 2), ("strength", 1600, 1), ("resistance", 1600, 0)], "syringe", "#d84a8a"),
]

# ---- холодное оружие
MELEE += [
    ("knife_hunting", "Hunting Knife", "Охотничий нож", 3.0, -1.4, 240, "knife", "#8a9298"),
    ("knife_throwing", "Throwing Knife", "Метательный нож", 2.5, -1.2, 120, "knife", "#aab2b8"),
    ("knife_bayonet", "Bayonet", "Штык-нож", 3.5, -1.5, 300, "knife", "#7a8288"),
    ("cleaver", "Butcher Cleaver", "Топор мясника", 5.5, -2.6, 220, "axe", "#9a9a9a"),
    ("sword_saber", "Cavalry Saber", "Сабля", 6.0, -2.0, 380, "blade", "#c0c8cc"),
    ("sword_cleaver", "Scrap Cleaver Sword", "Тесак из рессоры", 6.5, -2.3, 350, "blade", "#6a6a6a"),
    ("pipe_wrench", "Pipe Wrench", "Газовый ключ", 4.5, -2.6, 280, "wrench", "#a03a2a"),
    ("pipe_lead", "Lead Pipe", "Свинцовая труба", 5.0, -2.8, 260, "bat", "#6a6a72"),
    ("shovel_blade", "Sharpened Shovel", "Заточенная лопата", 5.5, -2.7, 250, "shovel", "#7a7a6a"),
    ("hammer_claw", "Claw Hammer", "Молоток-гвоздодёр", 4.0, -2.4, 280, "hammer", "#8a6a3a"),
    ("machete_rusty", "Rusty Machete", "Ржавое мачете", 4.0, -2.2, 160, "blade", "#8a5a3a"),
    ("katana_masterwork", "Masterwork Katana", "Катана мастера", 8.0, -1.8, 600, "blade", "#e0e8ec"),
    ("baton", "Police Baton", "Дубинка", 3.5, -1.8, 240, "bat", "#2a2a2e"),
    ("spiked_club", "Spiked Club", "Дубина с шипами", 6.0, -2.8, 200, "bat", "#5a3a22"),
]

# ---- инструменты
TOOLS += [
    ("pickaxe_pneumatic", "Pneumatic Pick", "Отбойник", "pickaxe", 4.0, -3.0, 700, 7.5, "pick", "#e0a82a"),
    ("pickaxe_ice", "Ice Pick", "Ледоруб", "pickaxe", 3.0, -2.2, 300, 4.0, "pick", "#7aa0b8"),
    ("pickaxe_geologist", "Geologist's Pick", "Геологический молоток", "pickaxe", 3.0, -2.6, 350, 4.5, "pick", "#6a7a8a"),
    ("pickaxe_mattock", "Mattock", "Кирка-мотыга", "pickaxe", 3.5, -2.9, 450, 5.5, "pick", "#8a5a2a"),
    ("shovel_garden", "Garden Spade", "Садовая лопата", "shovel", 2.5, -2.8, 240, 3.5, "shovel", "#6a7a4a"),
    ("shovel_coal", "Coal Shovel", "Совковая лопата", "shovel", 2.5, -2.8, 300, 4.0, "shovel", "#3a3a3e"),
    ("axe_lumber", "Lumber Axe", "Колун", "axe", 6.5, -3.1, 500, 6.0, "axe", "#8a5a3a"),
    ("axe_tactical", "Tactical Tomahawk", "Тактический томагавк", "axe", 5.0, -2.5, 450, 5.0, "axe", "#3a3e3a"),
    ("hoe_cultivator", "Cultivator", "Культиватор", "hoe", 1.5, -1.0, 260, 3.0, "hoe", "#7a6a3a"),
    ("hoe_rake", "Iron Rake", "Грабли", "hoe", 1.0, -1.0, 200, 2.5, "hoe", "#8a8a8a"),
    ("pickaxe_old", "Old Pickaxe", "Старая кирка", "pickaxe", 2.0, -2.8, 200, 3.5, "pick", "#6a4a2a"),
    ("pickaxe_sapper", "Sapper's Pick", "Сапёрная кирка", "pickaxe", 3.0, -2.5, 400, 5.0, "pick", "#4a5a3a"),
]

# ---- огнестрел
GUNS += [
    ("pistol_makarov_mod", "PMM Pistol", "Пистолет ПММ", 5.5, 7, 1, 2.3, 42, "ammo_9mm", 380, "pistol", "gun_pistol", "#2a2e32"),
    ("pistol_stechkin", "APS Machine Pistol", "Автоматический Стечкин", 5.0, 3, 1, 4.0, 40, "ammo_9mm", 420, "pistol", "gun_smg", "#3a3e42"),
    ("pistol_deagle", "Heavy Pistol", "Тяжёлый пистолет", 9.0, 14, 1, 2.0, 50, "ammo_44", 360, "pistol", "gun_pistol", "#5a5e62"),
    ("revolver_magnum", "Magnum Revolver", "Револьвер «Магнум»", 10.0, 18, 1, 1.5, 55, "ammo_44", 400, "pistol", "gun_pistol", "#4a4e52"),
    ("smg_kedr", "Kedr SMG", "Пистолет-пулемёт «Кедр»", 4.0, 2, 1, 5.0, 38, "ammo_9mm", 380, "pistol", "gun_smg", "#2e3236"),
    ("smg_uzi", "Micro SMG", "Мини-автомат", 3.8, 2, 1, 5.5, 35, "ammo_9mm", 360, "pistol", "gun_smg", "#363a3e"),
    ("smg_vityaz", "Vityaz SMG", "ПП «Витязь»", 4.5, 3, 1, 4.0, 45, "ammo_9mm", 520, "pistol", "gun_smg", "#3a4036"),
    ("rifle_aks74u", "AKS-74U", "Автомат АКС-74У", 5.5, 3, 1, 4.0, 55, "ammo_545", 520, "rifle", "gun_rifle", "#3e423e"),
    ("rifle_ak12", "AK-12", "Автомат АК-12", 7.0, 3, 1, 2.5, 80, "ammo_545", 700, "rifle", "gun_rifle", "#3a3e36"),
    ("rifle_ar15", "AR Carbine", "Карабин AR", 6.5, 3, 1, 2.5, 80, "ammo_556", 650, "rifle", "gun_rifle", "#2e3236"),
    ("rifle_sks", "SKS Carbine", "Карабин СКС", 8.0, 9, 1, 2.0, 80, "ammo_762", 500, "rifle", "gun_rifle", "#6a4a2a"),
    ("rifle_bolt", "Hunting Rifle", "Охотничий карабин", 15.0, 28, 1, 0.5, 120, "ammo_308", 520, "rifle", "gun_sniper", "#5a4a32"),
    ("rifle_vss", "VSS Silent Rifle", "Бесшумная винтовка ВСС", 11.0, 4, 1, 1.0, 90, "ammo_9mm", 500, "pistol", "gun_sniper", "#3a3e3a"),
    ("sniper_dragunov_mod", "Marksman Rifle", "Снайперская винтовка", 18.0, 12, 1, 0.2, 150, "ammo_308", 600, "rifle", "gun_sniper", "#3e4a3a"),
    ("shotgun_sawedoff", "Sawed-off Shotgun", "Обрез", 3.0, 18, 8, 10.0, 18, "ammo_12g", 220, "shotgun", "gun_shotgun", "#5a4a32"),
    ("shotgun_saiga", "Saiga-12", "Сайга-12", 3.2, 6, 8, 6.5, 28, "ammo_12g", 560, "shotgun", "gun_shotgun", "#3a3e3a"),
    ("shotgun_bar", "Combat Shotgun", "Боевой дробовик", 3.8, 12, 10, 6.0, 30, "ammo_12g", 520, "shotgun", "gun_shotgun", "#42463a"),
    ("rifle_lmg", "Light Machine Gun", "Ручной пулемёт", 7.5, 2, 1, 5.0, 75, "ammo_762", 900, "rifle", "gun_rifle", "#3a3e32"),
]

# ---- разное: броня, маски, костюмы, боеприпасы, компоненты, снаряжение
# тип: head/chest/legs/feet = надевается; параметр «armor» берётся из ARMOR_VALUES
ARMOR_VALUES = {}
_ARMOR = [
    # id, en, ru, slot, armor, durability, icon, color
    ("helmet_construction", "Construction Helmet", "Строительная каска", "head", 2, 160, "helmet", "#d8a82a"),
    ("helmet_steel", "Steel Helmet", "Стальная каска", "head", 3, 260, "helmet", "#5a6a4a"),
    ("helmet_riot", "Riot Helmet", "Шлем «Сфера»", "head", 4, 340, "helmet", "#2a2e32"),
    ("helmet_military", "Military Helmet", "Армейский шлем", "head", 4, 380, "helmet", "#4a5a3a"),
    ("helmet_moto", "Motorcycle Helmet", "Мотошлем", "head", 2, 180, "helmet", "#3a3a3e"),
    ("cap_worker", "Worker Cap", "Кепка рабочего", "head", 1, 80, "helmet", "#6a5a3a"),
    ("ushanka", "Ushanka", "Ушанка", "head", 1, 100, "helmet", "#6a5a4a"),
    ("vest_padded", "Padded Jacket", "Ватник", "chest", 3, 200, "vest", "#4a5a3a"),
    ("vest_leather", "Leather Jacket", "Кожаная куртка", "chest", 4, 260, "vest", "#4a3022"),
    ("vest_kevlar", "Kevlar Vest", "Бронежилет", "chest", 6, 420, "vest", "#2a2e32"),
    ("vest_heavy", "Heavy Armor Vest", "Тяжёлый бронежилет", "chest", 8, 560, "vest", "#3a3e36"),
    ("vest_tactical", "Tactical Rig", "Разгрузка", "chest", 5, 340, "vest", "#4a4a38"),
    ("vest_firefighter", "Firefighter Jacket", "Куртка пожарного", "chest", 5, 300, "vest", "#b8a22a"),
    ("vest_police", "Police Vest", "Жилет полиции", "chest", 5, 360, "vest", "#26324a"),
    ("coat_lab", "Lab Coat", "Лабораторный халат", "chest", 1, 80, "vest", "#e8e8e8"),
    ("pants_work", "Work Trousers", "Рабочие штаны", "legs", 2, 160, "pants", "#4a4a5a"),
    ("pants_cargo", "Cargo Pants", "Карго-штаны", "legs", 3, 220, "pants", "#5a5a3a"),
    ("pants_kevlar", "Kevlar Pants", "Бронештаны", "legs", 4, 300, "pants", "#2a2e32"),
    ("pants_military", "Military Pants", "Армейские брюки", "legs", 4, 280, "pants", "#4a5a3a"),
    ("pants_firefighter", "Firefighter Pants", "Штаны пожарного", "legs", 3, 240, "pants", "#b8a22a"),
    ("boots_work", "Work Boots", "Рабочие ботинки", "feet", 2, 180, "boots", "#5a3a22"),
    ("boots_army", "Army Boots", "Берцы", "feet", 3, 260, "boots", "#2a2a2a"),
    ("boots_rubber", "Rubber Boots", "Резиновые сапоги", "feet", 2, 200, "boots", "#3a5a3a"),
    ("boots_tactical", "Tactical Boots", "Тактические ботинки", "feet", 4, 320, "boots", "#3a3a32"),
    ("boots_steel_toe", "Steel-toe Boots", "Ботинки со стальным носком", "feet", 3, 300, "boots", "#4a3a2a"),
]
_ARM_MISC = [(i, en, ru, sl, 1, du, ic, c) for (i, en, ru, sl, ar, du, ic, c) in _ARMOR]
for (i, *_rest) in _ARMOR:
    ARMOR_VALUES[i] = _rest[3]
MISC += [
    ("gas_mask_gp5", "GP-5 Gas Mask", "Противогаз ГП-5", "head", 1, 0, "mask", "#5a6a4a"),
    ("gas_mask_gp7", "GP-7 Gas Mask", "Противогаз ГП-7", "head", 1, 0, "mask", "#3a4a3a"),
    ("gas_mask_military", "Military Gas Mask", "Армейский противогаз", "head", 1, 0, "mask", "#2a3a2a"),
    ("respirator", "Respirator", "Респиратор", "head", 1, 0, "mask", "#c8c8c0"),
    ("hazmat_suit_mk2", "Hazmat Suit Mk.2", "Костюм химзащиты Мк.2", "chest", 1, 0, "suit", "#c8b02a"),
    ("hazmat_suit_military", "Military Hazmat Suit", "Армейский костюм ОЗК", "chest", 1, 0, "suit", "#4a5a3a"),
    ("hazmat_suit_lab", "Lab Hazmat Suit", "Лабораторный костюм", "chest", 1, 0, "suit", "#e8e8e8"),
] + _ARM_MISC + [
    ("flashlight_tactical", "Tactical Flashlight", "Тактический фонарь", "flashlight", 1, 900, "flash", "#2a2e32"),
    ("flashlight_dynamo", "Hand-crank Flashlight", "Динамо-фонарь", "flashlight", 1, 500, "flash", "#6a8a4a"),
    ("battery_medium", "Medium Battery", "Батарейка (средняя)", "battery", 1, 600, "battery", "#3a6a9a"),
    ("battery_large", "Large Battery", "Батарейка (большая)", "battery", 1, 1200, "battery", "#9a6a2a"),
    ("lighter_zippo", "Zippo Lighter", "Зажигалка Zippo", "lighter", 1, 160, "lighter", "#c8c8c8"),
    ("matches", "Matches", "Спички", "lighter", 1, 20, "lighter", "#d8c8a0"),
    ("flask_steel", "Steel Flask", "Стальная фляга", "flask", 8, 0, "flask", "#9aa0a8"),
    ("flask_glass", "Glass Bottle (empty)", "Пустая бутылка", "flask", 8, 0, "bottle", "#a8d0c0"),
    ("filter_cartridge_a", "Filter Cartridge A", "Фильтр-картридж А", "filter", 16, 1000, "filter", "#8a8a5a"),
    ("filter_cartridge_b", "Filter Cartridge B", "Фильтр-картридж Б", "filter", 16, 2400, "filter", "#5a8a8a"),
    ("filter_cartridge_c", "Filter Cartridge C", "Фильтр-картридж В", "filter", 16, 3600, "filter", "#8a5a8a"),
    ("filter_lab", "Laboratory Filter", "Лабораторный фильтр", "filter", 16, 6000, "filter", "#d8d8e8"),
    ("canister_empty_big", "Big Empty Canister", "Большая канистра (пустая)", "plain", 2, 0, "canister", "#5a4a2a"),
    ("canister_fuel_big", "Big Fuel Canister", "Большая канистра с топливом", "plain", 2, 0, "canister", "#b8442a"),
    ("fuel_additive", "Fuel Additive", "Присадка", "plain", 16, 0, "bottle", "#b8c82a"),
    ("lubricant", "Lubricant", "Смазка", "plain", 16, 0, "jar", "#8a7a2a"),
    ("ammo_44", ".44 Rounds", "Патроны .44", "plain", 64, 0, "ammo", "#c89a3a"),
    ("ammo_556", "5.56 Rounds", "Патроны 5.56", "plain", 64, 0, "ammo", "#a8a050"),
    ("ammo_9mm_ap", "9mm AP Rounds", "Патроны 9 мм (бронебойные)", "plain", 64, 0, "ammo", "#8a8a8a"),
    ("ammo_12g_slug", "12ga Slugs", "Пули 12 калибра", "plain", 64, 0, "shell", "#6a6a8a"),
    ("magazine_empty", "Empty Magazine", "Пустой магазин", "plain", 8, 0, "magazine", "#3a3a3a"),
    ("gunpowder_pack", "Gunpowder Pack", "Порох (пакет)", "plain", 32, 0, "pouch", "#2a2a2a"),
    ("primer_box", "Primers", "Капсюли", "plain", 32, 0, "box", "#c8a24a"),
    ("lead_ingot", "Lead", "Свинец", "plain", 64, 0, "scrap", "#5a5a6a"),
    ("steel_plate", "Steel Plate", "Стальной лист", "plain", 32, 0, "scrap", "#8a9298"),
    ("aluminium_scrap", "Aluminium Scrap", "Алюминий (лом)", "plain", 64, 0, "scrap", "#b8c0c8"),
    ("copper_scrap", "Copper Scrap", "Медный лом", "plain", 64, 0, "scrap", "#c8762a"),
    ("glass_shards", "Glass Shards", "Осколки стекла", "plain", 64, 0, "scrap", "#a8d8d8"),
    ("nails", "Nails", "Гвозди", "plain", 64, 0, "ammo", "#8a8a8a"),
    ("bolts_nuts", "Bolts and Nuts", "Болты и гайки", "plain", 64, 0, "scrap", "#6a6a72"),
    ("rope", "Rope", "Верёвка", "plain", 32, 0, "rope", "#b89a5a"),
    ("chemicals", "Chemicals", "Химикаты", "plain", 16, 0, "jar", "#5ac84a"),
    ("acid", "Acid", "Кислота", "plain", 16, 0, "bottle", "#a8e83a"),
    ("battery_acid", "Battery Acid", "Электролит", "plain", 16, 0, "bottle", "#e8e86a"),
    ("capacitor", "Capacitor", "Конденсатор", "plain", 32, 0, "battery", "#2a4a8a"),
    ("transistor", "Transistor", "Транзистор", "plain", 32, 0, "board", "#2a2a2a"),
    ("microchip", "Microchip", "Микросхема", "plain", 32, 0, "board", "#1a1a1e"),
    ("motor_small", "Small Motor", "Моторчик", "plain", 16, 0, "engine", "#6a6a8a"),
    ("magnet", "Magnet", "Магнит", "plain", 32, 0, "scrap", "#c82a2a"),
    ("display_screen", "Display", "Дисплей", "plain", 16, 0, "board", "#1a3a4a"),
    ("antenna", "Antenna", "Антенна", "plain", 16, 0, "wire", "#8a8a8a"),
    ("geiger_counter", "Geiger Counter", "Счётчик Гейгера", "plain", 1, 0, "radio", "#8a8a3a"),
    ("radio_handheld", "Handheld Radio", "Рация", "plain", 1, 0, "radio", "#3a3e42"),
    ("compass", "Compass", "Компас", "plain", 1, 0, "key", "#c8a82a"),
    ("binoculars", "Binoculars", "Бинокль", "plain", 1, 0, "flash", "#2a2e32"),
    ("map_metro", "Metro Map", "Схема метро", "plain", 1, 0, "note", "#c8b890"),
    ("map_city", "City Map", "Карта города", "plain", 1, 0, "note", "#a8c8a0"),
    ("book_survival", "Survival Handbook", "Справочник выживальщика", "plain", 1, 0, "book", "#6a4a2a"),
    ("book_medical", "Medical Handbook", "Медицинский справочник", "plain", 1, 0, "book", "#a82a2a"),
    ("book_engineering", "Engineering Handbook", "Инженерный справочник", "plain", 1, 0, "book", "#2a4a8a"),
    ("journal_old", "Old Journal", "Старый дневник", "plain", 1, 0, "book", "#4a3a2a"),
    ("key_card", "Access Card", "Карта доступа", "plain", 4, 0, "key", "#2a8a8a"),
    ("key_rusty", "Rusty Key", "Ржавый ключ", "plain", 4, 0, "key", "#8a5a2a"),
    ("toolbox", "Toolbox", "Ящик с инструментами", "plain", 1, 0, "kit", "#b82a2a"),
    ("repair_kit", "Repair Kit", "Ремкомплект", "plain", 8, 0, "kit", "#7a8a3a"),
    ("backpack_scrap", "Scrap Backpack", "Самодельный рюкзак", "plain", 1, 0, "pouch", "#6a5a3a"),
    ("pouch_small", "Small Pouch", "Подсумок", "plain", 4, 0, "pouch", "#5a5a3a"),
    ("cigarettes", "Cigarettes", "Сигареты", "plain", 16, 0, "box", "#c8c8b8"),
    ("playing_cards", "Playing Cards", "Игральные карты", "plain", 8, 0, "note", "#e8e8d8"),
    ("toy_old", "Old Toy", "Старая игрушка", "plain", 8, 0, "pouch", "#c87a8a"),
    ("watch_wrist", "Wristwatch", "Наручные часы", "plain", 4, 0, "casing", "#8a8a8a"),
    ("gold_casing_bundle", "Gold Casing Bundle", "Связка золотых гильз", "plain", 16, 0, "casing", "#f0c84a"),
    ("grenade_smoke", "Smoke Grenade", "Дымовая граната", "grenade", 16, 0, "grenade", "#8a8a8a"),
    ("grenade_frag_heavy", "Heavy Grenade", "Тяжёлая граната", "grenade", 16, 0, "grenade", "#3a4a2a"),
    ("molotov_improved", "Improved Molotov", "Улучшенный коктейль", "molotov", 16, 0, "molotov", "#d8452a"),
    ("vehicle_kit_buggy_armored", "Armored Buggy Kit", "Набор: бронированный багги", "kit", 1, 0, "kit", "#5a6a3a"),
]
# ---- декоративные блоки: (id, en, ru, стиль, цвет, свет, прочность)
DECOR = []
def _dec(prefix, en, ru, style, variants, light=0, strength=2.0):
    for (suffix, sen, sru, color) in variants:
        DECOR.append((f"{prefix}_{suffix}", f"{en} ({sen})", f"{ru} ({sru})", style, color, light, strength))

_WB = [("white", "White", "белая", "#c8c8c4"), ("gray", "Gray", "серая", "#7c8084"), ("green", "Green", "зелёная", "#4a6a54"),
       ("blue", "Blue", "синяя", "#3a5a7a"), ("brown", "Brown", "коричневая", "#6a4a38"), ("black", "Black", "чёрная", "#26282c"),
       ("beige", "Beige", "бежевая", "#a89878"), ("red", "Red", "красная", "#7a3028")]
_dec("metro_tiles", "Metro Tiles", "Плитка метро", "tiles", _WB)
_dec("tiles_cracked", "Cracked Tiles", "Битая плитка", "tiles_cracked", _WB[:5])
_dec("tiles_dirty", "Dirty Tiles", "Грязная плитка", "tiles_dirty", _WB[:5])
_dec("floor_checker", "Checker Floor", "Шахматный пол", "checker", [("bw", "Black/White", "чёрно-белый", "#8a8a8a"), ("gr", "Gray/Green", "серо-зелёный", "#5a7a60"), ("br", "Brown/Beige", "коричнево-бежевый", "#8a6a4a")])
_dec("concrete", "Concrete", "Бетон", "concrete", [("clean", "Clean", "чистый", "#8a8a88"), ("dirty", "Dirty", "грязный", "#6a6a64"), ("stained", "Stained", "в потёках", "#5a5a52"),
                                                 ("cracked", "Cracked", "треснувший", "#7a7a78"), ("mossy", "Mossy", "мшистый", "#5a6a52"), ("burnt", "Burnt", "обгоревший", "#3a3a3a")])
_dec("concrete_slab", "Concrete Slab", "Бетонная плита", "slab", [("a", "A", "А", "#808084"), ("b", "B", "Б", "#707074"), ("c", "C", "В", "#606064")])
_dec("rust_plate", "Rusted Plate", "Ржавая плита", "rust", [("a", "Light", "светлая", "#a8602a"), ("b", "Heavy", "тяжёлая", "#7a3c1a"), ("c", "Flaking", "облупленная", "#8a5a34")])
_dec("rust_grate", "Rusted Grate", "Ржавая решётка", "grate", [("a", "A", "А", "#8a5a34"), ("b", "B", "Б", "#6a4a2a")])
_dec("steel_panel", "Steel Panel", "Стальная панель", "panel", [("a", "Gray", "серая", "#7a8288"), ("b", "Green", "зелёная", "#4a5a4a"), ("c", "Blue", "синяя", "#4a5a74"), ("d", "Dark", "тёмная", "#34383c")])
_dec("crate", "Crate", "Ящик", "crate", [("wood", "Wooden", "деревянный", "#8a6a3a"), ("ammo", "Ammo", "патронный", "#4a5a3a"), ("military", "Military", "армейский", "#4a4a34"),
                                          ("supply", "Supply", "с припасами", "#7a5a2a"), ("medical", "Medical", "медицинский", "#a8a8a0"), ("toxic", "Toxic", "токсичный", "#8a9a2a")])
_dec("barrel", "Barrel", "Бочка", "barrel", [("rust", "Rusty", "ржавая", "#7a4a2a"), ("toxic", "Toxic", "токсичная", "#7a9a2a"), ("fuel", "Fuel", "топливная", "#9a2a2a"),
                                            ("water", "Water", "с водой", "#3a5a8a"), ("blue", "Blue", "синяя", "#2a4a7a"), ("black", "Black", "чёрная", "#2a2a2e")])
_dec("locker", "Locker", "Шкафчик", "locker", [("gray", "Gray", "серый", "#7a8084"), ("green", "Green", "зелёный", "#4a6a4a"), ("blue", "Blue", "синий", "#3a5a7a"), ("rust", "Rusty", "ржавый", "#8a4a2a")])
_dec("pipes", "Pipes", "Трубы", "pipes", [("a", "Gray", "серые", "#6a7076"), ("b", "Rusty", "ржавые", "#8a4a2a"), ("c", "Green", "зелёные", "#3a6a4a"), ("d", "Red", "красные", "#9a3a2a")])
_dec("vent", "Vent", "Вентиляция", "vent", [("a", "Gray", "серая", "#6a7076"), ("b", "Rusty", "ржавая", "#8a4a2a"), ("c", "Black", "чёрная", "#2a2e32")])
_dec("hazard", "Hazard Stripes", "Предупреждающая разметка", "hazard", [("y", "Yellow", "жёлтая", "#d8b82a"), ("r", "Red", "красная", "#b82a2a"), ("b", "Blue", "синяя", "#2a5ab8")])
_dec("brick", "Bricks", "Кирпич", "brick", [("red", "Red", "красный", "#8a4a3a"), ("old", "Old", "старый", "#6a4034"), ("sooty", "Sooty", "закопчённый", "#3a2e2a"),
                                         ("white", "White", "белый", "#b8b0a0"), ("yellow", "Yellow", "жёлтый", "#b89a5a")])
_dec("wallpaper", "Wallpaper", "Обои", "wallpaper", [("a", "Floral", "цветочные", "#a8987a"), ("b", "Green", "зелёные", "#6a7a5a"), ("c", "Striped", "полосатые", "#8a7a8a"), ("d", "Torn", "рваные", "#7a6a5a")])
_dec("linoleum", "Linoleum", "Линолеум", "checker", [("a", "Brown", "коричневый", "#7a5a3a"), ("b", "Green", "зелёный", "#5a7a5a"), ("c", "Gray", "серый", "#7a7a7a")])
_dec("sandbags", "Sandbags", "Мешки с песком", "sandbag", [("a", "Tan", "светлые", "#a89868"), ("b", "Gray", "серые", "#7a7a72"), ("c", "Green", "зелёные", "#5a6a4a")])
_dec("wood_planks", "Planks", "Доски", "planks", [("a", "Old", "старые", "#7a5a3a"), ("b", "Dark", "тёмные", "#4a3422"), ("c", "Rotten", "гнилые", "#5a4a32")])
_dec("tunnel_lamp", "Tunnel Lamp", "Тоннельная лампа", "lamp", [("white", "White", "белая", "#f0f0d0"), ("yellow", "Yellow", "жёлтая", "#e8c860")], light=12, strength=1.5)
_dec("emergency_light", "Emergency Light", "Аварийная лампа", "lamp", [("red", "Red", "красная", "#e03a2a"), ("green", "Green", "зелёная", "#4ae86a")], light=8, strength=1.5)
_dec("neon", "Neon Sign", "Неоновая вывеска", "neon", [("red", "Red", "красная", "#ff3a3a"), ("green", "Green", "зелёная", "#3aff6a"), ("blue", "Blue", "синяя", "#3a8aff"), ("pink", "Pink", "розовая", "#ff3aa8")], light=10, strength=1.5)
_dec("screen", "Dead Monitor", "Мёртвый монитор", "screen", [("a", "Off", "выключен", "#1a1e22"), ("b", "Static", "помехи", "#6a7a7a")], light=0)
_dec("server_rack", "Server Rack", "Серверная стойка", "rack", [("a", "Dark", "тёмная", "#2a2e32"), ("b", "Blinking", "мигающая", "#2a2e32")], light=3)
_dec("metro_sign", "Metro Sign", "Указатель метро", "sign", [("a", "Station", "станция", "#2a5a9a"), ("b", "Exit", "выход", "#2a8a4a"), ("c", "Danger", "опасно", "#b82a2a"), ("d", "Tunnel", "тоннель", "#d8b82a")])


# =====================================================================================
#                                   РАСШИРЕНИЕ КОНТЕНТА (v0.3)
# =====================================================================================
CONSUMABLES += [
    ("canned_pineapple", "Canned Pineapple", "Консервированный ананас", "food", 5, 0.4, 3, 0, 0, [], "can", "#e8c82a"),
    ("canned_pear", "Canned Pears", "Консервированные груши", "food", 5, 0.4, 2, 0, 0, [], "can", "#c8d86a"),
    ("canned_liver", "Cod Liver", "Печень трески", "food", 6, 0.6, -2, 1, 0, [], "can", "#c88a5a"),
    ("canned_goulash", "Goulash", "Гуляш", "food", 8, 0.6, -2, 0, 0, [], "can", "#8a4a2a"),
    ("canned_lecho", "Lecho", "Лечо", "food", 4, 0.4, 2, 0, 0, [], "jar", "#c8442a"),
    ("canned_eggplant", "Eggplant Caviar", "Икра баклажанная", "food", 4, 0.4, 0, 0, 0, [], "jar", "#5a3a4a"),
    ("sunflower_seeds", "Sunflower Seeds", "Семечки", "food", 2, 0.2, -2, 0, 0, [], "pouch", "#6a6a5a"),
    ("rusks_garlic", "Garlic Rusks", "Сухарики", "food", 3, 0.2, -3, 0, 0, [], "box", "#b8883a"),
    ("energy_bar", "Energy Bar", "Энергобатончик", "food", 4, 0.5, -1, 0, 0, [("speed", 200, 0)], "bar", "#3a8a5a"),
    ("meat_pie", "Meat Pie", "Пирожок с мясом", "food", 7, 0.6, -2, 0, 0, [], "box", "#c89a5a"),
    ("rat_meat_cooked", "Cooked Rat", "Жареная крыса", "food", 5, 0.4, -2, 0, 0, [("nausea", 80, 0)], "bar", "#7a4a2a"),
    ("mushroom_stew", "Mushroom Stew", "Грибная похлёбка", "food", 6, 0.5, 3, 0, 0, [], "jar", "#7a6a4a"),
    ("lemonade_apple", "Apple Soda", "Лимонад «Яблоко»", "drink", 1, 0.1, 22, 0, 0, [], "bottle", "#a8d84a"),
    ("lemonade_pear", "Pear Soda", "Лимонад «Дюшес»", "drink", 1, 0.1, 22, 0, 0, [], "bottle", "#c8e87a"),
    ("lemonade_ginger", "Ginger Ale", "Имбирный эль", "drink", 1, 0.1, 22, 0, 0, [("regen", 60, 0)], "bottle", "#d8b84a"),
    ("kompot_dried", "Dried Fruit Compote", "Компот из сухофруктов", "drink", 1, 0.2, 26, 0, 0, [], "jar", "#8a4a2a"),
    ("ayran", "Ayran", "Айран", "drink", 1, 0.2, 24, 0, 0, [], "bottle", "#f0f0e0"),
    ("kefir", "Kefir", "Кефир", "drink", 2, 0.2, 22, 0, 0, [], "bottle", "#f4f4ea"),
    ("vodka_premium", "Premium Vodka", "Водка «Особая»", "drink", 0, 0, 3, 0, 12, [("nausea", 300, 0), ("strength", 900, 0)], "bottle", "#e8f0f4"),
    ("rum", "Rum", "Ром", "drink", 0, 0, 2, 0, 5, [("nausea", 240, 0), ("strength", 700, 0)], "bottle", "#8a4a1a"),
    ("antirad_drink", "Anti-Rad Tonic", "Тоник «Антирад»", "drink", 0, 0, 15, 0, 25, [], "bottle", "#6ae86a"),
    ("vitamin_drink", "Vitamin Drink", "Витаминный напиток", "drink", 0, 0, 20, 2, 0, [("regen", 200, 0)], "bottle", "#e8a82a"),
    ("bandage_hemostatic", "Hemostatic Bandage", "Гемостатическая повязка", "med", 0, 0, 0, 9, 0, [], "bandage", "#e8e0d0"),
    ("splint", "Splint", "Шина", "med", 0, 0, 0, 5, 0, [("resistance", 600, 0)], "bandage", "#b8a070"),
    ("painkiller_strong", "Strong Painkiller", "Сильное обезболивающее", "med", 0, 0, 0, 1, 0, [("resistance", 1400, 1)], "pill", "#f0e0e0"),
    ("detox_pills", "Detox Pills", "Дезинтоксикант", "med", 0, 0, 0, 0, 30, [], "pill", "#7ac8a8"),
    ("stim_pen", "Auto-Injector", "Автоинъектор", "med", 0, 0, 0, 8, 0, [("regen", 160, 2)], "syringe", "#e8e84a"),
    ("antivenom", "Antivenom", "Противоядие", "med", 0, 0, 0, 2, 25, [], "syringe", "#9ae8c8"),
]
MELEE += [
    ("knife_trench", "Trench Knife", "Окопный нож", 4.0, -1.5, 300, "knife", "#8a9298"),
    ("knife_butterfly", "Balisong", "Нож-бабочка", 2.8, -1.0, 180, "knife", "#b0b8bc"),
    ("sword_broad", "Broadsword", "Палаш", 6.8, -2.2, 400, "blade", "#a8b0b4"),
    ("axe_battle", "Battle Axe", "Боевой топор", 7.5, -3.0, 380, "axe", "#6a6a6e"),
    ("mace_pipe", "Pipe Mace", "Булава из трубы", 6.0, -2.8, 300, "hammer", "#5a5a60"),
    ("bat_aluminium", "Aluminium Bat", "Алюминиевая бита", 4.2, -2.3, 240, "bat", "#b0b8c0"),
    ("shiv", "Shiv", "Заточка", 2.2, -1.0, 90, "knife", "#8a8a80"),
    ("fire_poker", "Fire Poker", "Кочерга", 3.5, -2.0, 200, "bat", "#4a4a50"),
]
TOOLS += [
    ("pickaxe_tungsten", "Tungsten Pick", "Вольфрамовая кирка", "pickaxe", 4.0, -2.8, 900, 8.5, "pick", "#8a8a9a"),
    ("pickaxe_rail", "Rail Pick", "Путейская кирка", "pickaxe", 3.5, -2.9, 500, 6.0, "pick", "#7a5a3a"),
    ("shovel_trench", "Trench Shovel", "Окопная лопата", "shovel", 3.5, -2.7, 420, 5.0, "shovel", "#5a6a4a"),
    ("axe_forester", "Forester's Axe", "Топор лесоруба", "axe", 5.5, -3.0, 460, 5.5, "axe", "#7a4a2a"),
    ("hoe_mattock", "Hoe Mattock", "Мотыга", "hoe", 2.0, -1.5, 300, 3.5, "hoe", "#6a5a3a"),
    ("pickaxe_chisel", "Mason's Chisel Pick", "Каменотёсная кирка", "pickaxe", 3.0, -2.6, 380, 5.0, "pick", "#8a8a8a"),
]
GUNS += [
    ("pistol_glock", "Compact Pistol", "Компактный пистолет", 5.5, 6, 1, 2.5, 40, "ammo_9mm", 420, "pistol", "gun_pistol", "#2e3236"),
    ("pistol_silenced", "Suppressed Pistol", "Пистолет с глушителем", 5.0, 8, 1, 1.8, 40, "ammo_9mm", 380, "pistol", "gun_pistol", "#3a3e42"),
    ("pistol_flare", "Flare Pistol", "Ракетница", 6.0, 40, 1, 3.0, 40, "ammo_12g", 120, "pistol", "gun_pistol", "#b8442a"),
    ("smg_mp5", "MP-5 SMG", "ПП МП-5", 4.2, 2, 1, 3.5, 45, "ammo_9mm", 550, "pistol", "gun_smg", "#2a2e32"),
    ("rifle_g36", "Assault Rifle G", "Штурмовая винтовка G", 6.5, 3, 1, 2.2, 80, "ammo_556", 650, "rifle", "gun_rifle", "#3a3e3a"),
    ("rifle_val", "AS Val", "АС «Вал»", 9.0, 3, 1, 2.0, 70, "ammo_9mm", 520, "rifle", "gun_rifle", "#3e4238"),
    ("rifle_mosin_sawed", "Sawed-off Mosin", "Обрез Мосина", 11.0, 24, 1, 3.5, 50, "ammo_762", 260, "rifle", "gun_rifle", "#5a4a32"),
    ("sniper_barrett", "Heavy Sniper", "Крупнокалиберная винтовка", 24.0, 34, 1, 0.1, 180, "ammo_308", 450, "rifle", "gun_sniper", "#3a3e3a"),
    ("shotgun_double_short", "Short Double-Barrel", "Короткая двустволка", 3.4, 22, 8, 8.0, 22, "ammo_12g", 260, "shotgun", "gun_shotgun", "#6a4a2a"),
    ("shotgun_spas", "Auto Shotgun", "Автоматический дробовик", 3.6, 8, 8, 6.5, 28, "ammo_12g", 560, "shotgun", "gun_shotgun", "#2e3236"),
]
_ARMOR2 = [
    ("helmet_tanker", "Tanker Helmet", "Танкошлем", "head", 2, 160, "helmet", "#2a2a2e"),
    ("helmet_pilot", "Pilot Helmet", "Лётный шлем", "head", 2, 180, "helmet", "#5a5a52"),
    ("helmet_welder", "Welder Mask", "Маска сварщика", "head", 3, 220, "helmet", "#3a3a40"),
    ("helmet_heavy", "Heavy Helmet", "Тяжёлый шлем", "head", 5, 460, "helmet", "#3a3e36"),
    ("vest_plate", "Plate Carrier", "Плитник", "chest", 7, 480, "vest", "#3a3a32"),
    ("vest_raincoat", "Raincoat", "Дождевик", "chest", 1, 120, "vest", "#4a6a4a"),
    ("vest_hunter", "Hunter Jacket", "Охотничья куртка", "chest", 4, 260, "vest", "#5a5a3a"),
    ("vest_scrap", "Scrap Armor", "Самодельная броня", "chest", 5, 300, "vest", "#6a5a4a"),
    ("pants_scrap", "Scrap Leg Guards", "Самодельные наколенники", "legs", 3, 240, "pants", "#6a5a4a"),
    ("pants_heavy", "Heavy Leg Armor", "Тяжёлые поножи", "legs", 5, 400, "pants", "#3a3e36"),
    ("pants_denim", "Denim Jeans", "Джинсы", "legs", 2, 140, "pants", "#3a4a6a"),
    ("boots_insulated", "Insulated Boots", "Утеплённые ботинки", "feet", 3, 260, "boots", "#4a3a2a"),
    ("boots_heavy", "Heavy Boots", "Тяжёлые ботинки", "feet", 4, 340, "boots", "#2a2a2e"),
    ("boots_sneakers", "Old Sneakers", "Старые кроссовки", "feet", 1, 100, "boots", "#8a8a8a"),
]
for (i, *_r) in _ARMOR2:
    ARMOR_VALUES[i] = _r[3]
MISC += [(i, en, ru, sl, 1, du, ic, c) for (i, en, ru, sl, ar, du, ic, c) in _ARMOR2]
MISC += [
    ("gas_mask_improvised", "Improvised Gas Mask", "Самодельный противогаз", "head", 1, 0, "mask", "#7a7a6a"),
    ("gas_mask_pbf", "PBF Gas Mask", "Противогаз ПБФ", "head", 1, 0, "mask", "#4a5a4a"),
    ("flashlight_headlamp", "Headlamp", "Налобный фонарь", "flashlight", 1, 700, "flash", "#3a3a3e"),
    ("flashlight_cheap", "Cheap Flashlight", "Дешёвый фонарик", "flashlight", 1, 250, "flash", "#8a6a2a"),
    ("battery_aa", "AA Battery", "Пальчиковая батарейка", "battery", 1, 200, "battery", "#c8a82a"),
    ("battery_solar", "Solar Charger", "Солнечная зарядка", "battery", 1, 1000, "battery", "#2a3a6a"),
    ("filter_charcoal", "Charcoal Filter", "Угольный фильтр", "filter", 16, 800, "filter", "#2a2a2a"),
    ("filter_hepa", "HEPA Filter", "HEPA-фильтр", "filter", 16, 2800, "filter", "#e8e8f0"),
    ("filter_chemical", "Chemical Filter", "Химический фильтр", "filter", 16, 3200, "filter", "#a8c82a"),
    ("filter_composite", "Composite Filter", "Композитный фильтр", "filter", 16, 5000, "filter", "#6a6aa8"),
    ("ammo_flare", "Flares", "Сигнальные патроны", "plain", 64, 0, "shell", "#d8442a"),
    ("ammo_birdshot", "Birdshot", "Мелкая дробь", "plain", 64, 0, "shell", "#8a8a5a"),
    ("ammo_545_ap", "5.45 AP Rounds", "Патроны 5.45 (БП)", "plain", 64, 0, "ammo", "#6a6a6a"),
    ("ammo_762_ap", "7.62 AP Rounds", "Патроны 7.62 (БП)", "plain", 64, 0, "ammo", "#7a7a7a"),
    ("casing_brass", "Brass Casings", "Латунные гильзы", "plain", 64, 0, "casing", "#c89a3a"),
    ("casing_steel", "Steel Casings", "Стальные гильзы", "plain", 64, 0, "casing", "#7a7a7a"),
    ("bullets_lead", "Lead Bullets", "Свинцовые пули", "plain", 64, 0, "ammo", "#6a6a72"),
    ("scope_basic", "Basic Scope", "Прицел", "plain", 4, 0, "flash", "#2a2e32"),
    ("scope_sniper", "Sniper Scope", "Снайперский прицел", "plain", 4, 0, "flash", "#1a1e22"),
    ("suppressor", "Suppressor", "Глушитель", "plain", 4, 0, "canister", "#2a2a2e"),
    ("grip_tactical", "Tactical Grip", "Тактическая рукоять", "plain", 4, 0, "scrap", "#3a3a3a"),
    ("gun_oil", "Gun Oil", "Оружейное масло", "plain", 16, 0, "bottle", "#8a7a3a"),
    ("cleaning_kit", "Cleaning Kit", "Набор для чистки оружия", "plain", 8, 0, "kit", "#5a6a4a"),
    ("barrel_spare", "Spare Barrel", "Запасной ствол", "plain", 4, 0, "scrap", "#4a4a4e"),
    ("spring_steel", "Spring Steel", "Пружинная сталь", "plain", 32, 0, "scrap", "#8a8e94"),
    ("iron_ore_chunk", "Iron Ore Chunk", "Кусок железной руды", "plain", 64, 0, "scrap", "#7a5a4a"),
    ("coal_chunk", "Coal Chunk", "Кусок угля", "plain", 64, 0, "scrap", "#1a1a1e"),
    ("sulfur", "Sulfur", "Сера", "plain", 32, 0, "jar", "#e8e04a"),
    ("saltpeter", "Saltpeter", "Селитра", "plain", 32, 0, "jar", "#e8e8e0"),
    ("alcohol_pure", "Pure Alcohol", "Спирт", "plain", 16, 0, "bottle", "#e0f0f4"),
    ("solvent", "Solvent", "Растворитель", "plain", 16, 0, "bottle", "#c8d84a"),
    ("glue", "Glue", "Клей", "plain", 16, 0, "jar", "#e8e8d0"),
    ("epoxy", "Epoxy Resin", "Эпоксидка", "plain", 16, 0, "jar", "#d8e8f0"),
    ("fabric_kevlar", "Kevlar Fabric", "Кевларовая ткань", "plain", 16, 0, "cloth", "#c8b84a"),
    ("leather_scrap", "Leather Scrap", "Кожа", "plain", 32, 0, "cloth", "#6a4a2a"),
    ("thread_spool", "Thread Spool", "Нитки", "plain", 32, 0, "wire", "#e8e8e8"),
    ("needle_set", "Needle Set", "Иглы", "plain", 16, 0, "nails", "#b8b8b8"),
    ("wire_steel", "Steel Wire", "Стальная проволока", "plain", 64, 0, "wire", "#8a8e94"),
    ("wire_aluminium", "Aluminium Wire", "Алюминиевая проволока", "plain", 64, 0, "wire", "#c0c8d0"),
    ("fuse", "Fuse", "Предохранитель", "plain", 32, 0, "casing", "#c8c8b8"),
    ("relay", "Relay", "Реле", "plain", 32, 0, "board", "#3a4a6a"),
    ("coil_copper", "Copper Coil", "Медная катушка", "plain", 32, 0, "wire", "#d8863a"),
    ("circuit_board_adv", "Advanced Circuit", "Продвинутая плата", "plain", 16, 0, "board", "#3a8a6a"),
    ("processor", "Processor", "Процессор", "plain", 16, 0, "board", "#2a2a32"),
    ("power_cell", "Power Cell", "Энергоячейка", "plain", 16, 0, "battery", "#3ac8e8"),
    ("solar_cell", "Solar Cell", "Солнечная ячейка", "plain", 16, 0, "board", "#2a3a8a"),
    ("generator_part", "Generator Part", "Деталь генератора", "plain", 8, 0, "engine", "#7a7a8a"),
    ("turbine_blade", "Turbine Blades", "Лопасти турбины", "plain", 8, 0, "engine", "#9a9aa8"),
    ("piston", "Piston", "Поршень", "plain", 8, 0, "engine", "#8a8a8a"),
    ("gearbox", "Gearbox", "Коробка передач", "plain", 4, 0, "engine", "#6a6a6e"),
    ("axle", "Axle", "Ось", "plain", 4, 0, "frame", "#5a5a5e"),
    ("spark_plug", "Spark Plug", "Свеча зажигания", "plain", 16, 0, "casing", "#d8d8d8"),
    ("radiator", "Radiator", "Радиатор", "plain", 4, 0, "frame", "#8a5a3a"),
    ("car_battery", "Car Battery", "Автомобильный аккумулятор", "plain", 2, 0, "battery", "#2a2a3a"),
    ("headlight", "Headlight", "Фара", "plain", 4, 0, "flash", "#e8e8c8"),
    ("steering_wheel", "Steering Wheel", "Руль", "plain", 2, 0, "wheel", "#2a2a2a"),
    ("seat_car", "Car Seat", "Автомобильное кресло", "plain", 2, 0, "frame", "#4a3a2a"),
    ("armor_plate_vehicle", "Vehicle Armor Plate", "Бронелист", "plain", 8, 0, "scrap", "#6a6e72"),
    ("wheel_good", "Good Wheel", "Хорошее колесо", "plain", 8, 0, "wheel", "#1a1a1a"),
    ("ring_gold", "Gold Ring", "Золотое кольцо", "plain", 16, 0, "casing", "#f0c84a"),
    ("chain_silver", "Silver Chain", "Серебряная цепочка", "plain", 16, 0, "wire", "#d0d8e0"),
    ("watch_gold", "Gold Watch", "Золотые часы", "plain", 4, 0, "casing", "#f0d060"),
    ("coin_old", "Old Coin", "Старая монета", "plain", 64, 0, "casing", "#b8a060"),
    ("vodka_crate_note", "Vodka Receipt", "Накладная на водку", "plain", 16, 0, "note", "#d8c8a0"),
    ("tape_cassette", "Cassette Tape", "Кассета", "plain", 8, 0, "magazine", "#2a2a2e"),
    ("walkman", "Cassette Player", "Кассетный плеер", "plain", 1, 0, "radio", "#8a8a8e"),
    ("lantern_oil", "Oil Lantern", "Керосиновая лампа", "plain", 1, 0, "flash", "#c8a82a"),
    ("candle", "Candle", "Свеча", "plain", 16, 0, "lighter", "#f0e8c8"),
    ("tent_pack", "Tent", "Палатка", "plain", 1, 0, "kit", "#5a6a4a"),
    ("sleeping_bag", "Sleeping Bag", "Спальник", "plain", 1, 0, "cloth", "#4a5a6a"),
    ("canteen_cup", "Camping Cup", "Походная кружка", "plain", 8, 0, "can", "#9a9aa0"),
    ("cooking_pot", "Cooking Pot", "Котелок", "plain", 4, 0, "can", "#3a3a3e"),
    ("pocket_stove", "Pocket Stove", "Горелка", "plain", 4, 0, "lighter", "#6a6a6e"),
    ("fishing_rod", "Fishing Rod", "Удочка", "plain", 1, 0, "bat", "#8a6a3a"),
    ("fishing_hook", "Fishing Hooks", "Рыболовные крючки", "plain", 32, 0, "nails", "#a8a8a8"),
    ("trap_snare", "Snare Trap", "Петля-ловушка", "plain", 8, 0, "rope", "#8a7a5a"),
    ("trap_bear", "Bear Trap", "Капкан", "plain", 4, 0, "scrap", "#5a5a5e"),
    ("mine_tripwire", "Tripwire Mine", "Растяжка", "plain", 8, 0, "grenade", "#4a5a3a"),
    ("signal_flare", "Signal Flare", "Сигнальная шашка", "plain", 16, 0, "lighter", "#e8442a"),
    ("noisemaker", "Noisemaker", "Трещотка", "plain", 8, 0, "can", "#8a8a5a"),
    ("seed_mushroom", "Mushroom Spores", "Споры грибов", "plain", 32, 0, "pouch", "#8a7a5a"),
    ("seed_potato", "Potato Tubers", "Клубни картофеля", "plain", 32, 0, "pouch", "#a8885a"),
    ("seed_cabbage", "Cabbage Seeds", "Семена капусты", "plain", 32, 0, "pouch", "#6a8a5a"),
    ("fertilizer", "Fertilizer", "Удобрение", "plain", 32, 0, "pouch", "#5a4a3a"),
    ("grow_lamp_part", "Grow Lamp Part", "Деталь фитолампы", "plain", 8, 0, "flash", "#c82a8a"),
    ("hydroponic_tray", "Hydroponic Tray", "Гидропонный лоток", "plain", 4, 0, "frame", "#4a8a5a"),
    ("water_canister", "Water Canister", "Канистра для воды", "plain", 4, 0, "canister", "#3a6a9a"),
    ("pump_part", "Pump Part", "Деталь насоса", "plain", 8, 0, "engine", "#5a6a8a"),
    ("pipe_segment", "Pipe Segment", "Отрезок трубы", "plain", 32, 0, "scrap", "#7a7a80"),
    ("valve", "Valve", "Вентиль", "plain", 16, 0, "wheel", "#a82a2a"),
]

# ---- декор v0.3
_dec("metro_tiles", "Metro Tiles", "Плитка метро", "tiles", [("yellow", "Yellow", "жёлтая", "#a8963a"), ("orange", "Orange", "оранжевая", "#a8622a"), ("teal", "Teal", "бирюзовая", "#3a7a78"),
     ("maroon", "Maroon", "бордовая", "#5a2a30"), ("olive", "Olive", "оливковая", "#6a703a"), ("cream", "Cream", "кремовая", "#c8bc98"), ("navy", "Navy", "тёмно-синяя", "#26384e"), ("pink", "Pink", "розовая", "#a86a78")])
_dec("tiles_cracked", "Cracked Tiles", "Битая плитка", "tiles_cracked", _WB[5:])
_dec("tiles_dirty", "Dirty Tiles", "Грязная плитка", "tiles_dirty", _WB[5:])
_dec("graffiti", "Graffiti Wall", "Стена с граффити", "graffiti", [("red", "Red", "красное", "#c83a3a"), ("blue", "Blue", "синее", "#3a6ac8"), ("green", "Green", "зелёное", "#3ac85a"),
     ("yellow", "Yellow", "жёлтое", "#d8c83a"), ("white", "White", "белое", "#e8e8e8"), ("purple", "Purple", "фиолетовое", "#8a3ac8")])
_dec("brick", "Bricks", "Кирпич", "brick", [("gray", "Gray", "серый", "#6a6a6e"), ("blue", "Blue", "синий", "#4a5a6e"), ("black", "Black", "чёрный", "#2a2a2e"), ("mossy", "Mossy", "мшистый", "#5a6a4a")])
_dec("wallpaper", "Wallpaper", "Обои", "wallpaper", [("e", "Blue", "синие", "#5a6a8a"), ("f", "Pink", "розовые", "#a88a92"), ("g", "Yellow", "жёлтые", "#b8a85a"), ("h", "Dark", "тёмные", "#4a4048")])
_dec("steel_panel", "Steel Panel", "Стальная панель", "panel", [("e", "Rust", "ржавая", "#8a5a3a"), ("f", "Yellow", "жёлтая", "#a89a3a"), ("g", "Red", "красная", "#8a3a3a"), ("h", "White", "белая", "#b8bcc0")])
_dec("crate", "Crate", "Ящик", "crate", [("food", "Food", "с едой", "#8a7a4a"), ("tools", "Tools", "с инструментами", "#8a3a2a"), ("fuel", "Fuel", "с топливом", "#8a2a2a"), ("electronics", "Electronics", "с электроникой", "#2a5a6a")])
_dec("barrel", "Barrel", "Бочка", "barrel", [("yellow", "Yellow", "жёлтая", "#b89a2a"), ("green", "Green", "зелёная", "#3a6a3a"), ("white", "White", "белая", "#b8b8b0")])
_dec("locker", "Locker", "Шкафчик", "locker", [("black", "Black", "чёрный", "#2a2a2e"), ("yellow", "Yellow", "жёлтый", "#a89a3a"), ("red", "Red", "красный", "#8a3a3a")])
_dec("pipes", "Pipes", "Трубы", "pipes", [("e", "Blue", "синие", "#3a5a8a"), ("f", "Yellow", "жёлтые", "#b89a2a"), ("g", "Black", "чёрные", "#2a2a2e")])
_dec("hazard", "Hazard Stripes", "Предупреждающая разметка", "hazard", [("w", "White", "белая", "#e0e0e0"), ("o", "Orange", "оранжевая", "#d86a2a"), ("g", "Green", "зелёная", "#2a9a4a")])
_dec("vent", "Vent", "Вентиляция", "vent", [("d", "White", "белая", "#c0c4c8"), ("e", "Green", "зелёная", "#4a6a4a")])
_dec("wood_planks", "Planks", "Доски", "planks", [("d", "Light", "светлые", "#a88a5a"), ("e", "Painted", "крашеные", "#6a7a6a"), ("f", "Charred", "обугленные", "#2a2420")])
_dec("sandbags", "Sandbags", "Мешки с песком", "sandbag", [("d", "Brown", "коричневые", "#7a5a3a"), ("e", "Dark", "тёмные", "#4a4a44")])
_dec("tunnel_lamp", "Tunnel Lamp", "Тоннельная лампа", "lamp", [("blue", "Blue", "синяя", "#8ab8f0"), ("orange", "Orange", "оранжевая", "#f0a84a")], light=11, strength=1.5)
_dec("neon", "Neon Sign", "Неоновая вывеска", "neon", [("yellow", "Yellow", "жёлтая", "#ffe83a"), ("white", "White", "белая", "#e8f0ff"), ("purple", "Purple", "фиолетовая", "#a83aff"), ("orange", "Orange", "оранжевая", "#ff8a3a")], light=10, strength=1.5)
_dec("metro_sign", "Metro Sign", "Указатель", "sign", [("e", "Medical", "медпункт", "#2a8a6a"), ("f", "Radiation", "радиация", "#c8b82a"), ("g", "Biohazard", "биоопасность", "#8a3ac8"),
     ("h", "No Entry", "вход запрещён", "#c82a2a"), ("i", "Gas Mask Zone", "зона противогазов", "#2a4a8a"), ("j", "Armory", "оружейная", "#4a5a3a")])
_dec("screen", "Dead Monitor", "Мёртвый монитор", "screen", [("c", "Blue Screen", "синий экран", "#2a4a9a"), ("d", "Green Text", "зелёный текст", "#1a4a2a")], light=2)
_dec("server_rack", "Server Rack", "Серверная стойка", "rack", [("c", "Red Lights", "красные огни", "#2a2e32"), ("d", "Rusty", "ржавая", "#3a2a22")], light=3)
_dec("mesh", "Chain-link Fence", "Сетка-рабица", "mesh", [("a", "Gray", "серая", "#8a8e92"), ("b", "Rusty", "ржавая", "#8a5a3a"), ("c", "Green", "зелёная", "#4a6a4a")])
_dec("tarp", "Tarp", "Брезент", "tarp", [("green", "Green", "зелёный", "#4a5a3a"), ("blue", "Blue", "синий", "#3a5a8a"), ("gray", "Gray", "серый", "#6a6e70"), ("orange", "Orange", "оранжевый", "#b8642a")])
_dec("moss", "Cave Moss", "Пещерный мох", "moss", [("green", "Green", "зелёный", "#3a6a2a"), ("yellow", "Yellow", "жёлтый", "#8a8a2a"), ("blue", "Blue", "синий", "#2a5a7a")], light=3)
_dec("flesh", "Mutant Growth", "Мутантная плоть", "flesh", [("red", "Red", "красная", "#7a2a30"), ("pale", "Pale", "бледная", "#a88a82"), ("glow", "Glowing", "светящаяся", "#6aa82a")], light=5, strength=1.0)
_dec("carpet", "Carpet", "Ковёр", "carpet", [("red", "Red", "красный", "#7a2a30"), ("green", "Green", "зелёный", "#3a5a3a"), ("blue", "Blue", "синий", "#2a3a6a"), ("gray", "Gray", "серый", "#5a5a5e")])
_dec("switchboard", "Switchboard", "Электрощит", "switchboard", [("a", "Gray", "серый", "#6a7076"), ("b", "Green", "зелёный", "#4a6a4a"), ("c", "Red", "красный", "#8a3a3a"), ("d", "Old", "старый", "#7a6a4a")])


# ---- v0.4: урожай с грядок
CONSUMABLES += [
    ("potato", "Potato", "Картофель", "food", 4, 0.4, 0, 0, 0, [], "jar", "#a8885a"),
    ("cabbage", "Cabbage", "Капуста", "food", 3, 0.3, 3, 0, 0, [], "jar", "#7aa05a"),
    ("mushroom_champignon", "Champignon", "Шампиньоны", "food", 4, 0.4, 0, 0, 0, [], "jar", "#d8c8a8"),
]

# ---- вкладки креатива: (ключ, иконка, en, ru)
TABS = [
    ("food", "canned_stew", "Food", "Продукты"),
    ("drinks", "clean_water", "Drinks", "Напитки"),
    ("medicine", "medkit", "Medicine", "Медицина"),
    ("melee", "machete", "Melee Weapons", "Холодное оружие"),
    ("firearms", "rifle_ak74", "Firearms", "Огнестрел"),
    ("ammo", "ammo_545", "Ammo", "Патроны"),
    ("explosives", "grenade", "Grenades", "Гранаты и взрывчатка"),
    ("tools", "pickaxe_miner", "Tools", "Инструменты"),
    ("clothing", "vest_kevlar", "Clothing & Armor", "Одежда и броня"),
    ("protection", "gas_mask", "Gas Masks & Filters", "Противогазы и фильтры"),
    ("power", "generator_t1", "Electronics & Base", "Электрика и база"),
    ("blueprints", "blueprint_generator_t2", "Blueprints", "Чертежи"),
    ("farm", "seed_potato", "Farming & Water", "Ферма и вода"),
    ("transport", "vehicle_kit_buggy", "Transport & Fuel", "Транспорт и топливо"),
    ("components", "circuit_board", "Components & Junk", "Компоненты и хлам"),
    ("gear", "flashlight", "Gear & Survival", "Снаряжение"),
    ("decor", "metro_tiles_gray", "Decoration Blocks", "Декоративные блоки"),
]

MISC.append(("ammo_guide", "Ammo Handbook", "Справочник по боеприпасам", "plain", 1, 0, "book", "#3a5a3a"))

GUN_MAG = {  # id: (магазин, время перезарядки в тиках)
    "pistol_flare": (1, 60), "pistol_deagle": (7, 45), "revolver_magnum": (6, 75), "revolver_nagant": (7, 75),
    "pistol_stechkin": (20, 50), "shotgun_toz": (2, 70), "shotgun_sawedoff": (2, 60), "shotgun_double_short": (2, 60),
    "rifle_mosin": (5, 85), "rifle_bolt": (5, 85), "rifle_sks": (10, 60), "rifle_lmg": (100, 150), "rifle_vss": (20, 55),
    "rifle_val": (20, 55), "sniper_barrett": (5, 95), "shotgun_pump": (7, 85), "shotgun_saiga": (8, 60), "shotgun_spas": (8, 60),
    "shotgun_bar": (8, 70),
}
GUN_MAG_DEFAULT = {"gun_pistol": (10, 40), "gun_smg": (30, 50), "gun_rifle": (30, 60), "gun_sniper": (5, 75), "gun_shotgun": (6, 80)}


def tab_of(i, kind_hint=None):
    """Вкладка креатива для предмета/блока по id."""
    ids = {r[0]: r for r in MISC}
    if i in {r[0] for r in CONSUMABLES}:
        k = [r for r in CONSUMABLES if r[0] == i][0][3]
        if i in ("potato", "cabbage", "mushroom_champignon"): return "farm"
        return {"food": "food", "drink": "drinks", "med": "medicine"}[k]
    if i in {r[0] for r in MELEE}: return "melee"
    if i in {r[0] for r in TOOLS}: return "tools"
    if i in {r[0] for r in GUNS}: return "firearms"
    if i in {d[0] for d in DECOR}: return "decor"
    if i.startswith("blueprint_"): return "blueprints"
    if i in ("hatch", "emergency_filter") or any(i.startswith(k + "_t") for k, _, _ in KINDS): return "power"
    if i in ids:
        r = ids[i]; ty = r[3]
        if ty in ("head", "chest", "legs", "feet"):
            return "protection" if (i.startswith(("gas_mask", "respirator", "hazmat_suit"))) else "clothing"
        if ty == "filter": return "protection"
        if ty in ("flashlight", "battery"): return "power"
        if ty in ("grenade", "molotov") or i == "mine_tripwire": return "explosives"
        if ty == "kit" or i.startswith(("canister", "fuel_")) or i in ("engine_part", "wheel_worn", "car_frame", "piston", "gearbox", "axle", "spark_plug",
                "radiator", "car_battery", "headlight", "steering_wheel", "seat_car", "armor_plate_vehicle", "wheel_good", "lubricant", "fuel_additive"):
            return "transport"
        if i.startswith(("ammo_", "casing_")) or i in ("bullets_lead", "gunpowder_pack", "primer_box"): return "ammo"
        if i in ("magazine_empty", "scope_basic", "scope_sniper", "suppressor", "grip_tactical", "gun_oil", "cleaning_kit", "barrel_spare"): return "firearms"
        if i in ("seed_mushroom", "seed_potato", "seed_cabbage", "fertilizer", "grow_lamp_part", "hydroponic_tray", "water_canister", "pump_part",
                 "water_tablet", "flask_empty", "flask_steel", "flask_glass", "valve", "pipe_segment"): return "farm"
        if ty in ("lighter", "flask") or i in ("radio", "radio_handheld", "geiger_counter", "compass", "binoculars", "map_metro", "map_city", "book_survival",
                "book_medical", "book_engineering", "journal_old", "key_card", "key_rusty", "toolbox", "repair_kit", "backpack_scrap", "pouch_small", "cigarettes",
                "playing_cards", "toy_old", "watch_wrist", "ammo_guide", "gold_casing_bundle", "gold_casing", "note_old", "tent_pack", "sleeping_bag", "canteen_cup", "cooking_pot",
                "pocket_stove", "fishing_rod", "fishing_hook", "trap_snare", "trap_bear", "signal_flare", "noisemaker", "ring_gold", "chain_silver", "watch_gold",
                "coin_old", "vodka_crate_note", "tape_cassette", "walkman", "lantern_oil", "candle"):
            return "gear"
    return "components"
