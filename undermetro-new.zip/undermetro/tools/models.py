"""Генератор детальных 3D-моделей предметов (оружие, холодное, инструменты, счётчик Гейгера).

Каждая модель = набор боксов + палитровая текстура 32x32 (ячейки 4x4 px, 64 цвета, с шумом).
Оружие строится вдоль оси X: ДУЛО при малых x, ПРИКЛАД при больших x.
Если в игре ствол смотрит на игрока — поменяйте GUN_FLIP на -1 (и перегенерируйте).
"""
import json
import os
import random

from PIL import Image

GUN_FLIP = 1  # 1: ствол вперёд (по умолчанию). -1: развернуть, если в руках всё наоборот.

PAL_COLORS = {
    "m": "#3a3d42", "M": "#9aa2a8", "k": "#17181a", "w": "#8a5a30", "W": "#5a3a1e", "p": "#2b2d30",
    "g": "#202224", "b": "#c9a23a", "r": "#7a4a2a", "l": "#7fd0ff", "o": "#d9611f", "y": "#d8b72c",
    "R": "#8b2a22", "G": "#5c6b45", "t": "#d8d2c0", "s": "#c8d0d4", "d": "#55595e", "n": "#2d5a35",
    "e": "#35e07a", "h": "#14301c", "L": "#8f6a3c", "c": "#b8742f", "u": "#3a5a8a", "x": "#e8e8e8",
}


def hx(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


class Model:
    def __init__(self, palette=None):
        self.pal = dict(PAL_COLORS)
        if palette:
            self.pal.update(palette)
        self.boxes = []  # (x1,y1,z1,x2,y2,z2,c)

    def box(self, x1, y1, z1, x2, y2, z2, c):
        if x2 < x1: x1, x2 = x2, x1
        if y2 < y1: y1, y2 = y2, y1
        if z2 < z1: z1, z2 = z2, z1
        if x2 - x1 <= 0 or y2 - y1 <= 0 or z2 - z1 <= 0:
            return
        self.boxes.append((x1, y1, z1, x2, y2, z2, c))

    def S(self, x1, x2, y1, y2, hz, c, zc=8.0):
        """Бокс, симметричный по Z (полуширина hz)."""
        self.box(x1, y1, zc - hz, x2, y2, zc + hz, c)

    # ------------------------------------------------------------ вывод
    def keys(self):
        ks = []
        for b in self.boxes:
            if b[6] not in ks:
                ks.append(b[6])
        return ks

    def texture(self, seed=0, extra_keys=()):
        ks = self.keys()
        for k in extra_keys:
            if k not in ks:
                ks.append(k)
        rnd = random.Random(seed)
        img = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
        px = img.load()
        for i, k in enumerate(ks[:64]):
            cx, cy = i % 8, i // 8
            base = hx(self.pal[k])
            for dx in range(4):
                for dy in range(4):
                    n = rnd.randint(-7, 7)
                    px[cx * 4 + dx, cy * 4 + dy] = tuple(max(0, min(255, v + n)) for v in base) + (255,)
        return img, ks

    def json(self, ks, display, textures_extra=None, gui_light="side"):
        els = []
        for (x1, y1, z1, x2, y2, z2, c) in self.boxes:
            i = ks.index(c)
            cx, cy = i % 8, i // 8
            uv = [cx * 2 + 0.5, cy * 2 + 0.5, cx * 2 + 1.5, cy * 2 + 1.5]
            els.append({"from": [round(x1, 3), round(y1, 3), round(z1, 3)], "to": [round(x2, 3), round(y2, 3), round(z2, 3)],
                        "faces": {f: {"uv": uv, "texture": "#p"} for f in ("north", "east", "south", "west", "up", "down")}})
        return els


def flipx(m):
    """Зеркалит модель по X вокруг центра (для GUN_FLIP = -1)."""
    out = []
    for (x1, y1, z1, x2, y2, z2, c) in m.boxes:
        out.append((16 - x2, y1, z1, 16 - x1, y2, z2, c))
    m.boxes = out


# ====================================================================== ОРУЖИЕ
def trigger_group(m, x, y0=5.8, y1=8.0, w=3.0, c="p"):
    m.S(x, x + 0.5, y0, y1, 0.5, c)
    m.S(x, x + w, y0, y0 + 0.5, 0.5, c)
    m.S(x + w - 0.5, x + w, y0, y1 - 0.8, 0.5, c)
    m.S(x + w / 2 - 0.2, x + w / 2 + 0.2, y0 + 0.5, y1, 0.3, "M")


def pistol(m, o):
    sl = o.get("slide", 8.5)
    x0 = o.get("x0", 3.5)
    big = o.get("big", 0)
    zh = 1.1 + 0.25 * big
    m.S(x0 - 0.8, x0 + 0.6, 9.0, 10.2 + 0.2 * big, 0.55 + 0.1 * big, "M")  # ствол
    m.S(x0, x0 + sl, 8.4, 10.8 + 0.3 * big, zh, o.get("slide_c", "m"))  # затвор
    m.S(x0 + 0.6, x0 + sl - 0.5, 10.8 + 0.3 * big, 11.1 + 0.3 * big, 0.4, "k")  # планка
    m.S(x0 + sl - 2.2, x0 + sl - 0.2, 8.6, 10.6, zh + 0.08, "k")  # насечки
    m.S(x0 + 3, x0 + 5.6, 9.2, 10.2, zh + 0.06, "k")  # окно выброса
    m.S(x0 + 0.2, x0 + sl - 1.0, 7.2, 8.4, 1.0, o.get("frame_c", "p"))  # рамка
    if o.get("rail"):
        for i in range(3):
            m.S(x0 + 1.0 + i * 0.9, x0 + 1.5 + i * 0.9, 7.0, 7.3, 1.1, "k")
    trigger_group(m, x0 + 2.6)
    gx = x0 + sl - 2.4
    gc = o.get("grip_c", "g")
    m.S(gx, gx + 2.6, 4.4, 7.2, 1.1, gc)
    m.S(gx + 0.3, gx + 2.9, 2.4, 4.4, 1.1, gc)
    m.S(gx + 0.6, gx + 3.2, 0.9, 2.4, 1.1, gc)
    m.S(gx + 0.4, gx + 2.4, 3.0, 6.8, 1.2, o.get("panel_c", "W"))
    m.S(gx + 0.5, gx + 3.3, 0.5, 0.9, 1.15, "k")
    m.S(x0 + 0.3, x0 + 0.9, 10.9, 11.5, 0.25, "k")  # мушка
    m.S(x0 + sl - 1.0, x0 + sl - 0.5, 10.9, 11.5, 0.7, "k")  # целик
    m.S(x0 + sl - 0.2, x0 + sl + 0.5, 9.6, 10.7, 0.3, "M")  # курок
    if o.get("supp"):
        m.S(x0 - 5.0, x0 - 0.2, 8.9, 10.3, 0.75, "k")
        m.S(x0 - 5.0, x0 - 4.8, 8.8, 10.4, 0.8, "d")
    if o.get("flare"):
        m.S(x0 - 1.0, x0 + 2.0, 8.8, 10.8, 1.1, "o")


def revolver(m, o):
    bl = o.get("bl", 6.0)
    x0 = 3.0
    m.S(x0, x0 + bl, 8.6, 9.8, 0.7, "m")
    m.S(x0, x0 + bl, 9.8, 10.2, 0.35, "M")
    m.S(x0, x0 + 0.5, 10.2, 10.8, 0.25, "k")
    m.S(x0 + 0.4, x0 + bl - 0.8, 7.6, 8.6, 0.3, "M")  # эжектор
    cx = x0 + bl
    m.S(cx, cx + 3.2, 7.0, 10.3, 1.3, "M")  # барабан
    for i in range(6):
        yy = 7.4 + (i % 3) * 1.0
        m.S(cx + 0.4 + (i // 3) * 1.4, cx + 1.4 + (i // 3) * 1.4, yy, yy + 0.6, 1.37, "k")
    m.S(cx - 0.4, cx + 4.6, 7.2, 10.6, 0.8, "m")  # рамка
    m.S(cx + 3.2, cx + 5.2, 9.2, 10.8, 0.9, "m")
    m.S(cx + 4.6, cx + 5.6, 10.0, 11.0, 0.3, "M")  # курок
    trigger_group(m, cx + 0.4, 5.6, 7.4, 2.4)
    gx = cx + 3.0
    m.S(gx, gx + 2.4, 4.6, 7.4, 1.0, "W")
    m.S(gx + 0.4, gx + 2.9, 2.6, 4.6, 1.0, "w")
    m.S(gx + 0.8, gx + 3.3, 1.0, 2.6, 1.0, "W")
    m.S(gx + 0.7, gx + 3.4, 0.6, 1.0, 0.9, "M")


def smg(m, o):
    r0 = o.get("r0", 6.0)
    r1 = o.get("r1", 14.0)
    m.S(r0, r1, 7.8, 10.6, 1.3, "m")
    m.S(r0 + 0.5, r1 - 0.5, 10.6, 11.0, 0.8, "k")
    m.S(r1 - 1.6, r1 - 0.6, 11.0, 11.7, 0.6, "k")  # целик
    sh = o.get("shroud", 4.0)
    m.S(r0 - sh, r0, 8.3, 10.2, 0.95, "d")
    for i in range(int(sh * 1.4)):
        xx = r0 - sh + 0.4 + i * 0.7
        m.S(xx, xx + 0.35, 8.9, 9.6, 1.0, "k")
    m.S(r0 - sh - 1.0, r0 - sh, 8.8, 9.7, 0.45, "M")
    m.S(r0 - sh - 0.5, r0 - sh, 10.2, 11.2, 0.3, "k")  # мушка
    mx = r0 + o.get("magx", 1.5)
    ms = o.get("mag", "box")
    if ms == "box":
        m.S(mx, mx + 1.8, 2.0, 7.8, 0.9, "k")
        m.S(mx - 0.05, mx + 1.85, 1.6, 2.0, 1.0, "m")
    elif ms == "curved":
        m.S(mx, mx + 1.8, 5.0, 7.8, 0.9, "k")
        m.S(mx + 0.4, mx + 2.2, 3.0, 5.0, 0.9, "k")
        m.S(mx + 0.9, mx + 2.7, 1.2, 3.0, 0.9, "k")
    elif ms == "helical":
        m.S(mx - 1.2, mx + 4.5, 4.4, 7.8, 1.0, "d")  # шнековый магазин под стволом
        m.S(mx - 1.2, mx + 4.5, 4.4, 5.0, 1.1, "m")
    elif ms == "grip":
        pass
    gx = r1 - 3.0
    m.S(gx, gx + 2.2, 4.4, 7.8, 1.0, "g")
    m.S(gx + 0.3, gx + 2.6, 2.6, 4.4, 1.0, "g")
    trigger_group(m, gx - 3.2, 5.8, 7.8, 2.8)
    # приклад
    st = o.get("stock", "skel")
    if st == "skel":
        m.S(r1, r1 + 2.2, 8.8, 9.4, 0.35, "M")
        m.S(r1 + 1.8, r1 + 2.2, 6.2, 9.4, 0.35, "M")
        m.S(r1, r1 + 2.2, 6.2, 6.8, 0.35, "M")
        m.S(r1 + 1.9, r1 + 2.4, 6.0, 9.6, 0.6, "k")
    elif st == "wood":
        m.S(r1, r1 + 2.4, 7.4, 9.8, 0.9, "w")
        m.S(r1 + 2.0, r1 + 2.2, 6.0, 9.6, 0.95, "k")
    elif st == "fold":
        m.S(r1, r1 + 2.2, 9.0, 9.6, 0.5, "M")
        m.S(r1 + 2.0, r1 + 2.4, 6.4, 9.6, 0.5, "k")


def rifle(m, o):
    """Универсальная винтовка/автомат (x: 0 — дуло, 16 — приклад)."""
    poly = o.get("poly", False)
    wc = "p" if poly else "w"
    wd = "g" if poly else "W"
    r0 = o.get("r0", 7.5)  # начало ствольной коробки
    r1 = o.get("r1", 12.0)
    ye = o.get("y", 7.6)  # низ ствольной коробки
    # ствол
    bx = o.get("bx", 1.2)
    m.S(bx, r0 + 0.5, 9.0, 9.9, 0.45, "M")
    muz = o.get("muz")
    if muz == "brake":
        m.S(bx - 1.0, bx + 0.6, 8.8, 10.1, 0.65, "d")
        m.S(bx - 0.8, bx - 0.5, 8.6, 10.3, 0.7, "k")
    elif muz == "supp":
        m.S(bx - 3.2, bx + 3.0, 8.6, 10.3, 0.9, "k")
        m.S(bx - 3.2, bx - 3.0, 8.5, 10.4, 0.95, "d")
    elif muz == "flash":
        m.S(bx - 0.9, bx + 0.6, 8.8, 10.1, 0.6, "d")
        for i in range(3):
            m.S(bx - 0.9 + i * 0.5, bx - 0.7 + i * 0.5, 8.7, 10.2, 0.68, "k")
    # мушка
    if o.get("sight", True):
        m.S(bx + 0.4, bx + 1.0, 9.9, 11.4, 0.25, "k")
        m.S(bx + 0.2, bx + 1.2, 9.9, 10.3, 0.5, "k")
    # газоотвод / цевьё
    hg = o.get("hg", "wood")
    hx0 = o.get("hx0", bx + 3.0)
    if hg == "wood":
        m.S(hx0, r0, 7.6, 9.4, 1.05, wc)
        m.S(hx0 + 0.8, r0 - 0.3, 9.4, 10.4, 0.85, wc)
        m.S(hx0, hx0 + 0.3, 7.6, 9.4, 1.12, wd)
        m.S(hx0 + 3.8, hx0 + 4.1, 7.6, 9.4, 1.12, wd)
        m.S(hx0 - 1.2, hx0 + 4.5, 10.4, 10.9, 0.45, "M")  # газовая трубка
    elif hg == "poly":
        m.S(hx0, r0, 7.8, 9.8, 1.05, "p")
        for i in range(4):
            m.S(hx0 + 0.6 + i * 0.9, hx0 + 0.9 + i * 0.9, 8.4, 9.4, 1.12, "k")
    elif hg == "rail":
        m.S(hx0 - 0.5, r0, 7.8, 10.0, 1.0, "p")
        for i in range(int((r0 - hx0) / 0.9)):
            m.S(hx0 - 0.3 + i * 0.9, hx0 + 0.1 + i * 0.9, 10.0, 10.4, 0.55, "k")
        m.S(hx0 - 0.5, hx0 + 1.5, 7.2, 7.8, 0.6, "k")  # передняя рукоять
        m.S(hx0 + 0.8, hx0 + 1.4, 6.0, 7.2, 0.5, "g")
    elif hg == "tube":
        m.S(hx0, r0 - 0.5, 8.0, 9.4, 0.9, "d")
    elif hg == "wood_long":
        m.S(hx0 - 1.2, r0, 8.0, 9.5, 0.95, wc)
        m.S(hx0 - 1.2, hx0 - 0.8, 8.0, 9.5, 1.0, "M")
        m.S(hx0 + 3.5, hx0 + 3.8, 8.0, 9.5, 1.0, "M")
    # ствольная коробка
    m.S(r0, r1, ye, ye + 2.9, 1.1, "m")
    m.S(r0 + 0.3, r1, ye + 2.9, ye + 3.2, 0.9, "d")  # крышка
    m.S(r0 + 1.0, r0 + 3.0, ye + 1.2, ye + 2.4, 1.18, "k")  # окно выброса
    if o.get("bolt"):
        m.S(r0 + 3.2, r0 + 4.0, ye + 1.6, ye + 2.2, 1.6, "M")
        m.S(r0 + 3.4, r0 + 3.8, ye + 1.6, ye + 2.2, 2.2, "M")
        m.S(r0 + 3.1, r0 + 4.1, ye + 1.4, ye + 2.4, 2.4, "k")
    # прицельные
    op = o.get("optic")
    if op == "pso":
        m.S(r0 + 0.5, r0 + 5.5, 11.2, 12.4, 0.6, "k")
        m.S(r0 + 0.2, r0 + 0.6, 11.0, 12.6, 0.75, "l")
        m.S(r0 + 5.4, r0 + 5.9, 11.0, 12.6, 0.7, "d")
        m.S(r0 + 1.5, r0 + 4.0, ye + 3.2, 11.2, 0.4, "k")
    elif op == "scope":
        m.S(r0 - 1.5, r1 - 0.5, 11.4, 12.8, 0.7, "k")
        m.S(r0 - 2.2, r0 - 1.5, 11.1, 13.1, 0.95, "d")
        m.S(r0 - 2.3, r0 - 2.15, 11.3, 12.9, 0.8, "l")
        m.S(r1 - 0.5, r1 + 0.6, 11.2, 13.0, 0.85, "d")
        m.S(r0 + 1.0, r0 + 1.8, ye + 3.2, 11.4, 0.4, "M")
        m.S(r1 - 2.0, r1 - 1.2, ye + 3.2, 11.4, 0.4, "M")
        m.S(r0 + 2.4, r0 + 3.3, 12.8, 13.4, 0.4, "M")  # барабанчик
    elif op == "bigscope":
        m.S(r0 - 2.5, r1 + 1.0, 11.5, 13.2, 0.85, "k")
        m.S(r0 - 3.6, r0 - 2.5, 11.2, 13.6, 1.2, "d")
        m.S(r0 - 3.7, r0 - 3.55, 11.5, 13.3, 1.0, "l")
        m.S(r1 + 0.6, r1 + 1.6, 11.3, 13.4, 1.05, "d")
        m.S(r0 - 0.5, r0 + 0.5, ye + 3.2, 11.5, 0.5, "M")
        m.S(r1 - 1.5, r1 - 0.5, ye + 3.2, 11.5, 0.5, "M")
        m.S(r0 + 1.5, r0 + 2.6, 13.2, 14.0, 0.5, "M")
    elif op == "carry":
        m.S(r0 + 0.5, r1 - 0.5, ye + 3.2, ye + 3.5, 0.35, "k")
        m.S(r0 + 1.0, r0 + 1.8, ye + 3.2, 11.8, 0.35, "p")
        m.S(r1 - 2.0, r1 - 1.2, ye + 3.2, 11.8, 0.35, "p")
        m.S(r0 + 0.8, r1 - 0.4, 11.4, 12.2, 0.6, "p")
        m.S(r0 + 1.0, r0 + 1.4, 11.5, 12.1, 0.65, "l")
    elif op == "dot":
        m.S(r0 + 1.0, r0 + 3.5, ye + 3.2, 11.6, 0.8, "k")
        m.S(r0 + 3.4, r0 + 3.6, ye + 3.4, 11.4, 0.85, "l")
    elif op == "iron":
        m.S(r1 - 1.2, r1 - 0.6, ye + 3.2, ye + 4.2, 0.7, "k")
        m.S(r1 - 1.2, r1 - 0.6, ye + 3.2, ye + 3.5, 0.9, "k")
    # магазин
    mg = o.get("mag", "ak")
    mx = o.get("magx", r0 + 1.2)
    if mg == "ak":
        m.S(mx, mx + 1.8, 5.0, ye, 0.85, "k")
        m.S(mx + 0.5, mx + 2.4, 3.2, 5.0, 0.85, "k")
        m.S(mx + 1.1, mx + 3.0, 1.4, 3.2, 0.85, "k")
        m.S(mx - 0.05, mx + 1.85, 4.9, 5.1, 0.95, "d")
    elif mg == "straight":
        m.S(mx, mx + 1.9, 2.4, ye, 0.85, "k")
        m.S(mx - 0.05, mx + 1.95, 2.2, 2.6, 0.95, "m")
    elif mg == "short":
        m.S(mx, mx + 1.9, 4.6, ye, 0.85, "k")
        m.S(mx - 0.05, mx + 1.95, 4.4, 4.8, 0.95, "m")
    elif mg == "drum":
        m.S(mx - 0.5, mx + 3.5, 2.8, ye, 1.3, "d")
        m.S(mx - 0.2, mx + 3.2, 3.0, 5.0, 1.4, "m")
        m.S(mx + 0.5, mx + 2.5, 3.8, 4.2, 1.45, "k")
    elif mg == "box":
        m.S(mx - 1.0, mx + 4.0, 2.2, ye, 1.6, "G")
        m.S(mx - 1.0, mx + 4.0, 2.2, 2.6, 1.7, "k")
        m.S(mx + 1.2, mx + 1.6, 2.8, ye, 1.75, "k")
    elif mg == "internal":
        m.S(mx, mx + 2.2, ye - 0.9, ye, 0.95, "m")
    elif mg == "tube":
        pass
    # спусковая скоба, рукоять
    gx = r1 - 3.2
    m.S(gx - 1.6, gx - 1.1, ye - 1.8, ye, 0.5, "p")
    m.S(gx - 1.6, gx + 0.2, ye - 1.8, ye - 1.3, 0.5, "p")
    m.S(gx - 0.2, gx + 0.2, ye - 1.8, ye, 0.5, "p")
    m.S(gx - 1.0, gx - 0.6, ye - 1.4, ye, 0.28, "M")
    st = o.get("stock", "wood")
    if st != "bullpup":
        m.S(r1 - 1.9, r1 - 0.1, ye - 2.6, ye, 0.95, wd if o.get("poly") else "W")
        m.S(r1 - 1.6, r1 + 0.2, ye - 4.6, ye - 2.6, 0.95, wd if o.get("poly") else "W")
        m.S(r1 - 1.4, r1 + 0.4, ye - 4.8, ye - 4.4, 0.9, "k")
    # приклад
    if st == "wood":
        m.S(r1, r1 + 1.8, ye + 0.3, ye + 2.9, 1.0, wc)
        m.S(r1 + 1.8, 14.5, ye - 0.2, ye + 2.6, 1.0, wc)
        m.S(14.5, 15.4, ye - 1.2, ye + 2.4, 1.0, wc)
        m.S(15.4, 15.9, ye - 1.6, ye + 2.4, 1.05, "k")
    elif st == "sniper":
        m.S(r1, r1 + 1.6, ye + 0.3, ye + 3.2, 1.0, wc)
        m.S(r1 + 1.6, 14.0, ye - 0.4, ye + 3.2, 1.0, wc)
        m.S(14.0, 15.4, ye - 2.2, ye + 3.2, 1.0, wc)
        m.S(15.4, 15.9, ye - 2.4, ye + 3.2, 1.05, "k")
        m.S(r1 + 1.6, 12.8 + 1.4, ye - 1.2, ye - 0.4, 1.0, wc)
    elif st == "thumb":
        m.S(r1, 14.4, ye + 0.6, ye + 3.0, 1.0, wc)
        m.S(14.4, 15.4, ye - 2.0, ye + 3.0, 1.0, wc)
        m.S(r1 + 0.8, r1 + 2.2, ye - 0.8, ye + 0.6, 1.0, wc)
        m.S(15.4, 15.9, ye - 2.2, ye + 3.0, 1.05, "k")
    elif st == "skel":
        m.S(r1, 15.2, ye + 2.2, ye + 2.8, 0.35, "M")
        m.S(14.7, 15.2, ye - 1.2, ye + 2.8, 0.35, "M")
        m.S(r1, 15.2, ye - 1.2, ye - 0.6, 0.35, "M")
        m.S(15.2, 15.8, ye - 1.5, ye + 3.0, 0.7, "k")
    elif st == "fold":
        m.S(r1, 15.0, ye + 2.0, ye + 2.6, 0.5, "M")
        m.S(15.0, 15.6, ye - 0.8, ye + 2.8, 0.55, "k")
    elif st == "adj":
        m.S(r1, 14.0, ye + 1.4, ye + 2.4, 0.7, "d")
        m.S(14.0, 15.6, ye - 0.9, ye + 3.0, 0.8, "p")
        m.S(15.6, 15.9, ye - 1.1, ye + 3.1, 0.85, "k")
        m.S(r1 + 0.8, 14.0, ye + 0.2, ye + 1.4, 0.55, "p")
    elif st == "bullpup":
        m.S(r1, 15.6, ye - 0.6, ye + 3.2, 1.2, "p")
        m.S(15.6, 15.9, ye - 0.8, ye + 3.2, 1.25, "k")
    if o.get("bipod"):
        m.S(bx + 3.2, bx + 3.7, 5.4, 8.0, 1.8, "m", )
        m.S(bx + 3.1, bx + 3.8, 5.2, 5.6, 2.0, "k")
        m.S(bx + 3.2, bx + 3.7, 7.2, 9.0, 0.5, "m")
    if o.get("sling"):
        m.S(bx + 4, r1 + 2, ye - 0.3, ye + 0.1, 0.12, "R")
    if o.get("bayonet"):
        m.S(bx - 3.2, bx + 0.2, 8.5, 9.1, 0.25, "s")
        m.S(bx + 0.1, bx + 0.6, 8.3, 9.4, 0.4, "d")
    if o.get("rust"):
        for (xx, yy) in o["rust"]:
            m.S(xx, xx + 0.8, yy, yy + 0.6, 1.2, "r")


def shotgun(m, o):
    kind = o.get("kind", "pump")
    bl = o.get("bl", 10.5)
    x0 = o.get("x0", 1.0)
    r0 = x0 + bl
    if kind in ("double", "sawed"):
        m.S(x0, r0, 9.0, 10.0, 0.45, "M", zc=7.2)
        m.S(x0, r0, 9.0, 10.0, 0.45, "M", zc=8.8)
        m.S(x0, r0, 10.0, 10.5, 0.5, "d")
        m.S(x0 - 0.1, x0 + 0.3, 9.9, 10.5, 0.2, "k")
        m.S(r0 - 0.4, r0 + 1.5, 7.8, 10.2, 1.3, "M")  # колодка
        for ff in (7.2, 8.8):
            m.S(r0, r0 + 0.4, 8.4, 9.6, 0.35, "k", zc=ff)
        m.S(r0 + 0.2, r0 + 0.7, 10.2, 10.9, 0.28, "M")
        if kind == "double":
            m.S(x0 + 3.5, x0 + 7.0, 7.6, 9.0, 1.1, "W")  # цевьё
        tail = r0 + 1.5
    else:
        m.S(x0, r0, 9.2, 10.4, 0.5, "m")
        m.S(x0, r0, 10.4, 10.8, 0.4, "k")
        m.S(x0 - 0.1, x0 + 0.3, 10.7, 11.3, 0.2, "k")
        if kind != "semi":
            m.S(x0, r0 - 1.0, 8.2, 9.2, 0.45, "d")  # трубчатый магазин
            m.S(x0 + 0.1, x0 + 0.5, 8.0, 9.4, 0.55, "k")
            m.S(x0 + 3.5, x0 + 7.2, 7.6, 9.1, 1.15, o.get("fore", "W"))  # цевьё помпы
            for i in range(4):
                m.S(x0 + 3.9 + i * 0.8, x0 + 4.2 + i * 0.8, 7.7, 9.0, 1.22, "k")
        else:
            m.S(x0 + 2.5, r0, 7.8, 9.2, 1.0, o.get("fore", "w"))
        m.S(r0, r0 + 3.6, 7.2, 10.2, 1.1, "m")
        m.S(r0 + 0.6, r0 + 1.8, 8.4, 9.6, 1.18, "k")
        m.S(r0 + 3.0, r0 + 3.6, 6.2, 7.2, 0.6, "m")
        trigger_group(m, r0 + 2.4, 5.6, 7.2, 2.6)
        tail = r0 + 3.6
    # приклад
    st = o.get("stock", "wood")
    if st == "wood":
        m.S(tail, tail + 2.0, 7.2, 10.0, 1.0, "w")
        m.S(tail + 2.0, 14.8, 6.6, 9.6, 1.0, "w")
        m.S(14.8, 15.9, 5.4, 9.6, 1.05, "w")
        m.S(15.9, 16.0, 5.2, 9.6, 1.08, "k")
        m.S(tail, tail + 1.5, 6.0, 7.2, 0.9, "w")
    elif st == "fold":
        m.S(tail, 15.0, 8.6, 9.2, 0.5, "M")
        m.S(15.0, 15.6, 5.6, 9.2, 0.55, "k")
    elif st == "pistol":
        m.S(tail - 0.2, tail + 2.2, 4.0, 7.4, 1.0, "W")
        m.S(tail + 0.2, tail + 2.6, 2.4, 4.0, 1.0, "W")
    if o.get("mag") == "box":
        m.S(x0 + bl - 0.6, x0 + bl + 1.8, 3.4, 7.4, 1.0, "k")


def flare_gun(m, o):
    pistol(m, {"slide": 7.5, "x0": 4.0, "slide_c": "o", "flare": True, "grip_c": "p", "panel_c": "g"})


def lmg(m, o):
    rifle(m, {"r0": 8.0, "r1": 12.5, "mag": "box", "hg": "tube", "optic": "carry", "bipod": True, "muz": "flash",
              "stock": "wood", "poly": False, "bx": 1.0, "hx0": 3.5, "magx": 8.6})
    m.S(0.5, 6.0, 8.0, 10.6, 1.0, "d")  # тяжёлый кожух ствола
    for i in range(5):
        m.S(1.0 + i * 0.9, 1.3 + i * 0.9, 8.2, 10.4, 1.08, "k")


FAMILY = {
    "pistol": pistol, "revolver": revolver, "smg": smg, "rifle": rifle, "shotgun": shotgun, "flare": flare_gun, "lmg": lmg,
}

GUN_SPECS = {
    "pistol_pm": ("pistol", {"slide": 8.0, "slide_c": "m", "grip_c": "g", "panel_c": "W"}),
    "pistol_tt": ("pistol", {"slide": 8.8, "slide_c": "d", "frame_c": "m", "panel_c": "W"}),
    "pistol_makarov_mod": ("pistol", {"slide": 8.0, "rail": True, "supp": True, "panel_c": "g"}),
    "pistol_stechkin": ("pistol", {"slide": 10.0, "x0": 2.8, "panel_c": "W", "rail": True}),
    "pistol_deagle": ("pistol", {"slide": 10.5, "x0": 2.5, "big": 1, "slide_c": "M", "frame_c": "m", "panel_c": "g"}),
    "pistol_glock": ("pistol", {"slide": 8.8, "slide_c": "p", "frame_c": "g", "rail": True, "panel_c": "g"}),
    "pistol_silenced": ("pistol", {"slide": 8.5, "supp": True, "slide_c": "m", "panel_c": "g"}),
    "pistol_flare": ("flare", {}),
    "revolver_nagant": ("revolver", {"bl": 5.5}),
    "revolver_magnum": ("revolver", {"bl": 8.0}),
    "smg_pp": ("smg", {"mag": "helical", "stock": "fold", "shroud": 3.0, "r0": 6.5, "r1": 13.5}),
    "smg_kedr": ("smg", {"mag": "box", "stock": "fold", "shroud": 2.5, "r0": 5.5, "r1": 12.0}),
    "smg_uzi": ("smg", {"mag": "grip", "stock": "skel", "shroud": 3.5, "r0": 5.5, "r1": 12.0}),
    "smg_vityaz": ("smg", {"mag": "curved", "stock": "skel", "shroud": 4.0, "r0": 6.5, "r1": 13.0}),
    "smg_mp5": ("smg", {"mag": "curved", "stock": "skel", "shroud": 4.5, "r0": 7.0, "r1": 13.5}),
    "rifle_ak74": ("rifle", {"hg": "wood", "mag": "ak", "stock": "wood", "muz": "brake", "poly": False, "sling": True}),
    "rifle_ak47": ("rifle", {"hg": "wood", "mag": "ak", "stock": "wood", "muz": "flash", "rust": [(9.0, 8.0)]}),
    "rifle_mosin": ("rifle", {"hg": "wood_long", "mag": "internal", "stock": "wood", "bolt": True, "bx": 0.5, "hx0": 3.8,
                              "r0": 8.5, "r1": 12.2, "bayonet": True, "rust": [(5.0, 9.0)]}),
    "rifle_mosin_sawed": ("rifle", {"hg": "wood_long", "mag": "internal", "stock": "wood", "bolt": True, "bx": 4.0, "hx0": 5.5,
                                    "r0": 8.5, "r1": 12.2}),
    "rifle_aks74u": ("rifle", {"hg": "wood", "mag": "ak", "stock": "fold", "muz": "brake", "bx": 4.0, "hx0": 6.0, "r0": 8.5,
                               "r1": 12.5}),
    "rifle_ak12": ("rifle", {"hg": "rail", "mag": "ak", "stock": "adj", "muz": "brake", "poly": True, "optic": "dot"}),
    "rifle_ar15": ("rifle", {"hg": "rail", "mag": "straight", "stock": "adj", "muz": "flash", "poly": True, "optic": "carry",
                             "r0": 7.8, "r1": 12.0, "magx": 8.6}),
    "rifle_sks": ("rifle", {"hg": "wood", "mag": "internal", "stock": "wood", "bayonet": True, "r0": 8.0, "r1": 12.2}),
    "rifle_bolt": ("rifle", {"hg": "wood_long", "mag": "internal", "stock": "sniper", "bolt": True, "optic": "scope",
                             "poly": False, "bx": 0.8, "hx0": 3.8, "r0": 8.4, "r1": 12.2}),
    "rifle_vss": ("rifle", {"hg": "tube", "mag": "short", "stock": "skel", "muz": "supp", "poly": True, "optic": "pso", "bx": 3.5,
                            "hx0": 5.0, "r0": 8.0}),
    "rifle_val": ("rifle", {"hg": "tube", "mag": "ak", "stock": "skel", "muz": "supp", "poly": True, "optic": "dot", "bx": 3.5,
                            "hx0": 5.0, "r0": 8.0}),
    "rifle_g36": ("rifle", {"hg": "poly", "mag": "box", "stock": "fold", "poly": True, "optic": "carry", "muz": "flash"}),
    "rifle_lmg": ("lmg", {}),
    "sniper_svd": ("rifle", {"hg": "wood_long", "mag": "short", "stock": "skel", "optic": "pso", "muz": "flash", "bx": 0.5,
                             "hx0": 4.0, "r0": 8.5, "r1": 12.5, "poly": False}),
    "sniper_dragunov_mod": ("rifle", {"hg": "rail", "mag": "short", "stock": "thumb", "optic": "scope", "muz": "brake",
                                      "bx": 0.5, "hx0": 3.5, "r0": 8.5, "r1": 12.5, "poly": True}),
    "sniper_barrett": ("rifle", {"hg": "tube", "mag": "box", "stock": "sniper", "optic": "bigscope", "muz": "brake", "bipod": True,
                                 "bx": 0.3, "hx0": 4.0, "r0": 8.5, "r1": 12.4, "poly": True, "y": 7.2, "magx": 10.0}),
    "shotgun_toz": ("shotgun", {"kind": "double", "bl": 9.0}),
    "shotgun_double_short": ("shotgun", {"kind": "double", "bl": 7.0, "x0": 3.0}),
    "shotgun_sawedoff": ("shotgun", {"kind": "sawed", "bl": 6.0, "x0": 3.5, "stock": "pistol"}),
    "shotgun_pump": ("shotgun", {"kind": "pump", "bl": 10.0}),
    "shotgun_saiga": ("shotgun", {"kind": "semi", "bl": 9.0, "mag": "box", "stock": "fold"}),
    "shotgun_bar": ("shotgun", {"kind": "semi", "bl": 10.0, "fore": "w"}),
    "shotgun_spas": ("shotgun", {"kind": "pump", "bl": 9.0, "stock": "fold", "fore": "k"}),
}

FALLBACK = {"pistol": ("pistol", {}), "revolver": ("revolver", {}), "smg": ("smg", {"mag": "box"}),
            "rifle": ("rifle", {}), "sniper": ("rifle", {"optic": "scope", "stock": "sniper", "bolt": True}),
            "shotgun": ("shotgun", {})}


def gun_model(gid, color):
    fam, opt = GUN_SPECS.get(gid) or FALLBACK.get(gid.split("_")[0], ("rifle", {}))
    m = Model({"m": color})
    FAMILY[fam](m, opt)
    if GUN_FLIP < 0:
        flipx(m)
    return m


def gun_display():
    # ПРИМЕЧАНИЕ: в первом лице/третьем лице +X модели смотрит на игрока при rotation y=-90 (ствол по -X уходит вперёд).
    ry = -90
    return {
        "gui": {"rotation": [8, 180, 0], "translation": [0, -0.5, 0], "scale": [1.12, 1.12, 1.12]},
        "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.5, 0.5, 0.5]},
        "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [0.95, 0.95, 0.95]},
        "thirdperson_righthand": {"rotation": [0, ry, 0], "translation": [0, 3.5, 1.5], "scale": [0.8, 0.8, 0.8]},
        "thirdperson_lefthand": {"rotation": [0, -ry, 0], "translation": [0, 3.5, 1.5], "scale": [0.8, 0.8, 0.8]},
        "firstperson_righthand": {"rotation": [0, ry, 0], "translation": [1.5, 1.2, 0.2], "scale": [0.85, 0.85, 0.85]},
        "firstperson_lefthand": {"rotation": [0, -ry, 0], "translation": [1.5, 1.2, 0.2], "scale": [0.85, 0.85, 0.85]},
    }


# ====================================================================== ДИАГОНАЛЬНЫЕ ПРЕДМЕТЫ (холодное, инструменты)
class Diag:
    """Пиксельный 16x16 рисунок вдоль диагонали (рукоять слева-внизу, острие справа-вверху) с глубиной."""

    def __init__(self, palette=None):
        self.pal = dict(PAL_COLORS)
        if palette:
            self.pal.update(palette)
        self.g = {}

    @staticmethod
    def uv(px, py):
        return px + (15 - py), px - (15 - py)

    def r(self, u0, u1, v0, v1, c, d=1.0):
        for py in range(16):
            for px in range(16):
                u, v = self.uv(px, py)
                if u0 <= u <= u1 and v0 <= v <= v1:
                    self.g[(px, py)] = (c, d)

    def p(self, px, py, c, d=1.0):
        if 0 <= px < 16 and 0 <= py < 16:
            self.g[(px, py)] = (c, d)

    def line(self, u0, u1, hw, c, d=1.0):
        self.r(u0, u1, -hw, hw, c, d)

    def model(self):
        m = Model(self.pal)
        rows = {}
        for (px, py), (c, d) in self.g.items():
            rows.setdefault((py, c, d), []).append(px)
        for (py, c, d), xs in rows.items():
            xs.sort()
            start = prev = xs[0]
            for x in xs[1:] + [None]:
                if x is not None and x == prev + 1:
                    prev = x
                    continue
                m.box(start, 15 - py, 8 - d / 2, prev + 1, 16 - py, 8 + d / 2, c)
                if x is not None:
                    start = prev = x
        return m


def d_blade_edge(d, u0, u1, hw, c="s", spine="d", dep=1.0, taper=True):
    """Клинок с обухом и заострением."""
    d.r(u0, u1, -hw, hw, c, dep)
    if hw >= 1:
        d.r(u0, u1, 1, hw, spine, dep + 0.8)  # обух потолще
    if taper:
        d.r(u1 - 1, u1 + 3, -1, 1, c, dep)
        d.r(u1 + 1, u1 + 3, 0, 1, c, dep)


def handle_wrap(d, u0, u1, hw, c1, c2, dep=1.8):
    for u in range(u0, u1 + 1):
        d.r(u, u, -hw, hw, c1 if (u // 2) % 2 == 0 else c2, dep)


def melee_diag(mid, color):
    d = Diag({"m": color})
    base = mid
    if base.startswith("knife_kitchen"):
        handle_wrap(d, 2, 8, 1, "L", "W")
        d.r(9, 9, -2, 2, "d", 2)
        d_blade_edge(d, 10, 19, 2, "s", "d")
    elif base == "knife_combat" or base == "knife_hunting" or base == "knife_trench":
        wc = {"knife_combat": ("g", "k"), "knife_hunting": ("w", "W"), "knife_trench": ("b", "d")}[base]
        handle_wrap(d, 2, 8, 1, *wc, dep=1.8)
        d.r(9, 10, -3, 3, "d", 2.2)
        d_blade_edge(d, 11, 21 if base != "knife_hunting" else 20, 2, "s", "m")
        d.p(2, 13, "k", 2)
    elif base == "knife_bayonet":
        d.r(1, 4, -2, 2, "d", 2.4)
        d.r(5, 7, -1, 1, "k", 1.6)
        d.r(8, 9, -3, 3, "d", 2.2)
        d_blade_edge(d, 10, 24, 1, "s", "d")
    elif base == "knife_throwing":
        d.r(3, 10, -1, 1, "k", 1.2)
        d.r(11, 11, -2, 2, "d", 1.6)
        d_blade_edge(d, 12, 22, 2, "s", "d", 0.8)
    elif base == "knife_butterfly":
        d.r(2, 9, -2, 2, "d", 1.4)
        d.r(3, 8, -1, -1, "k", 1.6)
        d.r(3, 8, 1, 1, "k", 1.6)
        d_blade_edge(d, 10, 21, 2, "s", "m")
    elif base == "shiv":
        handle_wrap(d, 2, 8, 1, "R", "k", 1.8)
        d_blade_edge(d, 9, 19, 1, "d", "k")
    elif base in ("machete", "machete_rusty"):
        rust = base.endswith("rusty")
        d.r(2, 8, -1, 1, "k", 1.8)
        d.r(9, 9, -2, 2, "d", 2.0)
        d.r(10, 26, -3, 1, "r" if rust else "s", 1.0)
        d.r(10, 26, 2, 2, "d", 1.8)
        d.r(24, 27, -3, 0, "r" if rust else "s", 1.0)
        d.r(26, 29, -1, 0, "r" if rust else "s", 1.0)
        if rust:
            for (a, b) in ((14, -1), (18, 0), (21, -2), (16, 1)):
                d.r(a, a, b, b, "R", 1.0)
    elif base in ("katana", "katana_masterwork"):
        mw = base.endswith("masterwork")
        handle_wrap(d, 1, 9, 1, "k" if not mw else "R", "x" if not mw else "b", 1.8)
        d.r(10, 11, -3, 3, "b" if mw else "d", 2.0)
        d.r(12, 27, -1, 1, "x" if not mw else "s", 0.9)
        d.r(12, 27, 1, 1, "d", 1.4)
        d.r(26, 29, 0, 1, "x", 0.9)
    elif base == "sword_saber":
        handle_wrap(d, 1, 8, 1, "w", "W", 1.8)
        d.r(9, 10, -4, 3, "b", 2.0)
        d.r(11, 24, -2, 1, "s", 0.9)
        d.r(11, 24, 2, 2, "d", 1.4)
        d.r(23, 28, -1, 0, "s", 0.9)
    elif base == "sword_broad":
        handle_wrap(d, 1, 7, 1, "L", "W", 1.8)
        d.r(8, 9, -5, 5, "b", 2.0)
        d.r(10, 25, -2, 2, "s", 1.0)
        d.r(10, 25, 0, 0, "d", 1.3)
        d.r(24, 29, -1, 1, "s", 1.0)
    elif base in ("sword_cleaver", "cleaver"):
        handle_wrap(d, 1, 8, 1, "w", "W", 1.8)
        d.r(9, 9, -2, 2, "d", 2.0)
        d.r(10, 21, -5, 1, "d" if base == "cleaver" else "r", 1.0)
        d.r(10, 21, 2, 2, "m", 1.7)
        d.r(13, 14, -3, -2, "k", 1.0)  # отверстие
        d.r(20, 22, -4, 0, "s", 1.0)
    elif base in ("bat_wood", "bat_nailed", "bat_aluminium"):
        al = base.endswith("aluminium")
        c, c2 = ("M", "s") if al else ("w", "L")
        d.r(1, 6, -1, 1, "k" if al else c, 1.8)
        d.r(7, 12, -1, 1, c, 2.0)
        d.r(13, 20, -2, 2, c, 2.4)
        d.r(21, 26, -3, 3, c2, 3.0)
        d.r(27, 27, -2, 2, c2, 2.6)
        d.r(0, 0, -1, 1, "k", 2.0)
        if base == "bat_nailed":
            for (u, v) in ((19, 2), (21, -1), (23, 1), (25, -2), (24, 3)):
                d.r(u, u, v, v, "d", 3.4)
        if al:
            d.r(3, 5, -1, 1, "R", 1.9)
    elif base == "crowbar":
        d.r(0, 22, -1, 1, "m", 1.8)
        d.r(22, 26, 0, 4, "m", 1.8)
        d.r(26, 29, 3, 5, "m", 1.8)
        d.r(24, 25, 4, 4, "k", 2.0)  # раздвоенный коготь
        d.r(0, 2, -2, -1, "m", 1.8)
        d.r(8, 10, -1, 1, "d", 2.0)
    elif base == "sledgehammer":
        d.r(0, 22, -1, 1, "w", 1.8)
        d.r(0, 3, -1, 1, "W", 2.0)
        d.r(20, 27, -5, 5, "d", 3.6)
        d.r(21, 26, -4, 4, "m", 4.0)
        d.r(22, 25, -3, 3, "M", 4.0)
        d.r(18, 19, -2, 2, "k", 2.2)
    elif base == "hammer_claw":
        d.r(0, 20, -1, 1, "w", 1.8)
        d.r(0, 3, -1, 1, "W", 2.0)
        d.r(19, 22, -4, 4, "d", 2.6)
        d.r(23, 25, -3, 1, "M", 2.8)
        d.r(23, 27, 1, 4, "m", 2.2)
    elif base in ("pipe_wrench", "pipe_lead", "mace_pipe"):
        if base == "pipe_lead":
            d.r(1, 25, -2, 2, "d", 2.4)
            d.r(1, 25, 2, 2, "m", 2.0)
            d.r(1, 7, -2, 2, "k", 2.6)
        elif base == "pipe_wrench":
            d.r(1, 21, -1, 1, "R", 2.0)
            d.r(0, 3, -1, 1, "k", 2.4)
            d.r(20, 25, -3, 3, "m", 2.6)
            d.r(24, 27, 1, 3, "m", 2.6)
            d.r(22, 24, -1, 1, "k", 2.8)
            d.r(25, 27, -3, -2, "m", 2.6)
        else:
            d.r(1, 20, -1, 1, "d", 2.0)
            d.r(0, 5, -1, 1, "k", 2.4)
            d.r(20, 27, -3, 3, "m", 3.4)
            d.r(21, 26, -2, 2, "M", 3.8)
            for (u, v) in ((19, 0), (28, 0), (24, 4), (24, -4), (22, 3), (26, -3), (22, -3), (26, 3)):
                d.r(u, u, v, v, "s", 1.2)
    elif base == "shovel_blade":
        d.r(0, 17, -1, 1, "w", 1.8)
        d.r(18, 27, -4, 4, "m", 1.2)
        d.r(18, 27, -4, -4, "M", 1.6)
        d.r(18, 27, 4, 4, "M", 1.6)
        d.r(26, 28, -2, 2, "s", 1.2)
        d.r(17, 19, -2, 2, "d", 2.0)
    elif base == "baton":
        d.r(1, 22, -1, 1, "k", 2.0)
        d.r(8, 12, -3, -2, "k", 1.8)  # боковая рукоять
        d.r(0, 8, -1, 1, "g", 2.4)
        d.r(22, 23, -1, 1, "d", 2.2)
    elif base == "spiked_club":
        d.r(1, 12, -1, 1, "w", 1.8)
        d.r(13, 26, -3, 3, "W", 3.0)
        d.r(14, 25, -2, 2, "w", 3.4)
        for (u, v) in ((16, 3), (19, -3), (22, 3), (25, -3), (28, 0), (20, 4), (17, -4), (23, -4)):
            d.r(u, u, v, v, "s", 1.4)
        d.r(0, 4, -1, 1, "k", 2.2)
    elif base == "axe_battle":
        d.r(0, 22, -1, 1, "w", 1.8)
        d.r(18, 28, -6, -2, "m", 1.4)
        d.r(18, 28, 2, 6, "m", 1.4)
        d.r(19, 27, -5, -3, "s", 1.4)
        d.r(19, 27, 3, 5, "s", 1.4)
        d.r(20, 26, -1, 1, "d", 2.6)
        d.r(0, 3, -1, 1, "W", 2.2)
    elif base == "fire_poker":
        d.r(2, 24, 0, 0, "m", 1.2)
        d.r(1, 2, -1, 1, "d", 1.4)
        d.r(0, 3, -3, -3, "d", 1.4)
        d.r(0, 0, -2, 2, "d", 1.4)
        d.r(23, 28, 0, 1, "m", 1.4)
        d.r(26, 30, -1, 0, "m", 1.4)
    else:
        d.r(2, 9, -1, 1, "w", 1.8)
        d.r(10, 22, -1, 1, "s", 1.0)
    return d.model()


def tool_diag(tid, ttype, color):
    d = Diag({"m": color})
    head = {"pick": "m", }
    hc = "m"
    if ttype == "pickaxe":
        rusty = "rusty" in tid or "old" in tid
        if tid == "pickaxe_pneumatic":
            d.r(2, 16, -3, 3, "y", 3.0)
            d.r(2, 16, -3, -3, "d", 3.4)
            d.r(0, 4, -4, 4, "k", 3.4)
            d.r(16, 22, -1, 1, "d", 2.2)
            d.r(22, 29, 0, 0, "s", 1.6)
            d.r(8, 10, -4, -3, "d", 2.0)
            d.r(6, 12, 3, 5, "k", 1.6)
            d.r(4, 5, 4, 6, "R", 1.2)
            return d.model()
        d.r(0, 22, -1, 1, "w", 1.8)
        d.r(0, 3, -1, 1, "W", 2.0)
        span = {"pickaxe_ice": 5, "pickaxe_chisel": 3, "pickaxe_geologist": 6, "pickaxe_sapper": 4, "pickaxe_rail": 8,
                "pickaxe_mattock": 6}.get(tid, 7)
        c = "r" if rusty else ("M" if "tungsten" in tid else "m")
        for v in range(-span, span + 1):
            uu = int(24 - abs(v) * (0.35 if "chisel" not in tid else 0.9))
            d.r(uu - 1, uu + 1, v, v, c, 2.6 if abs(v) < 2 else 2.0)
        if tid == "pickaxe_geologist":
            d.r(22, 26, 3, 6, "d", 3.4)  # молоток
            d.r(21, 22, -6, -3, "s", 1.6)
        if tid == "pickaxe_mattock":
            d.r(22, 27, 2, 7, "m", 1.4)
        if rusty:
            for (u, v) in ((22, 2), (23, -3), (24, 5), (23, -5)):
                d.r(u, u, v, v, "R", 2.2)
        d.r(21, 23, -1, 1, "d", 3.0)
    elif ttype == "shovel":
        d.r(0, 18, -1, 1, "w" if "sapper" not in tid else "d", 1.8)
        d.r(0, 2, -2, 2, "k", 2.2)  # ручка Т
        sp = {"shovel_sapper": (4, 22), "shovel_garden": (4, 24), "shovel_coal": (6, 26), "shovel_trench": (3, 25)}.get(tid, (5, 24))
        w, top = sp
        cc = "r" if "rusty" in tid else "m"
        d.r(17, top, -w, w, cc, 1.2)
        d.r(17, top, -w, -w, "M", 1.6)
        d.r(17, top, w, w, "M", 1.6)
        d.r(top - 1, top + 2, -w + 2, w - 2, cc, 1.2)
        d.r(16, 18, -2, 2, "d", 2.0)
        if "rusty" in tid:
            for (u, v) in ((19, 1), (21, -2), (22, 2)):
                d.r(u, u, v, v, "R", 1.4)
        if tid == "shovel_coal":
            d.r(17, 24, -w, -w, "k", 2.2)
            d.r(17, 24, w, w, "k", 2.2)
    elif ttype == "axe":
        d.r(0, 24, -1, 1, "w", 1.8)
        d.r(0, 3, -1, 1, "W", 2.0)
        ac = {"axe_fire": "R", "axe_tactical": "k", "axe_hatchet": "m", "axe_lumber": "m", "axe_forester": "m"}.get(tid, "m")
        big = tid in ("axe_lumber", "axe_fire", "axe_forester")
        d.r(18, 27 if big else 25, -6 if big else -5, -2, ac, 1.6)
        d.r(19, 26 if big else 24, -5 if big else -4, -3, "s", 1.6)
        d.r(20, 25, -1, 1, "d", 2.6)
        if tid == "axe_fire":
            d.r(22, 29, 2, 4, "m", 1.6)  # клюв
        if tid == "axe_lumber":
            d.r(18, 27, 2, 6, "m", 1.6)
            d.r(19, 26, 3, 5, "s", 1.6)
        if tid == "axe_tactical":
            d.r(0, 6, -1, 1, "k", 2.2)
            d.r(0, 0, -3, 3, "k", 1.6)
    elif ttype == "hoe":
        d.r(0, 22, -1, 1, "w", 1.8)
        d.r(0, 3, -1, 1, "W", 2.0)
        if tid == "hoe_rake":
            d.r(21, 22, -6, 6, "M", 1.6)
            for v in range(-6, 7, 2):
                d.r(23, 26, v, v, "M", 1.4)
        elif tid == "hoe_cultivator":
            d.r(21, 22, -1, 6, "M", 1.6)
            for v in (2, 4, 6):
                d.r(23, 27, v, v, "M", 1.4)
        elif tid == "hoe_mattock":
            d.r(21, 27, -1, 7, "m", 1.6)
            d.r(25, 28, 3, 6, "s", 1.6)
        else:
            d.r(21, 24, -1, 6, "m", 1.4)
            d.r(24, 26, 2, 6, "s", 1.4)
    else:
        d.r(0, 22, -1, 1, "w", 1.8)
    return d.model()


def diag_display():
    return {
        "gui": {"rotation": [8, -25, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]},
        "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.5, 0.5, 0.5]},
        "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]},
        "thirdperson_righthand": {"rotation": [0, -90, 55], "translation": [0, 4, 0.5], "scale": [0.85, 0.85, 0.85]},
        "thirdperson_lefthand": {"rotation": [0, 90, -55], "translation": [0, 4, 0.5], "scale": [0.85, 0.85, 0.85]},
        "firstperson_righthand": {"rotation": [0, -90, 25], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]},
        "firstperson_lefthand": {"rotation": [0, 90, -25], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]},
    }


# ====================================================================== СЧЁТЧИК ГЕЙГЕРА
GEIGER_FRAMES = 12


def geiger_screen():
    """Анимированная лента кадров 16xN*16: развёртка, шкала, мерцание."""
    import math
    img = Image.new("RGBA", (16, 16 * GEIGER_FRAMES), (0, 0, 0, 255))
    px = img.load()
    rnd = random.Random(5)
    for f in range(GEIGER_FRAMES):
        oy = f * 16
        for y in range(16):
            for x in range(16):
                px[x, oy + y] = (8, 26, 14, 255)
        # сетка
        for x in range(0, 16, 4):
            for y in range(16):
                px[x, oy + y] = (12, 40, 22, 255)
        # бегущая развёртка
        sx = int(f * 16 / GEIGER_FRAMES)
        for y in range(16):
            px[sx, oy + y] = (40, 200, 90, 255)
            px[(sx - 1) % 16, oy + y] = (22, 110, 52, 255)
        # осциллограмма с «шумом» радиации
        for x in range(16):
            h = 8 + int(3 * math.sin((x + f * 2) * 0.9)) + rnd.randint(-2, 2)
            h = max(2, min(13, h))
            px[x, oy + h] = (80, 255, 130, 255)
        # индикатор-вспышка каждые 3 кадра
        if f % 3 == 0:
            for x in range(13, 16):
                for y in range(0, 3):
                    px[x, oy + y] = (255, 70, 40, 255)
    return img


def geiger_model():
    m = Model({"m": "#7a7a2e"})
    m.S(4.5, 11.5, 2.0, 11.0, 1.7, "m")  # корпус
    m.S(4.2, 11.8, 2.0, 2.6, 1.9, "d")  # низ
    m.S(4.2, 11.8, 10.6, 11.2, 1.9, "d")  # верх
    m.S(5.5, 10.5, -1.0, 2.0, 1.1, "g")  # рукоять
    m.S(5.3, 10.7, -1.4, -0.8, 1.2, "k")
    m.S(6.0, 6.4, 2.0, 11.0, 1.8, "k")  # накладки
    m.S(9.6, 10.0, 2.0, 11.0, 1.8, "k")
    # зонд на кабеле
    m.S(11.5, 13.5, 8.8, 9.2, 0.25, "k")
    m.S(13.3, 14.5, 7.0, 9.6, 0.7, "d")
    m.S(14.5, 15.3, 7.2, 9.4, 0.55, "y")
    m.S(13.6, 14.3, 5.4, 7.0, 0.4, "k")
    # ручки настройки
    m.S(5.8, 7.2, 11.2, 12.0, 0.5, "y")
    m.S(8.8, 10.2, 11.2, 12.0, 0.5, "R")
    # антенна/динамик
    m.S(8.0, 8.4, 11.2, 14.0, 0.2, "M")
    for i in range(3):
        m.S(6.4 + i * 1.0, 6.9 + i * 1.0, 3.0, 3.6, 1.75, "k")
    return m


def geiger_json():
    m = geiger_model()
    img, ks = m.texture(seed=77)
    els = m.json(ks, None)
    # экраны на обеих сторонах (z=±)
    for z1, z2, face in ((9.7, 9.8, "south"), (6.2, 6.3, "north")):
        els.append({"from": [6.6, 4.4, z1], "to": [9.4, 9.8, z2],
                    "faces": {face: {"uv": [0, 0, 16, 16], "texture": "#screen"}}})
        els.append({"from": [6.3, 4.1, z1 - 0.05 if face == "south" else z1 - 0.05],
                    "to": [9.7, 10.1, z2 - 0.05 if face == "south" else z2 - 0.05],
                    "faces": {f: {"uv": [0.5, 0.5, 1.5, 1.5], "texture": "#p"} for f in ("east", "west", "up", "down")}})
    return img, els


def geiger_display():
    return {
        "gui": {"rotation": [10, -30, 0], "translation": [0, -1, 0], "scale": [1.15, 1.15, 1.15]},
        "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.55, 0.55, 0.55]},
        "fixed": {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]},
        "thirdperson_righthand": {"rotation": [0, 0, 0], "translation": [0, 3, 1], "scale": [0.6, 0.6, 0.6]},
        "thirdperson_lefthand": {"rotation": [0, 0, 0], "translation": [0, 3, 1], "scale": [0.6, 0.6, 0.6]},
        "firstperson_righthand": {"rotation": [-5, -20, 0], "translation": [1.5, 2.5, 0], "scale": [0.9, 0.9, 0.9]},
        "firstperson_lefthand": {"rotation": [-5, 20, 0], "translation": [-1.5, 2.5, 0], "scale": [0.9, 0.9, 0.9]},
    }


# ====================================================================== ВЫВОД
def write_item_model(path, tex_ref, elements, display, extra_tex=None, gui_light="side"):
    tex = {"p": tex_ref, "particle": tex_ref}
    if extra_tex:
        tex.update(extra_tex)
    data = {"parent": "minecraft:block/block", "gui_light": gui_light, "textures": tex, "elements": elements, "display": display}
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, separators=(",", ":"))


def preview(model, path, scale=24):
    """Боковой вид (X вправо, Y вверх) для проверки формы."""
    from PIL import ImageDraw
    w = 16 * scale
    img = Image.new("RGB", (w, w), (30, 32, 36))
    dr = ImageDraw.Draw(img)
    for i in range(0, 16):
        dr.line([(i * scale, 0), (i * scale, w)], fill=(40, 42, 46))
        dr.line([(0, i * scale), (w, i * scale)], fill=(40, 42, 46))
    for b in sorted(model.boxes, key=lambda b: b[2]):
        x1, y1, z1, x2, y2, z2, c = b
        col = hx(model.pal[c])
        dr.rectangle([x1 * scale, w - y2 * scale, x2 * scale, w - y1 * scale], fill=col, outline=tuple(int(v * .6) for v in col))
    img.save(path)


if __name__ == "__main__":
    import sys
    out = sys.argv[1] if len(sys.argv) > 1 else "/tmp"
    os.makedirs(out, exist_ok=True)
    for gid in ("pistol_pm", "revolver_nagant", "smg_pp", "rifle_ak74", "sniper_barrett", "shotgun_pump", "rifle_lmg", "shotgun_toz"):
        preview(gun_model(gid, "#3b3f44"), f"{out}/{gid}.png")
    for mid in ("katana", "crowbar", "bat_nailed", "sledgehammer", "axe_battle", "machete"):
        preview(melee_diag(mid, "#888888"), f"{out}/{mid}.png")
    for tid, ty in (("pickaxe_miner", "pickaxe"), ("shovel_sapper", "shovel"), ("axe_fire", "axe"), ("hoe_rake", "hoe")):
        preview(tool_diag(tid, ty, "#7b8790"), f"{out}/{tid}.png")
