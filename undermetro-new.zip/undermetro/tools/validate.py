# -*- coding: utf-8 -*-
"""Статическая проверка: JSON валиден, ссылки на предметы/модели/текстуры существуют, id из Java-кода зарегистрированы."""
import glob, json, os, re, sys
sys.path.insert(0, os.path.dirname(__file__))
from defs import *
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = f"{ROOT}/src/main/resources"
errs = []
_all = [r[0] for r in CONSUMABLES + MELEE + TOOLS + GUNS + MISC] + [d[0] for d in DECOR]
for _i in set(x for x in _all if _all.count(x) > 1): errs.append(f'duplicate id {_i}')
ids = {r[0] for r in CONSUMABLES} | {r[0] for r in MELEE + TOOLS + GUNS + MISC}
blocks = {machine_name(k, t) for k, _, _ in KINDS for t in range(1, MAX_TIER + 1)} | {"hatch", "emergency_filter"} | {d[0] for d in DECOR}
ids |= blocks
ids |= {f"blueprint_{machine_name(k,t)}" for k, _, _ in KINDS for t in range(2, MAX_TIER + 1)}
# JSON
nj = 0
for p in glob.glob(f"{RES}/**/*.json", recursive=True):
    try: json.load(open(p, encoding="utf-8")); nj += 1
    except Exception as e: errs.append(f"bad json {p}: {e}")
# id в Java
for p in glob.glob(f"{ROOT}/src/main/java/**/*.java", recursive=True):
    s = open(p, encoding="utf-8").read()
    for m in re.finditer(r'(?:ModRegistry\.item|[^\w.]item|isItem\([^,]+,)\s*\(?\s*"([a-z0-9_]+)"', s):
        if m.group(1) not in ids and m.group(1) not in ("blueprint_",): errs.append(f"{os.path.basename(p)}: unknown item '{m.group(1)}'")
# ссылки в данных
for p in glob.glob(f"{RES}/data/undermetro/**/*.json", recursive=True):
    s = open(p, encoding="utf-8").read()
    for m in re.finditer(r'"(?:name|item|id)":\s*"undermetro:([a-z0-9_]+)"', s):
        if m.group(1) not in ids and m.group(1) not in ("radiation",): errs.append(f"{os.path.relpath(p, RES)}: unknown item {m.group(1)}")
# модели/текстуры
for p in glob.glob(f"{RES}/assets/undermetro/models/**/*.json", recursive=True):
    j = json.load(open(p, encoding="utf-8"))
    for t in (j.get("textures") or {}).values():
        if t.startswith("undermetro:") and not os.path.exists(f"{RES}/assets/undermetro/textures/{t.split(':')[1]}.png"): errs.append(f"{p}: no texture {t}")
    par = j.get("parent", "")
    if par.startswith("undermetro:") and not os.path.exists(f"{RES}/assets/undermetro/models/{par.split(':')[1]}.json"): errs.append(f"{p}: no parent {par}")
for p in glob.glob(f"{RES}/assets/undermetro/blockstates/*.json"):
    s = open(p, encoding="utf-8").read()
    for m in re.finditer(r'undermetro:(block/[a-z0-9_]+)', s):
        if not os.path.exists(f"{RES}/assets/undermetro/models/{m.group(1)}.json"): errs.append(f"{p}: no model {m.group(1)}")
for b in blocks:
    for d in ("blockstates", "models/item", "models/block"):
        if not os.path.exists(f"{RES}/assets/undermetro/{d}/{b}.json"): errs.append(f"missing {d}/{b}")
    if not os.path.exists(f"{RES}/data/undermetro/loot_table/blocks/{b}.json"): errs.append(f"missing loot {b}")
for i in ids - blocks:
    if not os.path.exists(f"{RES}/assets/undermetro/models/item/{i}.json"): errs.append(f"missing item model {i}")
lang = json.load(open(f"{RES}/assets/undermetro/lang/en_us.json", encoding="utf-8"))
for i in ids - blocks:
    if f"item.undermetro.{i}" not in lang: errs.append(f"no lang {i}")
# ключи lang, используемые в Java
for p in glob.glob(f"{ROOT}/src/main/java/**/*.java", recursive=True):
    for m in re.finditer(r'"((?:msg|hud|skill)\.undermetro\.[a-z_]+)"', open(p, encoding="utf-8").read()):
        if m.group(1) not in lang: errs.append(f"lang key missing: {m.group(1)}")
    for m in re.finditer(r'"((?:msg|hud|skill)\.undermetro\.)"\s*\+', open(p, encoding="utf-8").read()): pass
print(f"json files ok: {nj}, registered ids: {len(ids)} (items+blocks)")
print("\n".join(errs) if errs else "NO ERRORS")
sys.exit(1 if errs else 0)
